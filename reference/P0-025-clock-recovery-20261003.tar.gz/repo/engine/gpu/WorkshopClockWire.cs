using System;
using System.Buffers.Binary;

namespace CuriousContraptions.Gpu;

public enum NativeClockProfile : uint { Chromium154MacIsolated = 2 }

/// <summary>Exact native-clock control boundary; no clock timestamp is converted to a JS Number.</summary>
public static class WorkshopClockWire
{
    public const uint Version = 2;
    public const int PeerBytes = 40;
    public const int ProbeBytes = 56;
    public const int ReplyBytes = 72;
    public const int ReceiptBytes = 24;

    public static byte[] EncodePeer(WorkshopClockPeer peer)
    {
        peer.Validate();
        if (peer.Uncertainty.Value != 100_000) throw new ArgumentException("Unsupported isolated native clock profile.");
        var bytes = new byte[PeerBytes]; var data = bytes.AsSpan();
        BinaryPrimitives.WriteUInt32LittleEndian(data, Version);
        BinaryPrimitives.WriteUInt32LittleEndian(data[4..], (uint)NativeClockProfile.Chromium154MacIsolated);
        WorkshopWire.WriteSession(data[8..24], peer.Session);
        BinaryPrimitives.WriteUInt64LittleEndian(data[24..], peer.Generation.Value);
        BinaryPrimitives.WriteUInt64LittleEndian(data[32..], peer.Uncertainty.Value);
        return bytes;
    }

    public static WorkshopClockPeer DecodePeer(ReadOnlySpan<byte> data)
    {
        if (data.Length != PeerBytes || BinaryPrimitives.ReadUInt32LittleEndian(data) != Version ||
            (NativeClockProfile)BinaryPrimitives.ReadUInt32LittleEndian(data[4..]) != NativeClockProfile.Chromium154MacIsolated)
            throw new ArgumentException("Unsupported clock bootstrap.");
        var peer = new WorkshopClockPeer(WorkshopWire.ReadSession(data[8..24]),
            new(BinaryPrimitives.ReadUInt64LittleEndian(data[24..])), new(BinaryPrimitives.ReadUInt64LittleEndian(data[32..])));
        peer.Validate();
        if (peer.Uncertainty.Value != 100_000) throw new ArgumentException("Unknown native precision bound.");
        return peer;
    }

    public static byte[] EncodeProbe(ClockProbe probe, WorkshopClockPeer peer)
    {
        if (probe.Session != peer.Session || probe.Generation != peer.Generation || probe.Sequence.Value == 0)
            throw new ArgumentException("Probe does not own this native clock.");
        probe.BrowserSent.Validate();
        var bytes = new byte[ProbeBytes];
        var bootstrap = EncodePeer(peer);
        bootstrap.CopyTo(bytes, 0);
        BinaryPrimitives.WriteUInt64LittleEndian(bytes.AsSpan(40), probe.Sequence.Value);
        BinaryPrimitives.WriteInt64LittleEndian(bytes.AsSpan(48), probe.BrowserSent.Value);
        return bytes;
    }

    public static ClockProbe DecodeProbe(ReadOnlySpan<byte> data, WorkshopClockPeer peer)
    {
        if (data.Length != ProbeBytes) throw new ArgumentException("Invalid clock probe length.");
        var declared = DecodePeer(data[..PeerBytes]);
        if (declared != peer) throw new ArgumentException("Probe belongs to another session or native clock.");
        var probe = new ClockProbe(peer.Session, peer.Generation,
            new(BinaryPrimitives.ReadUInt64LittleEndian(data[40..])), new(BinaryPrimitives.ReadInt64LittleEndian(data[48..])));
        if (probe.Sequence.Value == 0) throw new ArgumentException("Probe identity must be positive.");
        probe.BrowserSent.Validate(); return probe;
    }

    public static byte[] EncodeReply(ReadOnlySpan<byte> encodedProbe, WorkshopClockPeer peer,
        MonotonicNanoseconds received, MonotonicNanoseconds sent)
    {
        DecodeProbe(encodedProbe, peer);
        received.Validate(); sent.Validate();
        if (sent.Value < received.Value) throw new ArgumentException("Worker clock reversed.");
        var bytes = new byte[ReplyBytes]; encodedProbe.CopyTo(bytes);
        BinaryPrimitives.WriteInt64LittleEndian(bytes.AsSpan(56), received.Value);
        BinaryPrimitives.WriteInt64LittleEndian(bytes.AsSpan(64), sent.Value);
        return bytes;
    }

    public static ClockReply DecodeReply(ReadOnlySpan<byte> data, WorkshopClockPeer peer, MonotonicNanoseconds received)
    {
        if (data.Length != ReplyBytes) throw new ArgumentException("Invalid clock reply length.");
        var probe = DecodeProbe(data[..ProbeBytes], peer);
        return new(probe, new(BinaryPrimitives.ReadInt64LittleEndian(data[56..])),
            new(BinaryPrimitives.ReadInt64LittleEndian(data[64..])), received);
    }

    public const int DiagnosticBytes = 120;
    public static byte[] EncodeRejectedReply(ReadOnlySpan<byte> reply, MonotonicNanoseconds received)
    {
        received.Validate();
        var data = new byte[DiagnosticBytes];
        reply[..Math.Min(reply.Length, ReplyBytes)].CopyTo(data);
        BinaryPrimitives.WriteInt64LittleEndian(data.AsSpan(72), received.Value);
        BinaryPrimitives.WriteInt32LittleEndian(data.AsSpan(80), (int)ClockProbeOutcome.Malformed);
        BinaryPrimitives.WriteInt32LittleEndian(data.AsSpan(84), reply.Length);
        return data; // At most one native reply is retained; declared length records any truncation.
    }

    public static byte[] EncodeExpiredProbe(ClockProbe probe, WorkshopClockPeer peer, MonotonicNanoseconds now)
    {
        var data = new byte[DiagnosticBytes];
        EncodeProbe(probe, peer).CopyTo(data, 0);
        BinaryPrimitives.WriteInt64LittleEndian(data.AsSpan(72), now.Value);
        BinaryPrimitives.WriteInt32LittleEndian(data.AsSpan(80), (int)ClockProbeOutcome.Expired);
        return data; // Worker timestamps are unavailable; this outcome records a local expiry.
    }

    public static byte[] EncodeObservation(ClockObservation observation, WorkshopClockPeer peer)
    {
        var reply = observation.Reply;
        var data = new byte[DiagnosticBytes];
        var probe = EncodeProbe(reply.Probe, peer);
        probe.CopyTo(data, 0);
        BinaryPrimitives.WriteInt64LittleEndian(data.AsSpan(56), reply.WorkerReceived.Value);
        BinaryPrimitives.WriteInt64LittleEndian(data.AsSpan(64), reply.WorkerSent.Value);
        BinaryPrimitives.WriteInt64LittleEndian(data.AsSpan(72), reply.BrowserReceived.Value);
        BinaryPrimitives.WriteInt32LittleEndian(data.AsSpan(80), (int)observation.Outcome);
        BinaryPrimitives.WriteInt128LittleEndian(data.AsSpan(88), observation.Offset.Lower);
        BinaryPrimitives.WriteInt128LittleEndian(data.AsSpan(104), observation.Offset.Upper);
        return data;
    }

    public static void WriteReceipt(WorkshopResponse response, Span<byte> destination)
    {
        if (destination.Length != ReceiptBytes || response.Kind != WorkshopResponseKind.Read || response.Publication.Value == 0)
            throw new ArgumentException("Invalid physical publication receipt.");
        WorkshopWire.WriteSession(destination, response.Session);
        BinaryPrimitives.WriteUInt64LittleEndian(destination[16..], response.Publication.Value);
    }
}
