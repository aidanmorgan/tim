using System;

namespace CuriousContraptions.Gpu;

public enum PresentationBoundary { Continuous, Seed, Run, Completed }
public enum PresentationQuality { AwaitingHistory, Interpolated, ClockInvalid, Stale, Terminal, Faulted, Retired }
public readonly record struct PresentationSimulationTime(double Seconds);
public readonly record struct PresentedBody(GpuBodyId Id, CellOrigin Cell, LocalPosition Local);
public readonly record struct WorkshopPresentationSample(PresentedBody? Body, MonotonicNanoseconds? DisplayWall,
    PresentationSimulationTime SimulationTime, PresentationQuality Quality, WorkshopPresentationEvidence Evidence = default);
public readonly record struct PresentationEndpoint(SimulationTick Tick, WorkshopClockStamp Capture, MappedCapture? Mapped);
public readonly record struct WorkshopPresentationEvidence(MonotonicNanoseconds SelectedAt, ulong ClockEpoch, ulong DisplayEpoch,
    SimulationEpoch WorldEpoch, PresentationEndpoint? Latest, PresentationEndpoint? Before, PresentationEndpoint? After);

/// <summary>
/// Sole browser physical history: three complete canonical records. Rendered poses have no
/// authoritative tick or velocity; interpolation cannot become a simulation input.
/// </summary>
public sealed class WorkshopPoseHistory
{
    public const int Capacity = 3;
    public const long DelayNanoseconds = 16_666_667;
    public const long StaleNanoseconds = 50_000_000;
    public const int ReservedHistoryBytes = Capacity * WorkshopWire.ResponseBytes + 1024;
    private readonly Entry[] _entries = new Entry[Capacity];
    private byte _count, _next;
    private sbyte _latest = -1, _terminal = -1;
    private ulong _version, _clockEpoch, _displayEpoch;
    private long _displayWall;
    private double _simulationTime;
    private bool _dirty, _retired, _displayTimingValid;
    private WorkshopSimulationPhase _phase;
    public PresentationQuality Quality { get; private set; } = PresentationQuality.AwaitingHistory;
    public int Count => _count;
    public WorkshopResponse? Latest => _latest < 0 ? null : _entries[_latest].Response;

    private readonly record struct Entry(WorkshopResponse Response, MappedCapture? Mapped);

    public readonly struct Prepared
    {
        internal readonly WorkshopPoseHistory Owner;
        internal readonly ulong Version, ClockEpoch;
        internal readonly WorkshopResponse Response;
        internal readonly MappedCapture? Mapped;
        internal readonly bool Reseed, ReplaceLatest, Terminal;
        internal Prepared(WorkshopPoseHistory owner, ulong version, ulong clockEpoch,
            WorkshopResponse response, MappedCapture? mapped, bool reseed, bool replaceLatest, bool terminal)
        {
            Owner = owner; Version = version; ClockEpoch = clockEpoch; Response = response;
            Mapped = mapped; Reseed = reseed; ReplaceLatest = replaceLatest; Terminal = terminal;
        }
    }

    public Prepared Prepare(WorkshopResponse response, MappedCapture? mapped, PresentationBoundary boundary, ulong clockEpoch)
    {
        if (_retired) throw new ObjectDisposedException(nameof(WorkshopPoseHistory));
        if (!Enum.IsDefined(boundary) || clockEpoch == 0 || _version == ulong.MaxValue)
            throw new ArgumentException("Invalid presentation ownership.");
        if (response.Read.Capture is not { } capture) throw new ArgumentException("Physical history requires a capture.");
        capture.Validate();
        if (mapped is { } mapping && (mapping.BrowserInterval.Width < 0 ||
            mapping.BrowserInterval.Width > WorkshopClockMapping.MaximumMappedWidth ||
            mapping.BrowserInterval.Lower < 0 || (mapping.BrowserInterval.Lower + mapping.BrowserInterval.Upper) / 2 > long.MaxValue))
            throw new ArgumentException("Invalid mapped capture interval.");
        // Physical publication can overtake the original Run ACK. Its committed phase starts
        // the new segment even when the ACK's presentation read is already obsolete.
        var startsRun = _latest >= 0 && _phase == WorkshopSimulationPhase.Building &&
            response.Phase is WorkshopSimulationPhase.Running or WorkshopSimulationPhase.Faulted;
        var reseed = boundary is PresentationBoundary.Seed or PresentationBoundary.Run or PresentationBoundary.Completed ||
            _clockEpoch != clockEpoch || startsRun;
        var replace = false;
        if (_latest >= 0)
        {
            var previous = _entries[_latest];
            if (response.Session != previous.Response.Session || response.Read.Epoch.Value < previous.Response.Read.Epoch.Value)
                throw new ArgumentException("History belongs to another or retired session.");
            if (response.Read.Epoch != previous.Response.Read.Epoch) reseed = true;
            if (boundary == PresentationBoundary.Completed && response.Read.Epoch == previous.Response.Read.Epoch &&
                response.Read.Tick == previous.Response.Read.Tick)
            {
                if (response.Read.Capture != previous.Response.Read.Capture ||
                    !SameBody(response.Read.Ball, previous.Response.Read.Ball))
                    throw new ArgumentException("A terminal physical endpoint cannot be restamped or changed.");
                if (_clockEpoch == clockEpoch) mapped = previous.Mapped;
            }
            if (!reseed)
            {
                if (response.Read.Tick.Value < previous.Response.Read.Tick.Value ||
                    response.Read.Revision.Value < previous.Response.Read.Revision.Value)
                    throw new ArgumentException("Physical history cannot regress.");
                if (response.Read.Ball?.Id != previous.Response.Read.Ball?.Id)
                    throw new ArgumentException("A body identity change requires a committed discontinuity.");
                if (response.Read.Tick == previous.Response.Read.Tick)
                {
                    if (response.Read.Capture != previous.Response.Read.Capture ||
                        !SameBody(response.Read.Ball, previous.Response.Read.Ball))
                        throw new ArgumentException("A repeated physical endpoint cannot be restamped or changed.");
                    replace = true;
                    mapped = previous.Mapped; // Preserve the original uncertainty, including no valid mapping.
                }
            }
        }
        return new(this, _version, clockEpoch, response, mapped, reseed, replace,
            boundary is PresentationBoundary.Seed or PresentationBoundary.Run or PresentationBoundary.Completed);
    }

    public void Commit(Prepared prepared)
    {
        if (!ReferenceEquals(prepared.Owner, this) || prepared.Version != _version || _retired)
            throw new InvalidOperationException("Prepared history no longer owns this recipient.");
        if (prepared.Reseed)
        {
            Array.Clear(_entries); _count = _next = 0; _latest = _terminal = -1;
            _simulationTime = prepared.Response.Read.Tick.Value / 120.0;
        }
        int index = prepared.ReplaceLatest && _latest >= 0 ? _latest : _next;
        if (_terminal == index) _terminal = -1;
        _entries[index] = new(prepared.Response, prepared.Mapped);
        if (!prepared.ReplaceLatest)
        {
            _next = checked((byte)((index + 1) % Capacity));
            _count = checked((byte)Math.Min(_count + 1, Capacity));
        }
        _latest = checked((sbyte)index);
        if (prepared.Terminal) _terminal = checked((sbyte)index);
        _clockEpoch = prepared.ClockEpoch; _phase = prepared.Response.Phase;
        _version++; _dirty = true;
    }

    public bool TryTakeLatest(out WorkshopResponse response)
    {
        if (!_dirty || _latest < 0) { response = default; return false; }
        response = _entries[_latest].Response; _dirty = false; return true;
    }

    public bool TryPresent(MonotonicNanoseconds now, WorkshopClockMapping clock, out WorkshopPresentationSample sample)
    {
        var selected = TrySelect(now, clock, out sample, out var before, out var after);
        var latest = _latest < 0 ? (Entry?)null : _entries[_latest];
        sample = sample with
        {
            DisplayWall = selected ? sample.DisplayWall : _displayTimingValid ? new(_displayWall) : null,
            SimulationTime = new(_simulationTime), Quality = Quality,
            Evidence = new(now, _clockEpoch, _displayEpoch, latest?.Response.Read.Epoch ?? default,
                Endpoint(latest), Endpoint(before), Endpoint(after))
        };
        return selected;
    }

    private static PresentationEndpoint? Endpoint(Entry? entry) => entry is { } value &&
        value.Response.Read.Capture is { } capture ? new(value.Response.Read.Tick, capture, value.Mapped) : null;

    private bool TrySelect(MonotonicNanoseconds now, WorkshopClockMapping clock,
        out WorkshopPresentationSample sample, out Entry? selectedBefore, out Entry? selectedAfter)
    {
        sample = default; selectedBefore = selectedAfter = null;
        if (_retired) { Quality = PresentationQuality.Retired; return false; }
        clock.Observe(now);
        if (_phase == WorkshopSimulationPhase.Faulted)
        { Quality = PresentationQuality.Faulted; _terminal = -1; return false; }
        if (_terminal >= 0)
        {
            var entry = _entries[_terminal];
            var endpoint = entry.Response.Read;
            var wall = entry.Mapped is { } mapped ? new MonotonicNanoseconds(Math.Max(_displayWall, mapped.BrowserInterval.Midpoint)) : (MonotonicNanoseconds?)null;
            _terminal = -1;
            selectedBefore = selectedAfter = entry;
            _displayTimingValid = wall is not null;
            _displayEpoch = _displayTimingValid ? _clockEpoch : 0;
            _simulationTime = endpoint.Tick.Value / 120.0;
            Quality = PresentationQuality.Terminal;
            if (wall is { } mappedWall) _displayWall = mappedWall.Value;
            sample = new(Pose(endpoint.Ball), wall, new(_simulationTime), Quality);
            return true;
        }
        if (!clock.IsQualified || clock.DisplayEpoch != _clockEpoch)
        { Quality = PresentationQuality.ClockInvalid; return false; }
        if (_phase != WorkshopSimulationPhase.Running) return false;
        if (now.Value < DelayNanoseconds) { Quality = PresentationQuality.AwaitingHistory; return false; }
        var requested = now.Value - DelayNanoseconds;
        if (requested < _displayWall) { Quality = PresentationQuality.AwaitingHistory; return false; }
        // Any ambiguous or regressing pair holds until it is evicted; never reorder physical time.
        for (var i = 0; i < _count; i++)
            for (var j = i + 1; j < _count; j++)
                if (_entries[i].Mapped is { } left && _entries[j].Mapped is { } right)
                {
                    var tickOrder = _entries[i].Response.Read.Tick.Value.CompareTo(_entries[j].Response.Read.Tick.Value);
                    var timeOrder = left.BrowserInterval.Midpoint.CompareTo(right.BrowserInterval.Midpoint);
                    if (tickOrder != 0 && tickOrder != timeOrder)
                    { Quality = PresentationQuality.AwaitingHistory; return false; }
                }
        Entry? before = null, after = null;
        for (var i = 0; i < _count; i++)
        {
            var item = _entries[i];
            if (item.Mapped is not { } mapping) continue;
            var time = mapping.BrowserInterval.Midpoint;
            if (time <= requested && (before is null || time > before.Value.Mapped!.Value.BrowserInterval.Midpoint))
                before = item;
            if (time >= requested && (after is null || time < after.Value.Mapped!.Value.BrowserInterval.Midpoint))
                after = item;
        }
        if (before is not { } first || after is not { } last)
        {
            Quality = LatestAge(now) > StaleNanoseconds ? PresentationQuality.Stale : PresentationQuality.AwaitingHistory;
            return false;
        }
        var a = first.Mapped!.Value.BrowserInterval.Midpoint;
        var b = last.Mapped!.Value.BrowserInterval.Midpoint;
        if (b < a || last.Response.Read.Tick.Value < first.Response.Read.Tick.Value ||
            (a == b && last.Response.Read.Tick != first.Response.Read.Tick))
        { Quality = PresentationQuality.AwaitingHistory; return false; }
        var fraction = a == b ? 0 : (double)(requested - a) / (b - a);
        var timeSeconds = (first.Response.Read.Tick.Value +
            (last.Response.Read.Tick.Value - first.Response.Read.Tick.Value) * fraction) / 120.0;
        if (!double.IsFinite(timeSeconds) || timeSeconds < _simulationTime)
        { Quality = PresentationQuality.AwaitingHistory; return false; }
        var body = Interpolate(first.Response.Read.Ball, last.Response.Read.Ball, fraction);
        selectedBefore = first; selectedAfter = last;
        _displayTimingValid = true; _displayEpoch = _clockEpoch;
        _displayWall = requested; _simulationTime = timeSeconds;
        Quality = LatestAge(now) > StaleNanoseconds ? PresentationQuality.Stale : PresentationQuality.Interpolated;
        sample = new(body, new(requested), new(timeSeconds), Quality);
        return true;
    }

    public long LatestAge(MonotonicNanoseconds now)
    {
        if (_latest < 0 || _entries[_latest].Mapped is not { } mapped) return long.MaxValue;
        var age = (Int128)now.Value - mapped.BrowserInterval.Lower;
        return age > long.MaxValue ? long.MaxValue : (long)Int128.Max(0, age);
    }

    private static PresentedBody? Pose(CanonicalBody? body) =>
        body is { } value ? new(value.Id, value.Cell, value.Local) : null;

    public static PresentedBody? Interpolate(CanonicalBody? from, CanonicalBody? to, double fraction)
    {
        if (!double.IsFinite(fraction) || fraction < 0 || fraction > 1 || (from is null) != (to is null))
            throw new ArgumentException("Invalid presentation interpolation.");
        if (from is not { } first || to is not { } last) return null;
        first.Validate(); last.Validate();
        if (first.Id != last.Id || first.Epoch != last.Epoch || first.Cell.X != last.Cell.X || first.Cell.Z != last.Cell.Z ||
            !HalfBits.Equal(first.Local.X, last.Local.X) || !HalfBits.Equal(first.Local.Z, last.Local.Z))
            throw new ArgumentException("Incompatible vertical pose endpoints.");
        if (fraction == 0) return Pose(first);
        if (fraction == 1) return Pose(last);
        var relative = (double)first.Local.Y +
            (((long)last.Cell.Y - first.Cell.Y) + (double)last.Local.Y - (double)first.Local.Y) * fraction;
        var carry = checked((int)Math.Floor(relative + .5));
        var local = (Half)(relative - carry);
        // Half rounding itself may reach+.5; normalize the rounded output once more.
        if (local >= (Half).5) { carry++; local = (Half)((double)local - 1); }
        return new(first.Id, new(first.Cell.X, checked(first.Cell.Y + carry), first.Cell.Z),
            new(first.Local.X, local, first.Local.Z));
    }

    private static bool SameBody(CanonicalBody? first, CanonicalBody? second) =>
        first is null ? second is null : second is { } b && first.Value.Id == b.Id &&
            first.Value.Epoch == b.Epoch && first.Value.Tick == b.Tick && first.Value.Cell == b.Cell &&
            HalfBits.Equal(first.Value.Local, b.Local) && HalfBits.Equal(first.Value.Velocity.X, b.Velocity.X) &&
            HalfBits.Equal(first.Value.Velocity.Y, b.Velocity.Y) && HalfBits.Equal(first.Value.Velocity.Z, b.Velocity.Z);

    public void Retire()
    {
        Array.Clear(_entries); _count = _next = 0; _latest = _terminal = -1; _dirty = false; _retired = true;
        Quality = PresentationQuality.Retired;
    }
}
