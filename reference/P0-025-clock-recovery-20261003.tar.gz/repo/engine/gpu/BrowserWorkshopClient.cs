using System;
using System.Buffers.Binary;
using System.Runtime.InteropServices.JavaScript;
using System.Threading.Tasks;

namespace CuriousContraptions.Gpu;

public readonly record struct WorkshopClientId(int Value);
public sealed class WorkshopTransportException(WorkshopCommandIdentity identity, WorkshopTransportState state, Exception cause)
    : Exception("Workshop operation is indeterminate; recovery may require page reload.", cause)
{
    public WorkshopCommandIdentity Identity { get; } = identity;
    public WorkshopTransportState State { get; } = state;
}

/// <summary>Main-thread transport only; canonical state and numerical decisions remain in the worker.</summary>
public sealed partial class BrowserWorkshopClient : IWorkshopClient
{
    private WorkshopClientId _id;
    private readonly WorkshopClockPeer _peer;
    private readonly WorkshopClockMapping _clock;
    private readonly WorkshopPoseHistory _history = new();
    private WorkshopConstruction _construction = new(new(1), null);
    private ulong _sequence;
    private int _pending;
    private ulong _memorySequence;
    private WorkshopMemoryRequest? _memoryRequest;
    private PublicationSequence _observedPublication;
    private bool _disposed;
    private readonly WorkshopClientCursor _cursor;
    public WorkshopCommandIdentity? Pending { get; private set; }
    public WorkshopTransportState TransportState
    {
        get
        {
            if (_disposed) return WorkshopTransportState.RecoveryBlocked;
            var state = (WorkshopTransportState)Status(_id.Value);
            if (!Enum.IsDefined(state)) throw new ArgumentException("Unknown transport state.");
            return state;
        }
    }
    public SimulationEpoch Epoch => _cursor.Epoch;
    public AuthorityRevision Revision => _cursor.Revision;
    private BrowserWorkshopClient(WorkshopClockPeer peer)
    {
        _peer = peer; _clock = new(peer); _cursor = new(peer.Session);
    }

    [JSImport("now", "workshopClient")]
    private static partial double NativeMilliseconds();
    [JSImport("probe", "workshopClient")]
    private static partial void SendProbe(int client, byte[] probe);
    [JSImport("acceptedClockReply", "workshopClient")]
    private static partial void AcceptedClockReply(int client);
    [JSImport("clockObservation", "workshopClient")]
    private static partial void RecordClockObservation(int client, byte[] observation);
    [JSImport("presentationObservation", "workshopClient")]
    private static partial void RecordPresentationObservation(int client, byte[] observation);

    [JSImport("create", "workshopClient")]
    private static partial Task<int> CreateClient(int[] states, byte[] bootstrap, int captureMode,
        [JSMarshalAs<JSType.Function>] Action clockReply,
        [JSMarshalAs<JSType.Function>] Action physicalRead,
        [JSMarshalAs<JSType.Function>] Action service,
        [JSMarshalAs<JSType.Function>] Action beginMemory,
        [JSMarshalAs<JSType.Function>] Action receiveMemory,
        [JSMarshalAs<JSType.Function>] Action releaseMemory);
    [JSImport("activate", "workshopClient")]
    private static partial void ActivateClient(int client);
    [JSImport("sendMemoryRequest", "workshopClient")]
    private static partial void SendMemoryRequest(int client, byte[] request);
    [JSImport("completeMemoryObservation", "workshopClient")]
    private static partial void CompleteMemoryObservation(int client, byte[] result);
    [JSImport("eventBytes", "workshopClient")]
    private static partial byte[] EventBytes(int client);
    [JSImport("eventMilliseconds", "workshopClient")]
    private static partial double EventMilliseconds(int client);
    [JSImport("qualified", "workshopClient")]
    private static partial void Qualified(int client);
    [JSImport("status", "workshopClient")]
    private static partial int Status(int client);
    [JSImport("send", "workshopClient")]
    private static partial Task Send(int client, byte[] command);
    [JSImport("acknowledgement", "workshopClient")]
    private static partial byte[] Acknowledgement(int client, byte[] sequence);
    [JSImport("dispose", "workshopClient")]
    private static partial void DisposeClient(int client);

    public static async Task<BrowserWorkshopClient> Create()
    {
        if (!OperatingSystem.IsBrowser())
            throw new PlatformNotSupportedException("This Workshop requires Chrome WebGPU with shader-f16.");
        using var document = JSHost.GlobalThis.GetPropertyAsJSObject("document")
            ?? throw new InvalidOperationException("A browser document is required.");
        var baseUri = document.GetPropertyAsString("baseURI")
            ?? throw new InvalidOperationException("The document resource origin is unavailable.");
        await JSHost.ImportAsync("workshopClient", new Uri(new Uri(baseUri), "workshop-client.js").AbsoluteUri);
        var identity = new byte[16];
        System.Security.Cryptography.RandomNumberGenerator.Fill(identity);
        var peer = new WorkshopClockPeer(WorkshopWire.ReadSession(identity), new(1), new(100_000));
        var client = new BrowserWorkshopClient(peer);
        client._id = new(await CreateClient([(int)WorkshopTransportState.Ready, (int)WorkshopTransportState.Backpressure,
            (int)WorkshopTransportState.TimedOut, (int)WorkshopTransportState.Indeterminate, (int)WorkshopTransportState.RecoveryBlocked],
            WorkshopClockWire.EncodePeer(peer), (int)WorkshopBuild.CaptureMode, client.ReceiveClockReply, client.ReceiveRead,
            client.Service, client.BeginMemory, client.ReceiveMemory, client.ReleaseMemory));
        try
        {
            ActivateClient(client._id.Value);
            var initialized = await client.Execute(WorkshopCommandKind.Initialize);
            if (initialized.Response.Result.Outcome != WorkshopCommandOutcome.Applied)
                throw new InvalidOperationException("The WebGPU simulation worker could not initialize.");
            while (!client._clock.IsQualified)
            {
                client.ThrowIfTransportFailed();
                await Task.Delay(10);
            }
            Qualified(client._id.Value);
            return client;
        }
        catch { client._disposed = true; client._clock.Retire(); DisposeClient(client._id.Value); throw; }
    }

    public async Task<WorkshopDelivery> Execute(WorkshopCommandKind kind, WorkshopConstruction? construction = null, WorkshopCommandIdentity? target = null)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (_memoryRequest is not null) throw new InvalidOperationException("A stopped memory observation owns this client.");
        if (_pending >= 2) throw new InvalidOperationException("Workshop command queue is full.");
        if (_sequence == ulong.MaxValue) throw new InvalidOperationException("Workshop command sequence is exhausted.");
        var sequence = new CommandSequence(_sequence + 1);
        var revisionKind = kind is WorkshopCommandKind.Reset or WorkshopCommandKind.Cancel or WorkshopCommandKind.Dispose
            ? ExpectedRevisionKind.Any : ExpectedRevisionKind.Exact;
        var command = new WorkshopCommand(sequence, kind, Epoch,
            revisionKind == ExpectedRevisionKind.Any ? default : Revision, construction, target, revisionKind, _peer.Session);
        var bytes = WorkshopWire.Encode(command);
        _sequence = sequence.Value;
        _pending++;
        var dispatchedReadOrder = _cursor.ReadOrder;
        var identity = new WorkshopCommandIdentity(sequence, command.Epoch, command.Revision);
        if (kind != WorkshopCommandKind.Cancel) Pending = identity;
        try
        {
            try { await Send(_id.Value, bytes); }
            catch (Exception error) { throw new WorkshopTransportException(identity, TransportState, error); }
            var encodedIdentity = new byte[8];
            BinaryPrimitives.WriteUInt64LittleEndian(encodedIdentity, sequence.Value);
            var response = WorkshopWire.DecodeResponse(Acknowledgement(_id.Value, encodedIdentity));
            var prepared = _cursor.PrepareAcknowledgement(command, response, dispatchedReadOrder, _disposed);
            if (prepared.Applicable)
            {
                ValidateCommandRead(response, construction, _construction);
                var boundary = response.Result.Outcome == WorkshopCommandOutcome.Applied ? kind switch
                {
                    WorkshopCommandKind.Initialize or WorkshopCommandKind.Construct or WorkshopCommandKind.Reset => PresentationBoundary.Seed,
                    WorkshopCommandKind.Run => PresentationBoundary.Run,
                    _ => PresentationBoundary.Continuous
                } : PresentationBoundary.Continuous;
                WorkshopPoseHistory.Prepared? history = response.Read.Capture is null ? null :
                    PrepareHistory(response, boundary, WorkshopNativeClock.FromMilliseconds(NativeMilliseconds()));
                _cursor.Commit(prepared);
                if (history is { } ready) _history.Commit(ready);
                if (response.Result.Outcome == WorkshopCommandOutcome.Applied && construction is { } admitted)
                    _construction = admitted;
            }
            return new(response, prepared.Applicable);
        }
        finally { _pending--; if (Pending == identity) Pending = null; }
    }

    public Task<WorkshopDelivery> CancelPending()
    {
        var target = Pending ?? throw new InvalidOperationException("No pending operation to cancel.");
        return Execute(WorkshopCommandKind.Cancel, target: target);
    }

    public bool TryRead(out WorkshopResponse response)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        ThrowIfTransportFailed();
        return _history.TryTakeLatest(out response);
    }

    private void Service()
    {
        if (_disposed) return;
        var now = WorkshopNativeClock.FromMilliseconds(NativeMilliseconds());
        _clock.Observe(now);
#if PLAYTEST
        var pending = _clock.Pending;
#endif
        if (_clock.BeginProbe(now) is { } probe)
        {
#if PLAYTEST
            if (pending is { } expired) RecordClockObservation(_id.Value, WorkshopClockWire.EncodeExpiredProbe(expired, _peer, now));
#endif
            SendProbe(_id.Value, WorkshopClockWire.EncodeProbe(probe, _peer));
        }
    }

    private void ReceiveClockReply()
    {
        if (_disposed) return;
        var bytes = EventBytes(_id.Value);
        var milliseconds = EventMilliseconds(_id.Value);
        var received = WorkshopNativeClock.FromMilliseconds(milliseconds);
        ClockReply reply;
        try { reply = WorkshopClockWire.DecodeReply(bytes, _peer, received); }
        catch (ArgumentException)
        {
#if PLAYTEST
            RecordClockObservation(_id.Value, WorkshopClockWire.EncodeRejectedReply(bytes, received));
#endif
            return;
        }
        var observation = _clock.Receive(reply);
        if (observation.Outcome == ClockProbeOutcome.Accepted) AcceptedClockReply(_id.Value);
#if PLAYTEST
        RecordClockObservation(_id.Value, WorkshopClockWire.EncodeObservation(observation, _peer));
#endif
    }

    private void ReceiveRead()
    {
        if (_disposed) return;
        var bytes = EventBytes(_id.Value);
        var milliseconds = EventMilliseconds(_id.Value);
        var response = WorkshopWire.DecodeResponse(bytes);
        var prepared = _cursor.PrepareRead(response);
        if (response.Publication.Value > _observedPublication.Value) _observedPublication = response.Publication;
        if (!prepared.Applicable) return;
        ValidateRead(response.Read, _construction);
        var boundary = response.Phase == WorkshopSimulationPhase.Completed ? PresentationBoundary.Completed : PresentationBoundary.Continuous;
        var history = PrepareHistory(response, boundary, WorkshopNativeClock.FromMilliseconds(milliseconds));
        _cursor.Commit(prepared);
        _history.Commit(history);
    }

    private WorkshopPoseHistory.Prepared PrepareHistory(WorkshopResponse response, PresentationBoundary boundary, MonotonicNanoseconds now)
    {
        MappedCapture? mapped = response.Read.Capture is { } stamp && _clock.TryMap(stamp, now, out var captured) ? captured : null;
        return _history.Prepare(response, mapped, boundary, _clock.DisplayEpoch);
    }

    public bool TryPresent(out WorkshopPresentationSample sample)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        ThrowIfTransportFailed();
        return _history.TryPresent(WorkshopNativeClock.FromMilliseconds(NativeMilliseconds()), _clock, out sample);
    }

    public void RecordPresentation(WorkshopPresentationSample sample, bool selected, PresentationScene scene)
    {
        #if PLAYTEST
        if (_disposed) return;
        RecordPresentationObservation(_id.Value, WorkshopPresentationWire.Encode(sample, selected, scene,
            WorkshopNativeClock.FromMilliseconds(NativeMilliseconds())));
        #endif
    }

    private void BeginMemory()
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        if (_memoryRequest is not null || _pending != 0 || TransportState != WorkshopTransportState.Ready ||
            !WorkshopMemoryWire.IsStopped(_cursor.Phase))
            throw new InvalidOperationException("Memory observation requires a stopped, idle client.");
        if (_memorySequence == ulong.MaxValue) throw new InvalidOperationException("Memory observation identity exhausted.");
        var request = new WorkshopMemoryRequest(WorkshopMemoryKind.PostGc, WorkshopMemoryContext.Simulation,
            _peer.Session, new(++_memorySequence), Epoch, Revision, _observedPublication);
        _memoryRequest = request;
        SendMemoryRequest(_id.Value, WorkshopMemoryWire.Encode(request));
    }

    private void ReceiveMemory()
    {
        var request = _memoryRequest ?? throw new InvalidOperationException("No stopped observation is owned.");
        var result = WorkshopMemoryWire.DecodeResult(EventBytes(_id.Value));
        if (_disposed || result.Request != request) throw new ArgumentException("Memory result belongs to another observation.");
        if (result.Status != WorkshopMemoryStatus.Accepted) return;
        if (_pending != 0 || TransportState != WorkshopTransportState.Ready || !WorkshopMemoryWire.IsStopped(_cursor.Phase) ||
            request.Epoch != Epoch || request.Revision != Revision || request.Publication != _observedPublication)
            throw new InvalidOperationException("Stopped observation lost its committed identity.");
        var browser = WorkshopMemoryWire.Capture(request with { Context = WorkshopMemoryContext.Browser });
        CompleteMemoryObservation(_id.Value, WorkshopMemoryWire.Encode(browser));
    }

    private void ReleaseMemory() => _memoryRequest = null;

    private void ThrowIfTransportFailed()
    {
        if (TransportState is WorkshopTransportState.Indeterminate or WorkshopTransportState.RecoveryBlocked)
            throw new InvalidOperationException("Worker session is unavailable; its unacknowledged operations remain indeterminate.");
    }

    internal static void ValidateCommandRead(WorkshopResponse response, WorkshopConstruction? proposed, WorkshopConstruction current) =>
        ValidateRead(response.Read, response.Result.Outcome == WorkshopCommandOutcome.Applied ? proposed ?? current : current);

    private static void ValidateRead(WorkshopRead read, WorkshopConstruction construction)
    {
        if (read.Tick.Value > 3600 || (read.Ball is null) != (construction.Ball is null))
            throw new ArgumentException("Read does not own the admitted construction.");
        if (read.Ball is not { } body || construction.Ball is not { } ball) return;
        body.Validate();
        if (body.Id != ball.Id || body.Epoch != read.Epoch.Value || body.Tick != read.Tick.Value ||
            body.Cell.X != ball.Cell.X || body.Cell.Z != ball.Cell.Z ||
            !HalfBits.Equal(body.Local.X, ball.Local.X) || !HalfBits.Equal(body.Local.Z, ball.Local.Z) ||
            (read.Tick.Value == 0 && (body.Cell != ball.Cell || !HalfBits.Equal(body.Local, ball.Local) || !HalfBits.IsPositiveZero(body.Velocity))))
            throw new ArgumentException("Read differs from the admitted canonical construction.");
    }

    public async ValueTask DisposeAsync()
    {
        if (_disposed) return;
        if (_memoryRequest is not null)
        {
            _disposed = true; _clock.Retire(); _history.Retire(); DisposeClient(_id.Value);
            return;
        }
        try
        {
            var disposal = Execute(WorkshopCommandKind.Dispose);
            if (await Task.WhenAny(disposal, Task.Delay(1000)) == disposal) await disposal;
            else _ = disposal.ContinueWith(task => { _ = task.Exception; }, TaskContinuationOptions.OnlyOnFaulted);
        }
        finally { _disposed = true; _clock.Retire(); _history.Retire(); DisposeClient(_id.Value); }
    }
}
