using System;
using System.Buffers.Binary;
using System.Globalization;

namespace CuriousContraptions.Gpu;

public enum WorkshopGpuOperation { Admit, Advance }
public enum WorkshopBodyMotion : uint { Flying, Resting }
public enum WorkshopRootPredicate : uint { Contact, Region, Apex }
public enum WorkshopLawVersion : uint { LocalQuadraticResponse = 2 }
public enum WorkshopLawFailure : uint
{
    None, InvalidDescriptor, Domain, Bound, RootBudget, RepeatedImpact,
    PositiveImpact, NonFinite, NegativeAscending
}

/// <summary>
/// Sole primary launch parameter: the material-scaled polynomial derivative coefficient.
/// Its scale is inherited from the local polynomial; canonical Body velocity units do not change.
/// Only WGSL converts this physical response to the segment law's launch speed.
/// </summary>
public readonly record struct WorkshopMaterialResponse(Half Value)
{
    public static Half Maximum => (Half)2.1328125;
    public static Half WorldFactor => (Half)3.75;
    public void Validate()
    {
        if (!Half.IsFinite(Value) || Value < (Half)0 || Value > Maximum)
            throw new ArgumentException("Unsupported Basketball material-response coefficient.");
    }
}

public sealed class WorkshopNumericalException : InvalidOperationException
{
    public WorkshopLawFailure Failure { get; }
    public WorkshopNumericalException(WorkshopLawFailure failure)
        : base("GPU numerical candidate failed before commit.")
    {
        if (!Enum.IsDefined(failure) || failure == WorkshopLawFailure.None)
            throw new ArgumentException("Undefined numerical failure.", nameof(failure));
        Failure = failure;
    }
}

/// <summary>Explicit little-endian WebGPU boundary. The final 48 bytes are the current GPU-owned segment law descriptor.</summary>
public static class WorkshopGpuAbi
{
    public const int ByteLength = 128;
    public const int BodyCountOffset = 100;
    public const int LawVersionOffset = 112;
    public const int LawFailureOffset = 116;
    public static byte[] Admission(WorkshopConstruction construction, SimulationEpoch epoch)
    {
        construction.Validate();
        if (epoch.Value == 0) throw new ArgumentException("GPU world epoch must be nonzero.");
        var body = construction.Ball is { } ball
            ? new CanonicalBody(ball.Id, epoch.Value, 0, ball.Cell, ball.Local, default)
            : new CanonicalBody(new(1), epoch.Value, 0, default, default, default);
        var bytes = new byte[ByteLength];
        body.Write(bytes.AsSpan(0, CanonicalBody.ByteLength));
        BinaryPrimitives.WriteInt32LittleEndian(bytes.AsSpan(96), body.Cell.Y);
        BinaryPrimitives.WriteUInt16LittleEndian(bytes.AsSpan(94), BitConverter.HalfToUInt16Bits(body.Local.Y));
        BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(LawVersionOffset), (uint)WorkshopLawVersion.LocalQuadraticResponse);
        BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(BodyCountOffset), construction.Ball is null ? 0u : 1u);
        return bytes;
    }

    public static WorkshopRead Read(ReadOnlySpan<byte> bytes)
    {
        if (bytes.Length != ByteLength) throw new ArgumentException("Unsupported Workshop GPU record length.");
        var body = CanonicalBody.Decode(bytes[..CanonicalBody.ByteLength]);
        var count = BinaryPrimitives.ReadUInt32LittleEndian(bytes[BodyCountOffset..]);
        if (count > 1) throw new ArgumentException("Unsupported Workshop body count.");
        ValidateDescriptor(bytes, body, count);
        return new(new(body.Epoch), new(body.Tick), count == 0 ? null : body);
    }

    public static WorkshopLawFailure ReadFailure(ReadOnlySpan<byte> bytes)
    {
        if (bytes.Length != ByteLength) throw new ArgumentException("Unsupported Workshop GPU record length.");
        var version = (WorkshopLawVersion)BinaryPrimitives.ReadUInt32LittleEndian(bytes[LawVersionOffset..]);
        var failure = (WorkshopLawFailure)BinaryPrimitives.ReadUInt32LittleEndian(bytes[LawFailureOffset..]);
        if (version != WorkshopLawVersion.LocalQuadraticResponse || !Enum.IsDefined(failure))
            throw new ArgumentException("Unsupported Workshop law version or failure.");
        return failure;
    }

    private static void ValidateDescriptor(ReadOnlySpan<byte> bytes, CanonicalBody body, uint count)
    {
        var response = new WorkshopMaterialResponse(ReadHalf(bytes[82..]));
        response.Validate();
        var start = BinaryPrimitives.ReadUInt32LittleEndian(bytes[88..]);
        var phase = ReadHalf(bytes[92..]);
        var initialLocal = ReadHalf(bytes[94..]);
        var initialCell = BinaryPrimitives.ReadInt32LittleEndian(bytes[96..]);
        var contacts = BinaryPrimitives.ReadUInt32LittleEndian(bytes[104..]);
        var motion = (WorkshopBodyMotion)BinaryPrimitives.ReadUInt32LittleEndian(bytes[108..]);
        var endOrdinal = body.Tick * 4;
        if (ReadFailure(bytes) != WorkshopLawFailure.None ||
            body.Epoch == 0 || body.Tick > 3600 || !Enum.IsDefined(motion) ||
            start > endOrdinal || contacts > endOrdinal ||
            !Half.IsFinite(phase) || phase < (Half)(-2048) || phase >= (Half)2048 ||
            (start == endOrdinal && phase > (Half)0) ||
            !Half.IsFinite(initialLocal) || initialLocal < (Half)(-0.5) || initialLocal >= (Half)0.5 ||
            initialCell < -1024 || initialCell > 1024 ||
            BinaryPrimitives.ReadUInt16LittleEndian(bytes[86..]) != 0 ||
            BinaryPrimitives.ReadUInt32LittleEndian(bytes[120..]) != 0 ||
            BinaryPrimitives.ReadUInt32LittleEndian(bytes[124..]) != 0 ||
            !HalfBits.Equal(ReadHalf(bytes[80..]), (Half)0) || !HalfBits.Equal(ReadHalf(bytes[84..]), (Half)0) ||
            !HalfBits.Equal(body.Velocity.X, (Half)0) || !HalfBits.Equal(body.Velocity.Z, (Half)0))
            throw new ArgumentException("Unsupported Workshop trajectory descriptor.");
        if (count == 1 && (!AdmittedAxis(body.Cell.X, body.Local.X, 112) ||
            !AdmittedAxis(body.Cell.Z, body.Local.Z, 64)))
            throw new ArgumentException("Body is outside the admitted finite deck.");
        if (count == 0)
        {
            if (body.Id.Value != 1 || body.Cell != default || !HalfBits.Equal(body.Local, default) ||
                !HalfBits.IsPositiveZero(body.Velocity) || !HalfBits.Equal(response.Value, (Half)0) ||
                start != 0 || !HalfBits.Equal(phase, (Half)0) || contacts != 0 ||
                motion != WorkshopBodyMotion.Flying || initialCell != 0 ||
                !HalfBits.Equal(initialLocal, (Half)0))
                throw new ArgumentException("Empty workbench contains a physical descriptor.");
            return;
        }
        if (contacts == 0)
        {
            if (initialCell < 0 || initialCell > 144 ||
                (initialCell == 0 && initialLocal < (Half)0) ||
                (initialCell == 144 && initialLocal > (Half)0) ||
                !HalfBits.Equal(response.Value, (Half)0) || start != 0 ||
                !HalfBits.Equal(phase, (Half)0) || motion != WorkshopBodyMotion.Flying ||
                (body.Tick == 0 && (body.Cell.Y != initialCell ||
                    !HalfBits.Equal(body.Local.Y, initialLocal) || !HalfBits.IsPositiveZero(body.Velocity))))
                throw new ArgumentException("Invalid initial Basketball segment.");
        }
        else
        {
            var support = Support();
            if (initialCell != support.Cell.Y || !HalfBits.Equal(initialLocal, support.Local.Y) ||
                (motion == WorkshopBodyMotion.Flying && response.Value <= (Half)0))
                throw new ArgumentException("Contact segment has no canonical support origin.");
        }
        if (motion == WorkshopBodyMotion.Flying &&
            (endOrdinal - start > 960 || (endOrdinal - start == 960 && phase < (Half)0)))
            throw new ArgumentException("Trajectory segment exceeds its finite clock bound.");
        if (motion == WorkshopBodyMotion.Resting &&
            (!HalfBits.IsPositiveZero(body.Velocity) || !HalfBits.Equal(response.Value, (Half)0) ||
             body.Cell.Y != Support().Cell.Y || !HalfBits.Equal(body.Local.Y, Support().Local.Y)))
            throw new ArgumentException("Resting descriptor is not the canonical supported state.");
    }

    private static bool AdmittedAxis(int cell, Half local, int bound) =>
        cell >= -bound && cell <= bound && !(cell == -bound && local < (Half)0) && !(cell == bound && local > (Half)0);

    private static Half ReadHalf(ReadOnlySpan<byte> bytes) =>
        BitConverter.UInt16BitsToHalf(BinaryPrimitives.ReadUInt16LittleEndian(bytes));
    private static WorkshopBall Support()
    {
        var height = (Half)((float)WorkshopConstruction.WorkbenchSurface.Value + (float)BasketballMaterial.Default.Radius.Value);
        return WorkshopInput.Basketball(new(1), 0, (double)height, 0, 0, 0, 0, 1);
    }

    public static string ShaderPreamble()
    {
        var material = BasketballMaterial.Default;
        var support = (Half)((float)WorkshopConstruction.WorkbenchSurface.Value + (float)material.Radius.Value);
        var origin = WorkshopInput.Basketball(new(1), 0, (double)support, 0, 0, 0, 0, 1);
        BasketballLawCoefficients.ValidateProfile(WorkshopConstruction.Gravity.Value, material.Drag.Value,
            support, (Half)(512.0 / 480.0), CellScale.Metres, TimeScale.Seconds);
        return
            $"enable f16;\nconst RECORD_VERSION: u32 = {(uint)BodyRecordVersion.CanonicalHalf}u;\n" +
            $"const COMMITTED: u32 = {(uint)BodyCandidateStatus.Committed}u;\n" +
            $"const INVALID_RECORD: u32 = {(uint)BodyCandidateStatus.InvalidRecord}u;\n" +
            $"const OUT_OF_RANGE: u32 = {(uint)BodyCandidateStatus.OutOfRange}u;\n" +
            $"const ROOT_CONTACT: u32 = {(uint)WorkshopRootPredicate.Contact}u;\n" +
            $"const ROOT_REGION: u32 = {(uint)WorkshopRootPredicate.Region}u;\n" +
            $"const ROOT_APEX: u32 = {(uint)WorkshopRootPredicate.Apex}u;\n" +
            $"const LAW_VERSION: u32 = {(uint)WorkshopLawVersion.LocalQuadraticResponse}u;\n" +
            $"const FAILURE_NONE: u32 = {(uint)WorkshopLawFailure.None}u;\n" +
            $"const FAILURE_INVALID_DESCRIPTOR: u32 = {(uint)WorkshopLawFailure.InvalidDescriptor}u;\n" +
            $"const FAILURE_DOMAIN: u32 = {(uint)WorkshopLawFailure.Domain}u;\n" +
            $"const FAILURE_BOUND: u32 = {(uint)WorkshopLawFailure.Bound}u;\n" +
            $"const FAILURE_ROOT_BUDGET: u32 = {(uint)WorkshopLawFailure.RootBudget}u;\n" +
            $"const FAILURE_REPEATED_IMPACT: u32 = {(uint)WorkshopLawFailure.RepeatedImpact}u;\n" +
            $"const FAILURE_POSITIVE_IMPACT: u32 = {(uint)WorkshopLawFailure.PositiveImpact}u;\n" +
            $"const FAILURE_NONFINITE: u32 = {(uint)WorkshopLawFailure.NonFinite}u;\n" +
            $"const FAILURE_NEGATIVE_ASCENDING: u32 = {(uint)WorkshopLawFailure.NegativeAscending}u;\n" +
            $"const CELL_SCALE: i32 = {(int)CellScale.Metres};\nconst TIME_SCALE: i32 = {(int)TimeScale.Seconds};\n" +
            $"const FLYING: u32 = {(uint)WorkshopBodyMotion.Flying}u;\nconst RESTING: u32 = {(uint)WorkshopBodyMotion.Resting}u;\n" +
            $"const SUPPORT_CELL: i32 = {origin.Cell.Y};\nconst SUPPORT_LOCAL: f16 = {Literal(origin.Local.Y)};\n" +
            $"const DT: f16 = {Literal((Half)(512.0 / 480.0))};\nconst GRAVITY: f16 = {Literal(WorkshopConstruction.Gravity.Value)};\n" +
            $"const DRAG: f16 = {Literal(material.Drag.Value)};\nconst BOUNCE: f16 = {Literal(material.Bounce.Value)};\n" +
            $"const RESPONSE_MAX: f16 = {Literal(WorkshopMaterialResponse.Maximum)};\n" +
            $"const RESPONSE_WORLD_FACTOR: f16 = {Literal(WorkshopMaterialResponse.WorldFactor)};\n" +
            $"const BOUNCE_THRESHOLD: f16 = {Literal((Half)0.1)};\n" +
            BasketballLawCoefficients.ShaderDeclarations();
    }

    private static string Literal(Half value) => ((float)value).ToString("R", CultureInfo.InvariantCulture) + "h";
}
