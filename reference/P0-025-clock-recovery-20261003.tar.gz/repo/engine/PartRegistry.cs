using Godot;
using System;
using System.Collections.Generic;

namespace CuriousContraptions;

public sealed class PartRegistry
{
    private readonly Dictionary<WorkshopPartKind, PartDefinition> _definitions = new();
    public IReadOnlyDictionary<WorkshopPartKind, PartDefinition> Definitions => _definitions;
    public void Discover()
    {
        // Named content boundary: unsupported scene scripts are neither loaded nor shipped.
        var ball = ResourceLoader.Load<PartDefinition>("res://parts/catalog/ball.tres");
        if (ball is null || ball.Scene is null || ball.WorkshopKind != WorkshopPartKind.Basketball ||
            ball.Basketball is null || ball.Parameters.Count != 0)
            throw new ArgumentException("Canonical Basketball resource is invalid.");
        ball.Basketball.Capture();
        _definitions.Clear();
        _definitions.Add(WorkshopPartKind.Basketball, ball);
    }
    public MachinePart Create(WorkshopPartKind kind)
    {
        if (kind != WorkshopPartKind.Basketball || !_definitions.TryGetValue(kind, out var definition))
            throw new ArgumentException("This catalogue part is not supported by the current GPU Workshop.");
        var part = definition.Scene.Instantiate<MachinePart>();
        try { part.Configure(definition); return part; }
        catch { part.Free(); throw; }
    }
}
