#if PLAYTEST
using System.Buffers.Binary;
using CuriousContraptions.Gpu;

namespace CuriousContraptions.Simulation;

// Observational only. All methods contain diagnostic failure; none can reject or change a commit.
internal enum TraceEnd { Complete, Reset, Disposed, DeviceLost, Fault, InvalidRecord, Overflow }
internal sealed class WorkshopTrace
{
    private const int Capacity = 3601;
    private const int ChunkRecords = 128;
    private readonly byte[] _records = new byte[Capacity * WorkshopGpuAbi.ByteLength];
    private ulong _identity;
    private SimulationEpoch _epoch;
    private int _count;
    private bool _active, _sealed;
    private TraceEnd _sealedReason;
    private byte[] _construction = [];
    internal void Begin(RuntimeSessionId session, WorkshopConstruction construction, SimulationEpoch epoch, byte[] record)
    {
        try
        {
            if (_active) End(TraceEnd.Reset);
            // Preserve the preceding capture before this one buffer is reused. No new RunLoop exists yet.
            FlushSealed();
            if (_identity == ulong.MaxValue) return;
            _identity++;
            _epoch = epoch;
            _count = 0;
            _construction = WorkshopWire.Encode(new WorkshopCommand(new(1), WorkshopCommandKind.Construct,
                epoch, default, construction, Session: session));
            _active = true;
            Append(record);
        }
        catch { End(TraceEnd.InvalidRecord); }
    }
    internal void Append(byte[] record)
    {
        if (!_active) return;
        try
        {
            if (_count == Capacity) { End(TraceEnd.Overflow); return; }
            if (record.Length != WorkshopGpuAbi.ByteLength ||
                BinaryPrimitives.ReadUInt64LittleEndian(record.AsSpan(8)) != _epoch.Value ||
                BinaryPrimitives.ReadUInt64LittleEndian(record.AsSpan(16)) != (ulong)_count)
            { End(TraceEnd.InvalidRecord); return; }
            record.CopyTo(_records, _count * WorkshopGpuAbi.ByteLength);
            _count++;
        }
        catch { End(TraceEnd.InvalidRecord); }
    }
    internal void End(TraceEnd reason)
    {
        if (!_active) return;
        _active = false;
        if (reason == TraceEnd.Complete && _count != Capacity) reason = TraceEnd.InvalidRecord;
        _sealedReason = reason;
        _sealed = true;
    }

    internal void Flush(WorkshopSimulationPhase phase)
    {
        // Invalid/overflow captures sealed during Run must not stall an ordinary publication.
        if (phase is WorkshopSimulationPhase.Building or WorkshopSimulationPhase.Completed or
            WorkshopSimulationPhase.Faulted or WorkshopSimulationPhase.Disposed) FlushSealed();
    }

    private void FlushSealed()
    {
        if (!_sealed) return;
        _sealed = false;
        var reason = _sealedReason;
        try
        {
            var chunks = (_count + ChunkRecords - 1) / ChunkRecords;
            // Closed discriminants are serialized numerically at this console boundary.
            Console.WriteLine($"CCGPU_TRACE_BEGIN {_identity} {_epoch.Value} {(uint)BodyRecordVersion.CanonicalHalf} {WorkshopGpuAbi.ByteLength} {_count} {chunks} {(int)reason} {Convert.ToBase64String(_construction)}");
            for (var ordinal = 0; ordinal < chunks; ordinal++)
            {
                var first = ordinal * ChunkRecords;
                var count = Math.Min(ChunkRecords, _count - first);
                var encoded = Convert.ToBase64String(_records, first * WorkshopGpuAbi.ByteLength,
                    count * WorkshopGpuAbi.ByteLength);
                Console.WriteLine($"CCGPU_TRACE_CHUNK {_identity} {ordinal} {chunks} {first} {count} {encoded}");
            }
            Console.WriteLine($"CCGPU_TRACE_END {_identity} {_count} {chunks} {(int)reason}");
        }
        catch { /* Missing end/chunks are an explicit incomplete capture to its consumer. */ }
    }
}
#endif
