using System.Buffers.Binary;
using CuriousContraptions.Gpu;

internal interface IWorkshopGpuTransport
{
    Task Initialize(string preamble);
    Task Stage(byte[] input, WorkshopGpuOperation operation);
    byte[] Read();
    void Commit();
    void Discard();
    bool DeviceReady();
    void Dispose();
}

internal sealed class WorkshopGpuDevice(IWorkshopGpuTransport transport) : IWorkshopGpuDevice
{
    private readonly SemaphoreSlim _gate = new(1, 1);
    private CommandSequence _active;
    private bool _initialized;
    private bool _disposed;
#if PLAYTEST
    private byte[] _diagnosticCandidate = [];
    internal byte[] DiagnosticCommitted { get; private set; } = [];
#endif

    public ValueTask<WorkshopGpuCandidate> Admit(WorkshopConstruction construction, SimulationEpoch epoch, CommandSequence sequence) =>
        Stage(WorkshopGpuAbi.Admission(construction, epoch), WorkshopGpuOperation.Admit, sequence);
    public ValueTask<WorkshopGpuCandidate> Advance(WorkshopRead committed, CommandSequence sequence) =>
        Stage([], WorkshopGpuOperation.Advance, sequence);

    private async ValueTask<WorkshopGpuCandidate> Stage(byte[] input, WorkshopGpuOperation operation, CommandSequence sequence)
    {
        await _gate.WaitAsync();
        try
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            if (_active.Value != 0 || sequence.Value == 0) throw new InvalidOperationException("Invalid GPU candidate ownership.");
            _active = sequence;
            if (!_initialized)
            {
                await transport.Initialize(WorkshopGpuAbi.ShaderPreamble());
                ObjectDisposedException.ThrowIf(_disposed, this);
                _initialized = true;
            }
            await transport.Stage(input, operation);
            ObjectDisposedException.ThrowIf(_disposed, this);
            var bytes = transport.Read();
            if (bytes.Length != WorkshopGpuAbi.ByteLength) throw new ArgumentException("Invalid GPU candidate length.");
            var failure = WorkshopGpuAbi.ReadFailure(bytes);
            var status = (BodyCandidateStatus)BinaryPrimitives.ReadUInt32LittleEndian(bytes.AsSpan(4));
            if (!Enum.IsDefined(status)) throw new ArgumentException("Unknown GPU candidate status.");
            if (status != BodyCandidateStatus.Committed)
            {
                if (failure == WorkshopLawFailure.None) throw new ArgumentException("Rejected GPU candidate has no failure.");
                if (operation == WorkshopGpuOperation.Admit)
                    throw new GpuAdmissionException("Construction is outside the admitted Basketball/workbench profile.");
                throw new WorkshopNumericalException(failure);
            }
            var read = WorkshopGpuAbi.Read(bytes);
#if PLAYTEST
            _diagnosticCandidate = bytes;
#endif
            return new(sequence, read);
        }
        catch
        {
            _initialized = !_disposed && transport.DeviceReady();
            _active = default;
            transport.Discard();
            _gate.Release();
            throw;
        }
    }
    public void MarkLost() => _initialized = false;
    public void Commit(CommandSequence sequence)
    {
        if (_disposed || _active != sequence || sequence.Value == 0)
            throw new InvalidOperationException("GPU candidate is not owned by this command.");
        transport.Commit();
#if PLAYTEST
        DiagnosticCommitted = _diagnosticCandidate;
#endif
    }
    public void Discard(CommandSequence sequence)
    {
        if (_active != sequence || sequence.Value == 0) return;
        _active = default;
#if PLAYTEST
        _diagnosticCandidate = [];
#endif
        if (!_disposed) transport.Discard();
        _gate.Release();
    }
    public ValueTask DisposeAsync()
    {
        if (_disposed) return ValueTask.CompletedTask;
        _disposed = true;
        transport.Dispose();
        return ValueTask.CompletedTask;
    }
}
