using System;
using Godot;
using CuriousContraptions.Presentation;

namespace CuriousContraptions;

/// <summary>Closed identities for the controls used by presentation integration.
/// Node names are an explicit Godot/automation boundary, never behaviour selectors.</summary>
public enum WorkshopAnimationControl { Hint, ShowHint, Goal, Run, LevelPicker, Menu }

public static class WorkshopAnimationControlBoundary
{
    public static string NodeName(WorkshopAnimationControl control)=>control switch
    {
        WorkshopAnimationControl.Hint=>"PuzzleHint",
        WorkshopAnimationControl.ShowHint=>"ShowHint",
        WorkshopAnimationControl.Goal=>"Goal",
        WorkshopAnimationControl.Run=>"RunMachine",
        WorkshopAnimationControl.LevelPicker=>"LevelPicker",
        WorkshopAnimationControl.Menu=>"Menu",
        _=>throw new ArgumentOutOfRangeException(nameof(control))
    };
}

/// <summary>Browser target application for the portable animation owner; no second hint evaluator.</summary>
public partial class Workshop
{
    private static readonly AnimationTargetId HintTarget = new(1); // Semantic UI declaration, never a slot or wire identity.
    private static readonly AnimationDefinition HintReveal = new(
        new AnimationValue(new AnimationOpacity((Half)0)),
        new AnimationValue(new AnimationOpacity((Half)1)),
        new AnimationDurationSeconds((Half).16), AnimationCurve.SmoothStep,
        AnimationRepeat.Once, AnimationClock.Presentation);
    private readonly AnimationBatch _hintAnimations = new(1);
    private AnimationHandle? _hintAnimation;
    private double _hintPresentationTime; // External presentation clock.
    private ulong _hintFrame;
    private bool _hintAnimationVisible;

    private void InitializeUiAnimations() => ResetUiAnimations();
    private void RevealHint()
    {
        if (!_hint.IsInsideTree()) return;
        ResetUiAnimations();
        var handle = _hintAnimations.Register(new(HintTarget,AnimationProperty.Opacity),HintReveal);
        _hintAnimations.StartAt(handle,_hintPresentationTime);
        _hintAnimation=handle;
        _hintAnimationVisible=_hint.IsVisibleInTree();
        _hintAnimations.SetVisible(handle,_hintAnimationVisible);
        ApplyHintOpacity(_hintAnimations.Read(handle).Value.Opacity);
    }
    private void HideHint()
    {
        ResetUiAnimations();
        _hint.Visible = false;
    }
    private void ResetUiAnimations()
    {
        // This sole-target UI lifetime owns its generation and external clock.
        // Reset preflights generation exhaustion before any local handle/baseline mutation.
        _hintAnimations.Reset();
        _hintAnimation=null;
        _hintPresentationTime=0;_hintFrame=0;_hintAnimationVisible=false;
        ApplyHintOpacity(new((Half)1));
    }
    private void PresentUiAnimations(double delta)
    {
        if (!double.IsFinite(delta) || delta < 0) throw new ArgumentOutOfRangeException(nameof(delta));
        if (!_hint.IsInsideTree() || _hintAnimation is not { } handle) return;
        var visible=_hint.IsVisibleInTree();
        if(_hintAnimations.ScheduledCount==0 && visible==_hintAnimationVisible)return;
        var time=_hintPresentationTime+delta;
        if(!double.IsFinite(time))throw new ArgumentOutOfRangeException(nameof(delta));
        var frame=checked(_hintFrame+1);
        if(visible!=_hintAnimationVisible)_hintAnimations.SetVisible(handle,visible);
        _hintAnimations.Advance(frame,time,0);
        _hintPresentationTime=time;_hintFrame=frame;_hintAnimationVisible=visible;
        foreach(var sample in _hintAnimations.Samples)
        {
            if(sample.Binding.Target!=HintTarget||sample.Binding.Property!=AnimationProperty.Opacity)
                throw new InvalidOperationException("Unexpected hint animation target.");
            ApplyHintOpacity(sample.Value.Opacity);
        }
    }
    private void ApplyHintOpacity(AnimationOpacity opacity)
    {
        var color = _hint.Modulate;
        color.A = (float)opacity.Value; // Named Godot presentation adapter.
        _hint.Modulate = color;
    }
    private void RemoveUiAnimations() => ResetUiAnimations();
}
