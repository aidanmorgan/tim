using Godot;
using CuriousContraptions.Gpu;
using System;
using System.Threading.Tasks;

namespace CuriousContraptions;

public partial class Workshop
{
    private async Task<bool> SubmitConstruction(WorkshopBall? ball)
    {
        if (!CanEdit) return false;
        _gpuPending = true;
        _state.Text = "CHECKING PLACEMENT";
        RefreshPalette();
        try
        {
            var result = await World.ReplaceConstruction(ball);
            if (_workshopUiRemoved) return false;
            if (!result.Applicable) return false;
            if (result.Result.Outcome != WorkshopCommandOutcome.Applied)
            {
                _status.Text = $"Placement rejected: {result.Result.Reason}";
                World.RestoreConstructionPresentation();
                return false;
            }
            _state.Text = "BUILD MODE";
            return true;
        }
        catch (Exception error)
        {
            if (_workshopUiRemoved) return false;
            World.RestoreConstructionPresentation();
            _status.Text = error.Message;
            return false;
        }
        finally { if (!_workshopUiRemoved) { _gpuPending = false; RefreshPalette(); RefreshLayers(); } }
    }

    private async void CommitSelected()
    {
        if (!CanEdit || _selected is null || World.Construction.Ball is not { } prior) return;
        try
        {
            var proposed = World.CaptureBasketball(prior.Id, _selected.Position, _selected.Quaternion);
            // Live pointer motion is an input preview, never retained canonical construction.
            World.RestoreConstructionPresentation();
            var accepted = await SubmitConstruction(proposed);
            if (!_workshopUiRemoved && !accepted && _undo.Count > 0) _undo.RemoveAt(_undo.Count - 1);
        }
        catch (Exception error) { if (_workshopUiRemoved) return; World.RestoreConstructionPresentation(); _status.Text = error.Message; }
    }
}
