using CuriousContraptions.Gpu;

namespace CuriousContraptions.Tests;

// Exercises the production C# device owner with a held external transport, never a numerical substitute.
public sealed class WorkshopGpuDeviceTests
{
    [Theory]
    [InlineData(true)]
    [InlineData(false)]
    public async Task DisposeDuringQualificationOrReadbackCannotStageOrCommitLateCandidate(bool duringQualification)
    {
        var transport = new HeldTransport(duringQualification);
        var device = new WorkshopGpuDevice(transport);
        var pending = device.Admit(new(new(1), null), new(1), new(1)).AsTask();
        Assert.False(pending.IsCompleted);
        await device.DisposeAsync();
        await device.DisposeAsync();
        transport.Held.SetResult();
        await Assert.ThrowsAsync<ObjectDisposedException>(() => pending);
        Assert.Equal(1, transport.Disposals);
        Assert.Equal(duringQualification ? 0 : 1, transport.Stages);
        Assert.Equal(0, transport.Reads);
        Assert.Equal(0, transport.Commits);
        await Assert.ThrowsAsync<ObjectDisposedException>(() =>
            device.Admit(new(new(1), null), new(1), new(2)).AsTask());
        Assert.Equal(0, transport.Commits);
    }

    [Fact]
    public async Task ActualAdapterRejectsMalformedDescriptorBeforeCommit()
    {
        var transport = new HeldTransport(false);
        var device = new WorkshopGpuDevice(transport);
        var pending = device.Admit(new(new(1), null), new(1), new(1)).AsTask();
        transport.Record[120] = 1;
        transport.Held.SetResult();
        await Assert.ThrowsAsync<ArgumentException>(() => pending);
        Assert.Equal(0, transport.Commits);
        Assert.Equal(1, transport.Reads);
        await device.DisposeAsync();
    }

    [Fact]
    public async Task TypedNumericalFailureDiscardsCandidateAndReleasesOwnedGate()
    {
        var transport = new HeldTransport(false);
        var device = new WorkshopGpuDevice(transport);
        transport.Record[4] = (byte)BodyCandidateStatus.InvalidRecord;
        transport.Record[WorkshopGpuAbi.LawFailureOffset] = (byte)WorkshopLawFailure.RootBudget;
        var pending = device.Advance(new(new(1), new(0), null), new(1)).AsTask();
        transport.Held.SetResult();
        var failure = await Assert.ThrowsAsync<WorkshopNumericalException>(() => pending);
        Assert.Equal(WorkshopLawFailure.RootBudget, failure.Failure);
        Assert.Equal(0, transport.Commits);
        Assert.Equal(1, transport.Discards);
        transport.Record[4] = (byte)BodyCandidateStatus.Committed;
        transport.Record[WorkshopGpuAbi.LawFailureOffset] = (byte)WorkshopLawFailure.None;
        var next = await device.Admit(new(new(1), null), new(1), new(2));
        device.Commit(next.Sequence);
        device.Discard(next.Sequence);
        Assert.Equal(1, transport.Commits);
        Assert.Equal(2, transport.Discards);
        await device.DisposeAsync();
    }

    [Fact]
    public async Task UnknownFailureCannotBecomeACommittedRead()
    {
        var transport = new HeldTransport(false);
        var device = new WorkshopGpuDevice(transport);
        transport.Record[WorkshopGpuAbi.LawFailureOffset] = byte.MaxValue;
        var pending = device.Admit(new(new(1), null), new(1), new(1)).AsTask();
        transport.Held.SetResult();
        await Assert.ThrowsAsync<ArgumentException>(() => pending);
        Assert.Equal(0, transport.Commits);
        Assert.Equal(1, transport.Discards);
        await device.DisposeAsync();
    }

    private sealed class HeldTransport(bool holdInitialization) : IWorkshopGpuTransport
    {
        public TaskCompletionSource Held { get; } = new();
        public byte[] Record { get; } = WorkshopGpuAbi.Admission(new(new(1), null), new(1));
        public int Stages, Reads, Commits, Disposals, Discards;
        public Task Initialize(string preamble) => holdInitialization ? Held.Task : Task.CompletedTask;
        public Task Stage(byte[] input, WorkshopGpuOperation operation) { Stages++; return Held.Task; }
        public byte[] Read() { Reads++; return Record; }
        public void Commit() => Commits++;
        public void Discard() => Discards++;
        public bool DeviceReady() => Disposals == 0;
        public void Dispose() => Disposals++;
    }
}
