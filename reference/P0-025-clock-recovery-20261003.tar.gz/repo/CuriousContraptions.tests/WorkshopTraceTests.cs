#if PLAYTEST
using System.Buffers.Binary;
using System.Globalization;
using CuriousContraptions.Gpu;
using CuriousContraptions.Simulation;

namespace CuriousContraptions.Tests;

// Exercises the actual diagnostic recorder and wire boundary, never numerical GPU behavior.
public sealed class WorkshopTraceTests
{
    private static readonly RuntimeSessionId Session = new(0x20000000000001, ulong.MaxValue);
    private static readonly WorkshopConstruction Construction = new(new(7),
        WorkshopInput.Basketball(new(3), 0, 8.875, 0, 0, 0, 0, 1));

    [Fact]
    public void CompleteCapturePreservesSessionConstructionAndEveryOriginalRecord()
    {
        using var output = new CapturedConsole();
        var trace = new WorkshopTrace();
        var record = WorkshopGpuAbi.Admission(Construction, new(9));
        var expected = new byte[3601 * WorkshopGpuAbi.ByteLength];
        trace.Begin(Session, Construction, new(9), record);
        record.CopyTo(expected, 0);
        for (ulong tick = 1; tick <= 3600; tick++)
        {
            BinaryPrimitives.WriteUInt64LittleEndian(record.AsSpan(16), tick);
            record.CopyTo(expected, checked((int)tick * WorkshopGpuAbi.ByteLength));
            trace.Append(record);
        }
        var finalRecord = (byte[])record.Clone();
        trace.End(TraceEnd.Complete);
        Assert.Empty(output.Lines);
        trace.Flush(WorkshopSimulationPhase.Completed);
        trace.Flush(WorkshopSimulationPhase.Completed);
        var lines = output.Lines;
        Assert.Equal(31, lines.Length);
        var header = lines[0].Split(' ');
        Assert.Equal("CCGPU_TRACE_BEGIN", header[0]);
        Assert.Equal(9UL, Number(header[2]));
        Assert.Equal(3601UL, Number(header[5]));
        Assert.Equal(29UL, Number(header[6]));
        Assert.Equal(TraceEnd.Complete, Reason(header[7]));
        var construction = WorkshopWire.DecodeCommand(Convert.FromBase64String(header[8]));
        Assert.Equal(Session, construction.Session);
        Assert.Equal(Construction, construction.Construction);
        Assert.Equal(new SimulationEpoch(9), construction.Epoch);
        var observed = new List<byte>(expected.Length);
        for (var ordinal = 0; ordinal < 29; ordinal++)
        {
            var fields = lines[ordinal + 1].Split(' ');
            Assert.Equal("CCGPU_TRACE_CHUNK", fields[0]);
            Assert.Equal(header[1], fields[1]);
            Assert.Equal((ulong)ordinal, Number(fields[2]));
            Assert.Equal(29UL, Number(fields[3]));
            Assert.Equal((ulong)(ordinal * 128), Number(fields[4]));
            var count = Math.Min(128, 3601 - ordinal * 128);
            Assert.Equal((ulong)count, Number(fields[5]));
            var bytes = Convert.FromBase64String(fields[6]);
            Assert.Equal(count * WorkshopGpuAbi.ByteLength, bytes.Length);
            observed.AddRange(bytes);
        }
        Assert.Equal(expected, observed.ToArray());
        Assert.Equal(finalRecord, record);
        Assert.Equal($"CCGPU_TRACE_END {header[1]} 3601 29 0", lines[^1]);
        trace.Append(record);
        trace.End(TraceEnd.Reset);
        trace.Flush(WorkshopSimulationPhase.Building);
        Assert.Equal(31, output.Lines.Length);
    }

    [Fact]
    public void InvalidSessionCannotStartOrContaminateTheNextRun()
    {
        using var output = new CapturedConsole();
        var trace = new WorkshopTrace();
        var record = WorkshopGpuAbi.Admission(Construction, new(9));
        trace.Begin(default, Construction, new(9), record);
        trace.Append(record);
        trace.End(TraceEnd.Complete);
        trace.Flush(WorkshopSimulationPhase.Completed);
        Assert.Empty(output.Lines);
        trace.Begin(Session, Construction, new(9), record);
        trace.End(TraceEnd.Reset);
        trace.Flush(WorkshopSimulationPhase.Building);
        Assert.Equal(3, output.Lines.Length);
        var header = output.Lines[0].Split(' ');
        Assert.Equal(TraceEnd.Reset, Reason(header[7]));
        Assert.Equal(Session, WorkshopWire.DecodeCommand(Convert.FromBase64String(header[8])).Session);
    }

    [Fact]
    public void RestartClosesThePreviousPartialCaptureBeforeTheNewSession()
    {
        using var output = new CapturedConsole();
        var trace = new WorkshopTrace();
        trace.Begin(Session, Construction, new(9), WorkshopGpuAbi.Admission(Construction, new(9)));
        var previousRecord = WorkshopGpuAbi.Admission(Construction, new(9));
        var nextRecord = WorkshopGpuAbi.Admission(Construction, new(10));
        var nextSession = new RuntimeSessionId(23, 41);
        trace.Begin(nextSession, Construction, new(10), WorkshopGpuAbi.Admission(Construction, new(10)));
        trace.End(TraceEnd.Reset);
        trace.Flush(WorkshopSimulationPhase.Building);
        var lines = output.Lines;
        Assert.Equal(6, lines.Length);
        var previous = lines[0].Split(' ');
        var next = lines[3].Split(' ');
        Assert.Equal(TraceEnd.Reset, Reason(previous[7]));
        Assert.Equal(TraceEnd.Reset, Reason(next[7]));
        Assert.True(Number(next[1]) > Number(previous[1]));
        Assert.Equal(9UL, Number(previous[2]));
        Assert.Equal(10UL, Number(next[2]));
        Assert.Equal(previousRecord, Convert.FromBase64String(lines[1].Split(' ')[6]));
        Assert.Equal(nextRecord, Convert.FromBase64String(lines[4].Split(' ')[6]));
        Assert.Equal(Session, WorkshopWire.DecodeCommand(Convert.FromBase64String(previous[8])).Session);
        Assert.Equal(nextSession, WorkshopWire.DecodeCommand(Convert.FromBase64String(next[8])).Session);
    }

    [Fact]
    public void MissingOrOutOfOrderRecordsCannotClaimComplete()
    {
        using var output = new CapturedConsole();
        var trace = new WorkshopTrace();
        var record = WorkshopGpuAbi.Admission(Construction, new(9));
        trace.Begin(Session, Construction, new(9), record);
        BinaryPrimitives.WriteUInt64LittleEndian(record.AsSpan(16), 2);
        trace.Append(record);
        trace.End(TraceEnd.Complete);
        trace.Flush(WorkshopSimulationPhase.Completed);
        Assert.Equal(3, output.Lines.Length);
        var header = output.Lines[0].Split(' ');
        Assert.Equal(1UL, Number(header[5]));
        Assert.Equal(TraceEnd.InvalidRecord, Reason(header[7]));
        var before = output.Lines.Length;
        trace.Begin(Session, Construction, new(10), WorkshopGpuAbi.Admission(Construction, new(10)));
        trace.End(TraceEnd.Complete);
        trace.Flush(WorkshopSimulationPhase.Completed);
        Assert.Equal(before + 3, output.Lines.Length);
        Assert.Equal(TraceEnd.InvalidRecord, Reason(output.Lines[before].Split(' ')[7]));
    }

    [Theory]
    [InlineData(WorkshopSimulationPhase.Running)]
    [InlineData(WorkshopSimulationPhase.Starting)]
    [InlineData(WorkshopSimulationPhase.Resetting)]
    public void InvalidCaptureRemainsSealedUntilStopped(WorkshopSimulationPhase phase)
    {
        foreach (var reason in new[] { TraceEnd.InvalidRecord, TraceEnd.Overflow })
        {
            using var output = new CapturedConsole();
            var trace = new WorkshopTrace();
            var record = WorkshopGpuAbi.Admission(Construction, new(9));
            trace.Begin(Session, Construction, new(9), record);
            if (reason == TraceEnd.Overflow)
                for (ulong tick = 1; tick <= 3600; tick++)
                {
                    BinaryPrimitives.WriteUInt64LittleEndian(record.AsSpan(16), tick);
                    trace.Append(record);
                }
            else BinaryPrimitives.WriteUInt64LittleEndian(record.AsSpan(16), 2);
            trace.Append(record);
            trace.Flush(phase);
            Assert.Empty(output.Lines);
            trace.Flush(WorkshopSimulationPhase.Faulted);
            Assert.Equal(reason == TraceEnd.Overflow ? 31 : 3, output.Lines.Length);
            Assert.Equal(reason, Reason(output.Lines[0].Split(' ')[7]));
        }
    }

    [Theory]
    [InlineData(WorkshopSimulationPhase.Building)]
    [InlineData(WorkshopSimulationPhase.Disposed)]
    [InlineData(WorkshopSimulationPhase.Faulted)]
    public void TerminalSealingPreservesBytesUntilOneFlush(WorkshopSimulationPhase phase)
    {
        var reason = phase switch
        {
            WorkshopSimulationPhase.Building => TraceEnd.Reset,
            WorkshopSimulationPhase.Disposed => TraceEnd.Disposed,
            WorkshopSimulationPhase.Faulted => TraceEnd.DeviceLost,
            _ => throw new ArgumentOutOfRangeException(nameof(phase))
        };
        using var output = new CapturedConsole();
        var trace = new WorkshopTrace();
        var record = WorkshopGpuAbi.Admission(Construction, new(9));
        var expected = (byte[])record.Clone();
        trace.Begin(Session, Construction, new(9), record);
        trace.End(reason);
        record.AsSpan().Clear();
        trace.Append(record);
        Assert.Empty(output.Lines);
        trace.Flush(phase);
        Assert.Equal(expected, Convert.FromBase64String(output.Lines[1].Split(' ')[6]));
        Assert.Equal(reason, Reason(output.Lines[0].Split(' ')[7]));
        trace.Flush(phase);
        Assert.Equal(3, output.Lines.Length);
    }

    [Fact]
    public void FailedOutputIsContainedAndCannotContaminateTheNextCapture()
    {
        using var output = new CapturedConsole();
        var trace = new WorkshopTrace();
        trace.Begin(Session, Construction, new(9), WorkshopGpuAbi.Admission(Construction, new(9)));
        trace.End(TraceEnd.Reset);
        var destination = Console.Out;
        using var failure = new FailingOutput();
        try { Console.SetOut(failure); trace.Flush(WorkshopSimulationPhase.Building); }
        finally { Console.SetOut(destination); }
        trace.Flush(WorkshopSimulationPhase.Building);
        Assert.Empty(output.Lines);
        trace.Begin(Session, Construction, new(10), WorkshopGpuAbi.Admission(Construction, new(10)));
        trace.End(TraceEnd.Reset);
        trace.Flush(WorkshopSimulationPhase.Building);
        Assert.Equal(3, output.Lines.Length);
        Assert.Equal(10UL, Number(output.Lines[0].Split(' ')[2]));
    }

    private sealed class FailingOutput : StringWriter
    {
        public override void WriteLine(string? value) => throw new IOException("Deliberate diagnostic output failure.");
    }

    private static ulong Number(string value) => ulong.Parse(value, CultureInfo.InvariantCulture);
    private static TraceEnd Reason(string value)
    {
        var result = (TraceEnd)int.Parse(value, CultureInfo.InvariantCulture);
        Assert.True(Enum.IsDefined(result));
        return result;
    }

    private sealed class CapturedConsole : IDisposable
    {
        private readonly TextWriter _previous = Console.Out;
        private readonly StringWriter _output = new(CultureInfo.InvariantCulture);
        public CapturedConsole() => Console.SetOut(_output);
        public string[] Lines => _output.ToString().Split(['\r', '\n'], StringSplitOptions.RemoveEmptyEntries);
        public void Dispose() { Console.SetOut(_previous); _output.Dispose(); }
    }
}
#endif
