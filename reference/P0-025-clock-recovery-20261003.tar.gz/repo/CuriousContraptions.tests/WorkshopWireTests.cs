using System.Buffers.Binary;
using CuriousContraptions.Gpu;

namespace CuriousContraptions.Tests;

public sealed class WorkshopWireTests
{
    private static readonly RuntimeSessionId Session = new(0x20000000000001, ulong.MaxValue);
    private static WorkshopRead Stamped(WorkshopRead read) => read with { Capture = new(WorkshopClockDomain.SimulationMonotonic,
        new(1), new(100_000_000), new(100_000)) };
    private static bool AdmitRead(WorkshopClientCursor cursor, WorkshopResponse response)
    {
        var candidate = cursor.PrepareRead(response); cursor.Commit(candidate); return candidate.Applicable;
    }
    private static WorkshopDelivery AdmitAcknowledgement(WorkshopClientCursor cursor, WorkshopCommand command,
        WorkshopResponse response, ulong order, bool disposed)
    {
        var candidate = cursor.PrepareAcknowledgement(command, response, order, disposed);
        cursor.Commit(candidate); return new(response, candidate.Applicable);
    }
    private static WorkshopConstruction Construction => new(new(2),
        WorkshopInput.Basketball(new(0x20000000000001), 0, 4, 0, 0, 0, 0, 1));


    [Fact]
    public void IsolatedNativeProfileRoundTripsAndRejectsOldOrUnprovenDeclarations()
    {
        var peer = new WorkshopClockPeer(Session, new(ulong.MaxValue), new(100_000));
        var bytes = WorkshopClockWire.EncodePeer(peer);
        Assert.Equal(peer, WorkshopClockWire.DecodePeer(bytes));
        Assert.Equal(2U, BinaryPrimitives.ReadUInt32LittleEndian(bytes));
        Assert.Equal(NativeClockProfile.Chromium154MacIsolated,
            (NativeClockProfile)BinaryPrimitives.ReadUInt32LittleEndian(bytes.AsSpan(4)));
        var oldVersion = (byte[])bytes.Clone();
        BinaryPrimitives.WriteUInt32LittleEndian(oldVersion, 1);
        Assert.Throws<ArgumentException>(() => WorkshopClockWire.DecodePeer(oldVersion));
        var oldProfile = (byte[])bytes.Clone();
        BinaryPrimitives.WriteUInt32LittleEndian(oldProfile.AsSpan(4), 1);
        Assert.Throws<ArgumentException>(() => WorkshopClockWire.DecodePeer(oldProfile));
        var unknown = (byte[])bytes.Clone();
        BinaryPrimitives.WriteUInt64LittleEndian(unknown.AsSpan(32), 100_001);
        Assert.Throws<ArgumentOutOfRangeException>(() => WorkshopClockWire.DecodePeer(unknown));
        Assert.Throws<ArgumentException>(() => WorkshopClockWire.EncodePeer(peer with { Uncertainty = new(99_999) }));
    }

    [Fact]
    public void RecoveryKeepsUsableCommittedHistoryAndAdvancesTheDisplay()
    {
        var peer = new WorkshopClockPeer(Session, new(1), new(100_000));
        var clock = new WorkshopClockMapping(peer);
        void Probe(long sent, long roundtrip = 0)
        {
            var probe = clock.BeginProbe(new(sent))!.Value;
            Assert.Equal(ClockProbeOutcome.Accepted,
                clock.Receive(new(probe, new(sent + 50_000_000), new(sent + 50_000_000), new(sent + roundtrip))).Outcome);
        }
        for (var i = 0; i < 8; i++) Probe(i * 10_000_000);
        var history = new WorkshopPoseHistory();
        void Admit(ulong tick, long browserTime, PresentationBoundary boundary)
        {
            var capture = new WorkshopClockStamp(WorkshopClockDomain.SimulationMonotonic, peer.Generation,
                new(browserTime + 50_000_000), new(100_000));
            Assert.True(clock.TryMap(capture, new(browserTime), out var mapped));
            var response = new WorkshopResponse(new(0), WorkshopResponseKind.Read,
                new(WorkshopCommandOutcome.Applied, WorkshopRejection.None), WorkshopSimulationPhase.Running,
                new(new(1), new(tick), new CanonicalBody(new(1), 1, tick, new(0, 10 - (int)tick, 0), default, default),
                    new(tick + 1), capture), peer.Session, new(tick + 1));
            history.Commit(history.Prepare(response, mapped, boundary, clock.DisplayEpoch));
        }
        Admit(0, 317_000_000, PresentationBoundary.Run);
        Assert.True(history.TryPresent(new(317_000_000), clock, out _));
        var epoch = clock.DisplayEpoch;
        Probe(320_000_000, 1_295_000);
        Assert.Equal(ClockMappingState.Recovering, clock.State);
        Admit(1, 325_000_000, PresentationBoundary.Continuous);
        Admit(2, 333_000_000, PresentationBoundary.Continuous);
        Assert.True(history.TryPresent(new(347_000_000), clock, out var presented));
        Assert.Equal(PresentationQuality.Interpolated, presented.Quality);
        Assert.Equal(1UL, presented.Evidence.Before!.Value.Tick.Value);
        Assert.Equal(2UL, presented.Evidence.After!.Value.Tick.Value);
        Assert.Equal(epoch, clock.DisplayEpoch);
        Assert.Equal(ClockMappingState.Recovering, clock.State);
    }

    [Theory]
    [InlineData(true, false)]
    [InlineData(false, false)]
    [InlineData(true, true)]
    [InlineData(false, true)]
    public void RunSegmentRetiresPreRunCaptureWhetherAckOrReadArrivesFirst(bool ackFirst, bool faultBeforeTick)
    {
        var peer = new WorkshopClockPeer(new(11, 23), new(1), new(0));
        var clock = new WorkshopClockMapping(peer);
        for (var i = 0; i < 8; i++)
        {
            var time = new MonotonicNanoseconds(i * 10_000_000);
            var probe = clock.BeginProbe(time)!.Value;
            clock.Receive(new(probe, time, time, time));
        }
        var history = new WorkshopPoseHistory();
        var cursor = new WorkshopClientCursor(peer.Session);
        WorkshopResponse Response(ulong sequence, WorkshopResponseKind kind, ulong tick, ulong revision,
            long captured, WorkshopSimulationPhase phase, ulong publication = 0) =>
            new(new(sequence), kind, new(phase == WorkshopSimulationPhase.Faulted ? WorkshopCommandOutcome.Faulted : WorkshopCommandOutcome.Applied,
                phase == WorkshopSimulationPhase.Faulted ? WorkshopRejection.DeviceLost : WorkshopRejection.None), phase,
                new(new(1), new(tick), new CanonicalBody(new(1), 1, tick, new(0, 10 - (int)tick, 0), default, default),
                    new(revision), new(WorkshopClockDomain.SimulationMonotonic, new(1), new(captured), new(0))),
                peer.Session, new(publication));
        void Admit(WorkshopResponse response, PresentationBoundary boundary)
        {
            var stamp = response.Read.Capture!.Value.Time;
            history.Commit(history.Prepare(response, new(new(stamp.Value, stamp.Value), stamp, new(8)), boundary, 1));
        }
        var building = Response(1, WorkshopResponseKind.Acknowledgement, 0, 1, 100_000_000, WorkshopSimulationPhase.Building);
        var initialized = new WorkshopCommand(new(1), WorkshopCommandKind.Initialize, new(1), default, null, Session: peer.Session);
        cursor.Commit(cursor.PrepareAcknowledgement(initialized, building, 0, false));
        Admit(building, PresentationBoundary.Seed);
        Assert.True(history.TryPresent(new(100_000_000), clock, out _));
        var command = new WorkshopCommand(new(2), WorkshopCommandKind.Run, cursor.Epoch, cursor.Revision, null, Session: peer.Session);
        var order = cursor.ReadOrder;
        var run = Response(2, WorkshopResponseKind.Acknowledgement, 0, 2, 300_000_000, WorkshopSimulationPhase.Running);
        if (ackFirst)
        {
            var prepared = cursor.PrepareAcknowledgement(command, run, order, false);
            Assert.True(prepared.Applicable); cursor.Commit(prepared); Admit(run, PresentationBoundary.Run);
            Assert.True(history.TryPresent(new(300_000_000), clock, out var seed));
            Assert.Equal(300_000_000, seed.Evidence.Before!.Value.Capture.Time.Value);
        }
        var first = faultBeforeTick
            ? Response(0, WorkshopResponseKind.Read, 0, 3, 300_000_000, WorkshopSimulationPhase.Faulted, 1)
            : Response(0, WorkshopResponseKind.Read, 1, 3, 308_000_000, WorkshopSimulationPhase.Running, 1);
        cursor.Commit(cursor.PrepareRead(first)); Admit(first, PresentationBoundary.Continuous);
        if (!ackFirst)
        {
            var oldAck = cursor.PrepareAcknowledgement(command, run, order, false);
            Assert.False(oldAck.Applicable);
            Assert.Equal(1, history.Count);
        }
        Assert.False(history.TryPresent(new(316_000_000), clock, out var held));
        if (faultBeforeTick)
        {
            Assert.Equal(PresentationQuality.Faulted, held.Quality);
            Assert.Null(held.Body); Assert.Null(held.Evidence.Before); Assert.Null(held.Evidence.After);
            Assert.Equal(300_000_000, held.Evidence.Latest!.Value.Capture.Time.Value);
            return;
        }
        var second = Response(0, WorkshopResponseKind.Read, 2, 4, 316_000_000, WorkshopSimulationPhase.Running, 2);
        cursor.Commit(cursor.PrepareRead(second)); Admit(second, PresentationBoundary.Continuous);
        Assert.True(history.TryPresent(new(329_000_000), clock, out var presented));
        Assert.Equal(1UL, presented.Evidence.Before!.Value.Tick.Value);
        Assert.Equal(2UL, presented.Evidence.After!.Value.Tick.Value);
        Assert.True(presented.Evidence.Before.Value.Capture.Time.Value >= 300_000_000);
    }

    [Fact]
    public void RejectedConstructionReadValidatesAgainstCurrentAdmittedPose()
    {
        var current = Construction;
        var ball = current.Ball!.Value;
        var read = Stamped(new(new(1), new(0), new CanonicalBody(ball.Id, 1, 0, ball.Cell, ball.Local, default)));
        var response = new WorkshopResponse(new(1), WorkshopResponseKind.Acknowledgement,
            new(WorkshopCommandOutcome.Rejected, WorkshopRejection.InvalidConstruction),
            WorkshopSimulationPhase.Building, read, Session);
        var proposed = current with { Revision = new(3), Ball = ball with { Cell = new(32, 64, 0) } };
        BrowserWorkshopClient.ValidateCommandRead(response, proposed, current);
        Assert.Throws<ArgumentException>(() => BrowserWorkshopClient.ValidateCommandRead(
            response with { Result = new(WorkshopCommandOutcome.Applied, WorkshopRejection.None) }, proposed, current));
        Assert.Equal(ball.Cell, response.Read.Ball!.Value.Cell);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void OriginalAckRemainsExactAfterNewerReadOrSameRevisionFault(bool sameRevisionFault)
    {
        var cursor = new WorkshopClientCursor(Session);
        var command = new WorkshopCommand(new(1), WorkshopCommandKind.Run, new(1), default, null, Session: Session);
        var dispatched = cursor.ReadOrder;
        var ack = new WorkshopResponse(new(1), WorkshopResponseKind.Acknowledgement,
            new(WorkshopCommandOutcome.Applied, WorkshopRejection.None), WorkshopSimulationPhase.Running, Stamped(new(new(1), new(0), null, new(1))), Session);
        var original = WorkshopWire.Encode(ack);
        var later = new WorkshopResponse(default, WorkshopResponseKind.Read,
            new(sameRevisionFault ? WorkshopCommandOutcome.Faulted : WorkshopCommandOutcome.Applied,
                sameRevisionFault ? WorkshopRejection.DeviceLost : WorkshopRejection.None),
            sameRevisionFault ? WorkshopSimulationPhase.Faulted : WorkshopSimulationPhase.Running, Stamped(new(new(1), new(sameRevisionFault ? 0UL : 1UL), null, new(sameRevisionFault ? 1UL : 2UL))), Session, new(1));
        Assert.True(AdmitRead(cursor, later));
        var delivery = AdmitAcknowledgement(cursor, command, ack, dispatched, false);
        Assert.False(delivery.Applicable);
        Assert.Equal(original, WorkshopWire.Encode(delivery.Response));
        Assert.Equal(later.Read.Revision, cursor.Revision);
    }

    [Fact]
    public void FutureReadCannotInstallEpochAndOnlyOwnedSuccessCanAdvanceIt()
    {
        var cursor = new WorkshopClientCursor(Session);
        var future = new WorkshopResponse(default, WorkshopResponseKind.Read,
            new(WorkshopCommandOutcome.Applied, WorkshopRejection.None), WorkshopSimulationPhase.Building, Stamped(new(new(2), default, null, new(1))), Session, new(1));
        Assert.Throws<ArgumentException>(() => AdmitRead(cursor, future));
        Assert.Equal(new SimulationEpoch(1), cursor.Epoch);
        Assert.Equal(default, cursor.Revision);
        var command = new WorkshopCommand(new(1), WorkshopCommandKind.Reset, new(1), default, null,
            RevisionKind: ExpectedRevisionKind.Any, Session: Session);
        var ack = future with { Sequence = new(1), Kind = WorkshopResponseKind.Acknowledgement, Publication = default };
        Assert.Throws<ArgumentException>(() => AdmitAcknowledgement(cursor, command with { Kind = WorkshopCommandKind.Run }, ack, 0, false));
        Assert.True(AdmitAcknowledgement(cursor, command, ack, 0, false).Applicable);
        Assert.Equal(new SimulationEpoch(2), cursor.Epoch);
        var retired = AdmitAcknowledgement(cursor, command with { Epoch = new(2) },
            ack with { Read = ack.Read with { Epoch = new(3), Revision = new(2) } }, 0, true);
        Assert.False(retired.Applicable);
        Assert.Equal(WorkshopCommandOutcome.Applied, retired.Response.Result.Outcome);
        Assert.Equal(new SimulationEpoch(2), cursor.Epoch);
        var old = AdmitAcknowledgement(cursor, command, ack with { Read = ack.Read with { Epoch = new(1) } }, 0, false);
        Assert.False(old.Applicable);
        Assert.Equal(new SimulationEpoch(1), old.Response.Read.Epoch);
        Assert.Equal(WorkshopCommandOutcome.Applied, old.Response.Result.Outcome);
    }

    [Fact]
    public void SameEpochAckCannotMoveTickBackwardsEvenWithNewerRevision()
    {
        var cursor = new WorkshopClientCursor(Session);
        var read = new WorkshopResponse(default, WorkshopResponseKind.Read,
            new(WorkshopCommandOutcome.Applied, WorkshopRejection.None), WorkshopSimulationPhase.Running, Stamped(new(new(1), new(7), null, new(8))), Session, new(1));
        Assert.True(AdmitRead(cursor, read));
        var command = new WorkshopCommand(new(2), WorkshopCommandKind.Run, new(1), new(8), null, Session: Session);
        var ack = read with { Sequence = new(2), Kind = WorkshopResponseKind.Acknowledgement, Publication = default,
            Read = read.Read with { Tick = new(6), Revision = new(9) } };
        Assert.False(AdmitAcknowledgement(cursor, command, ack, cursor.ReadOrder, false).Applicable);
        Assert.Equal(new AuthorityRevision(8), cursor.Revision);
        Assert.False(AdmitRead(cursor, read with { Read = read.Read with { Tick = new(6), Revision = new(9) } }));
    }

    [Fact]
    public void AuthorityRevisionIsSeparateAndAnyControlSurvivesLaterTicks()
    {
        var exact = new WorkshopCommand(new(1), WorkshopCommandKind.Construct, new(3), new(9), Construction, Session: Session);
        Assert.True(WorkshopWire.Matches(exact, new(3), new(9), Session));
        Assert.False(WorkshopWire.Matches(exact, new(3), new(10), Session));
        var reset = new WorkshopCommand(new(2), WorkshopCommandKind.Reset, new(3), default, null,
            RevisionKind: ExpectedRevisionKind.Any, Session: Session);
        Assert.True(WorkshopWire.Matches(WorkshopWire.DecodeCommand(WorkshopWire.Encode(reset)), new(3), new(1234), Session));
        Assert.False(WorkshopWire.Matches(reset, new(4), new(1234), Session));
        Assert.Throws<ArgumentException>(() => WorkshopWire.Encode(reset with { Revision = new(1) }));
        Assert.Throws<ArgumentException>(() => WorkshopWire.Encode(exact with { Revision = default, RevisionKind = ExpectedRevisionKind.Any }));
        var response = new WorkshopResponse(new(1), WorkshopResponseKind.Acknowledgement,
            new(WorkshopCommandOutcome.Applied, WorkshopRejection.None), WorkshopSimulationPhase.Building, Stamped(new(new(3), new(0), null, new(ulong.MaxValue))), Session);
        var bytes = WorkshopWire.Encode(response);
        Assert.Equal(192, bytes.Length);
        Assert.Equal(response, WorkshopWire.DecodeResponse(bytes));
        bytes[58] = 1;
        Assert.Throws<ArgumentException>(() => WorkshopWire.DecodeResponse(bytes));
    }

    [Fact]
    public void CancelWireRetainsExactOriginalIdentityAndRejectsMissingTarget()
    {
        var identity = new WorkshopCommandIdentity(new(0x20000000000001), new(19), new(23));
        var command = new WorkshopCommand(new(8), WorkshopCommandKind.Cancel, new(19), new(23), null, identity, Session: Session);
        Assert.Equal(command, WorkshopWire.DecodeCommand(WorkshopWire.Encode(command)));
        Assert.Throws<ArgumentException>(() => WorkshopWire.Encode(command with { Target = null }));
        var bytes = WorkshopWire.Encode(command);
        BinaryPrimitives.WriteUInt64LittleEndian(bytes.AsSpan(56), 0);
        Assert.Throws<ArgumentException>(() => WorkshopWire.DecodeCommand(bytes));
    }

    [Fact]
    public void InvalidQuaternionAndOutOfDeckDescriptorReject()
    {
        Assert.Throws<ArgumentException>(() => new CanonicalRotation((Half)1, (Half)1, (Half)1, (Half)1).Validate());
        Assert.Throws<ArgumentException>(() => new CanonicalRotation((Half).001, (Half)0, (Half)0, (Half)0).Validate());
        var bytes = WorkshopGpuAbi.Admission(Construction, new(2));
        BinaryPrimitives.WriteInt32LittleEndian(bytes.AsSpan(32), 1024);
        Assert.Throws<ArgumentException>(() => WorkshopGpuAbi.Read(bytes));
    }

    [Fact]
    public void CanonicalConstructionWireRetainsEveryBitAndWideIdentity()
    {
        var ball = Construction.Ball!.Value with
        {
            Local = new(BitConverter.UInt16BitsToHalf(0x8000), (Half)0.25, (Half)0),
            Rotation = new(BitConverter.UInt16BitsToHalf(0x8000), (Half)0, (Half)0, (Half)1)
        };
        var command = new WorkshopCommand(new(0x20000000000001), WorkshopCommandKind.Construct,
            new(0x30000000000001), new(1), Construction with { Ball = ball }, Session: Session);
        var bytes = WorkshopWire.Encode(command);
        Assert.Equal(bytes, WorkshopWire.Encode(WorkshopWire.DecodeCommand(bytes)));
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void ObsoleteResponseSchemaRejectsEmptyAndBall(bool withBall)
    {
        var body = withBall ? new CanonicalBody(new(1), 3, 8, default, default, default) : (CanonicalBody?)null;
        var response = new WorkshopResponse(new(0), WorkshopResponseKind.Read,
            new(WorkshopCommandOutcome.Applied, WorkshopRejection.None), WorkshopSimulationPhase.Running, Stamped(new(new(3), new(8), body)), Session, new(1));
        var bytes = WorkshopWire.Encode(response);
        BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(52), 17);
        Assert.Throws<ArgumentException>(() => WorkshopWire.DecodeResponse(bytes));
    }

    [Theory]
    [InlineData(80, 0x8000u)]
    [InlineData(82, 0x7e00u)]
    [InlineData(88, uint.MaxValue)]
    [InlineData(92, 0x7e00u)]
    [InlineData(94, 0x7e00u)]
    [InlineData(100, uint.MaxValue)]
    [InlineData(104, 2u)]
    [InlineData(108, 2u)]
    [InlineData(120, 1u)]
    public void MalformedOpaqueDescriptorCannotCommit(int offset, uint value)
    {
        var bytes = WorkshopGpuAbi.Admission(Construction, new(2));
        if (offset is 80 or 82 or 92 or 94) BinaryPrimitives.WriteUInt16LittleEndian(bytes.AsSpan(offset), (ushort)value);
        else BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(offset), value);
        Assert.Throws<ArgumentException>(() => WorkshopGpuAbi.Read(bytes));
    }

    private static void WriteHalf(byte[] bytes, int offset, Half value) =>
        BinaryPrimitives.WriteUInt16LittleEndian(bytes.AsSpan(offset), BitConverter.HalfToUInt16Bits(value));

    // A post-contact descriptor at an independently selected clock boundary. No CPU law is executed.
    private static byte[] ContactDescriptor(ulong tick, uint origin, Half phase,
        WorkshopBodyMotion motion = WorkshopBodyMotion.Flying)
    {
        var support = WorkshopInput.Basketball(new(1), 0, -0.119873046875, 0, 0, 0, 0, 1);
        var bytes = WorkshopGpuAbi.Admission(Construction, new(2));
        new CanonicalBody(Construction.Ball!.Value.Id, 2, tick, support.Cell, support.Local, default)
            .Write(bytes.AsSpan(0, CanonicalBody.ByteLength));
        WriteHalf(bytes, 82, motion == WorkshopBodyMotion.Flying ? (Half)0.125 : (Half)0);
        BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(88), origin);
        WriteHalf(bytes, 92, phase);
        WriteHalf(bytes, 94, support.Local.Y);
        BinaryPrimitives.WriteInt32LittleEndian(bytes.AsSpan(96), support.Cell.Y);
        BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(104), 1);
        BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(108), (uint)motion);
        return bytes;
    }

    [Fact]
    public void CurrentGpuDescriptorKeepsCanonicalBodyAndRejectsEveryOldLength()
    {
        var bytes = WorkshopGpuAbi.Admission(Construction, new(2));
        Assert.Equal(128, bytes.Length);
        Assert.Equal(80, CanonicalBody.ByteLength);
        Assert.Equal(Construction.Ball!.Value.Cell, WorkshopGpuAbi.Read(bytes).Ball!.Value.Cell);
        Assert.Equal(WorkshopLawFailure.None, WorkshopGpuAbi.ReadFailure(bytes));
        Assert.Equal(1U, BinaryPrimitives.ReadUInt32LittleEndian(bytes.AsSpan(100)));
        Assert.Equal(WorkshopLawVersion.LocalQuadraticResponse,
            (WorkshopLawVersion)BinaryPrimitives.ReadUInt32LittleEndian(bytes.AsSpan(112)));
        Assert.Equal(Construction.Ball.Value.Cell.Y, BinaryPrimitives.ReadInt32LittleEndian(bytes.AsSpan(96)));
        Assert.Equal(BitConverter.HalfToUInt16Bits(Construction.Ball.Value.Local.Y),
            BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(94)));
        foreach (var length in new[] { 80, 112, 127, 129 })
            Assert.Throws<ArgumentException>(() => WorkshopGpuAbi.Read(new byte[length]));
    }

    [Theory]
    [InlineData(-2048, true)]
    [InlineData(2048, false)]
    [InlineData(-1, true)]
    [InlineData(0, true)]
    [InlineData(1, false)]
    public void CenteredPhaseIsCanonicalAndCannotStartInTheFuture(int phase, bool accepted)
    {
        var bytes = ContactDescriptor(2, 8, (Half)phase);
        if (accepted) Assert.Equal(new SimulationTick(2), WorkshopGpuAbi.Read(bytes).Tick);
        else Assert.Throws<ArgumentException>(() => WorkshopGpuAbi.Read(bytes));
    }

    [Theory]
    [InlineData(4u, -1, false)]
    [InlineData(4u, 0, true)]
    [InlineData(4u, 1, true)]
    [InlineData(3u, 0, false)]
    public void ActiveSegmentHasExactTwoSecondCenteredAgeBoundary(uint origin, int phase, bool accepted)
    {
        var bytes = ContactDescriptor(241, origin, (Half)phase);
        if (accepted) Assert.Equal(new SimulationTick(241), WorkshopGpuAbi.Read(bytes).Tick);
        else Assert.Throws<ArgumentException>(() => WorkshopGpuAbi.Read(bytes));
    }

    [Fact]
    public void RestAndEmptyKeepTheirCanonicalShapesAtTerminalTick()
    {
        var resting = ContactDescriptor(3600, 1, (Half)0, WorkshopBodyMotion.Resting);
        Assert.Equal(new SimulationTick(3600), WorkshopGpuAbi.Read(resting).Tick);
        WriteHalf(resting, 82, (Half)0.125);
        Assert.Throws<ArgumentException>(() => WorkshopGpuAbi.Read(resting));
        var empty = WorkshopGpuAbi.Admission(new(new(1), null), new(2));
        BinaryPrimitives.WriteUInt64LittleEndian(empty.AsSpan(16), 3600);
        Assert.Null(WorkshopGpuAbi.Read(empty).Ball);
        foreach (var offset in new[] { 88, 94, 96, 104 })
        {
            var invalid = (byte[])empty.Clone(); invalid[offset] = 1;
            Assert.Throws<ArgumentException>(() => WorkshopGpuAbi.Read(invalid));
        }
        BinaryPrimitives.WriteUInt64LittleEndian(empty.AsSpan(16), 3601);
        Assert.Throws<ArgumentException>(() => WorkshopGpuAbi.Read(empty));
    }

    [Fact]
    public void ImmutableAdmissionCopyPreservesSignedZeroExactly()
    {
        var bytes = WorkshopGpuAbi.Admission(Construction, new(2));
        WriteHalf(bytes, 58, BitConverter.UInt16BitsToHalf(0x8000));
        Assert.Throws<ArgumentException>(() => WorkshopGpuAbi.Read(bytes));
        WriteHalf(bytes, 94, BitConverter.UInt16BitsToHalf(0x8000));
        Assert.NotNull(WorkshopGpuAbi.Read(bytes).Ball);
    }

    [Fact]
    public void ImmutableInputAndContactOriginsRejectNoncanonicalState()
    {
        var admitted = WorkshopGpuAbi.Admission(Construction, new(2));
        foreach (var offset in new[] { 82, 88, 92, 94, 96 })
        {
            var invalid = (byte[])admitted.Clone(); invalid[offset] ^= 1;
            Assert.Throws<ArgumentException>(() => WorkshopGpuAbi.Read(invalid));
        }
        var contact = ContactDescriptor(2, 7, (Half)0);
        contact[96] ^= 1;
        Assert.Throws<ArgumentException>(() => WorkshopGpuAbi.Read(contact));
        var reset = WorkshopGpuAbi.Admission(Construction, new(3));
        Assert.Equal(new SimulationEpoch(3), WorkshopGpuAbi.Read(reset).Epoch);
        Assert.Equal(WorkshopLawFailure.None, WorkshopGpuAbi.ReadFailure(reset));
        Assert.Equal(0U, BinaryPrimitives.ReadUInt32LittleEndian(reset.AsSpan(104)));
    }

    [Theory]
    [InlineData(112, 0u)]
    [InlineData(112, 1u)]
    [InlineData(112, uint.MaxValue)]
    [InlineData(116, uint.MaxValue)]
    [InlineData(116, (uint)WorkshopLawFailure.Domain)]
    [InlineData(120, 1u)]
    [InlineData(124, 1u)]
    [InlineData(100, 2u)]
    [InlineData(108, uint.MaxValue)]
    public void UndefinedVersionFailureAndReservedDescriptorCannotCommit(int offset, uint value)
    {
        var bytes = WorkshopGpuAbi.Admission(Construction, new(2));
        BinaryPrimitives.WriteUInt32LittleEndian(bytes.AsSpan(offset), value);
        Assert.Throws<ArgumentException>(() => WorkshopGpuAbi.Read(bytes));
    }

    [Theory]
    [InlineData(0x0001, true)]
    [InlineData(0x4044, true)]
    [InlineData(0x4045, false)]
    [InlineData(0x8000, false)]
    [InlineData(0xbc00, false)]
    [InlineData(0x7c00, false)]
    [InlineData(0x7e00, false)]
    public void MaterialResponseDomainRejectsBeforeVelocityConversion(ushort bits, bool accepted)
    {
        var value = BitConverter.UInt16BitsToHalf(bits);
        var bytes = ContactDescriptor(2, 7, (Half)0);
        WriteHalf(bytes, 82, value);
        if (accepted)
        {
            new WorkshopMaterialResponse(value).Validate();
            Assert.NotNull(WorkshopGpuAbi.Read(bytes).Ball);
        }
        else Assert.Throws<ArgumentException>(() => WorkshopGpuAbi.Read(bytes));
        Assert.Equal((ushort)0x4044, BitConverter.HalfToUInt16Bits(WorkshopMaterialResponse.Maximum));
        Assert.Equal((Half)3.75, WorkshopMaterialResponse.WorldFactor);
    }

    [Fact]
    public void ResponseIsPositiveZeroForInitialEmptyAndRestingStates()
    {
        var shapes = new[]
        {
            WorkshopGpuAbi.Admission(Construction, new(2)),
            WorkshopGpuAbi.Admission(new(new(1), null), new(2)),
            ContactDescriptor(2, 7, (Half)0, WorkshopBodyMotion.Resting)
        };
        foreach (var bytes in shapes)
        {
            Assert.Equal((ushort)0, BinaryPrimitives.ReadUInt16LittleEndian(bytes.AsSpan(82)));
            WorkshopGpuAbi.Read(bytes);
            WriteHalf(bytes, 82, BitConverter.UInt16BitsToHalf(0x8000));
            Assert.Throws<ArgumentException>(() => WorkshopGpuAbi.Read(bytes));
        }
        new WorkshopMaterialResponse((Half)0).Validate();
    }

    [Fact]
    public void StaticLawTableMatchesFrozenHalfCoefficientsAndRejectsProfileDrift()
    {
        var rows = BasketballLawCoefficients.Regions;
        Assert.Equal(1105, rows.Length);
        var packed = new byte[rows.Length * 16];
        for (var i = 0; i < rows.Length; i++)
        {
            var row = rows[i];
            BinaryPrimitives.WriteInt32LittleEndian(packed.AsSpan(i * 16), row.Cell);
            var values = new[] { row.Local, row.A1, row.A2, row.B0, row.B1, row.B2 };
            for (var field = 0; field < values.Length; field++)
            {
                Assert.True(Half.IsFinite(values[field]));
                WriteHalf(packed, i * 16 + 4 + field * 2, values[field]);
            }
            Assert.InRange(row.Local, (Half)(-0.5), BitConverter.UInt16BitsToHalf(0x37ff));
        }
        Assert.Equal("F8DB33355086590F4B989FDB02D5B0E0CAF0B832E2789EC43F873E514AD4B9F4",
            Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(packed)));
        void Validate(Half gravity, Half drag, Half support, Half dt, CellScale cell, TimeScale time) =>
            BasketballLawCoefficients.ValidateProfile(gravity, drag, support, dt, cell, time);
        var g = (Half)9.8125; var k = (Half)0.040008544921875;
        var s = (Half)(-0.119873046875); var dt = (Half)1.06640625;
        Validate(g, k, s, dt, CellScale.Metres, TimeScale.Seconds);
        Assert.Throws<ArgumentException>(() => Validate((Half)9, k, s, dt, CellScale.Metres, TimeScale.Seconds));
        Assert.Throws<ArgumentException>(() => Validate(g, (Half)0, s, dt, CellScale.Metres, TimeScale.Seconds));
        Assert.Throws<ArgumentException>(() => Validate(g, k, (Half)0, dt, CellScale.Metres, TimeScale.Seconds));
        Assert.Throws<ArgumentException>(() => Validate(g, k, s, (Half)1, CellScale.Metres, TimeScale.Seconds));
        Assert.Throws<ArgumentException>(() => Validate(g, k, s, dt, (CellScale)0, TimeScale.Seconds));
        Assert.Throws<ArgumentException>(() => Validate(g, k, s, dt, CellScale.Metres, (TimeScale)0));
        Assert.Contains("array<LawRegion, 1105>", WorkshopGpuAbi.ShaderPreamble());
    }

    [Fact]
    public async Task ActualRouterReplaysOnlyExactPendingAndCompletedCommand()
    {
        var held = new TaskCompletionSource<byte[]>();
        var applied = new List<WorkshopCommand>();
        var router = new WorkshopCommandRouter((command, reserved) => { applied.Add(command); return held.Task; });
        var command = new WorkshopCommand(new(1), WorkshopCommandKind.Construct, new(1), new(1), Construction, Session: Session);
        var bytes = WorkshopWire.Encode(command);
        var first = router.Dispatch(bytes);
        var duplicate = router.Dispatch((byte[])bytes.Clone());
        Assert.Same(first, duplicate);
        await Assert.ThrowsAsync<ArgumentException>(() => router.Dispatch(WorkshopWire.Encode(command with { Kind = WorkshopCommandKind.Run, Construction = null })));
        await Assert.ThrowsAsync<ArgumentException>(() => router.Dispatch(WorkshopWire.Encode(command with { Epoch = new(2) })));
        var different = command with { Construction = Construction with { Ball = null } };
        await Assert.ThrowsAsync<ArgumentException>(() => router.Dispatch(WorkshopWire.Encode(different)));
        bytes[16] ^= 1; // caller cannot change the retained identity after admission.
        await Assert.ThrowsAsync<ArgumentException>(() => router.Dispatch(bytes));
        held.SetResult([1, 2, 3]);
        Assert.Equal(new byte[] { 1, 2, 3 }, await first);
        Assert.Same(first, router.Dispatch(WorkshopWire.Encode(command)));
        Assert.Single(applied);
    }

    [Fact]
    public async Task MalformedAndOutOfOrderInputsDoNotConsumeNextReliableIdentity()
    {
        var seen = new List<CommandSequence>();
        var router = new WorkshopCommandRouter((command, reserved) => { seen.Add(command.Sequence); return Task.FromResult(Array.Empty<byte>()); });
        var next = new WorkshopCommand(new(1), WorkshopCommandKind.Run, new(1), new(1), null, Session: Session);
        var malformed = WorkshopWire.Encode(next);
        BinaryPrimitives.WriteUInt32LittleEndian(malformed.AsSpan(12), 99);
        await Assert.ThrowsAsync<ArgumentException>(() => router.Dispatch(malformed));
        await Assert.ThrowsAsync<ArgumentException>(() => router.Dispatch(WorkshopWire.Encode(next with { Sequence = new(2) })));
        await router.Dispatch(WorkshopWire.Encode(next));
        Assert.Equal(new[] { new CommandSequence(1) }, seen);
    }

    private static WorkshopMemoryRequest MemoryRequest => new(WorkshopMemoryKind.PostGc, WorkshopMemoryContext.Simulation,
        Session, new(ulong.MaxValue), new(ulong.MaxValue), new(ulong.MaxValue), new(ulong.MaxValue));

    [Fact]
    public void StoppedMemoryWirePreservesExactWideIdentitiesAndSeparateContext()
    {
        var bytes = WorkshopMemoryWire.Encode(MemoryRequest);
        Assert.Equal(64, bytes.Length);
        Assert.Equal(MemoryRequest, WorkshopMemoryWire.DecodeRequest(bytes));
        Assert.Equal(ulong.MaxValue, BinaryPrimitives.ReadUInt64LittleEndian(bytes.AsSpan(32)));
        var sample = new WorkshopMemoryResult(MemoryRequest, WorkshopMemoryStatus.Accepted,
            1234, 1200, 19, 1_000_000_000, 5000, 5050, 6, 7);
        var result = WorkshopMemoryWire.Encode(sample);
        Assert.Equal(128, result.Length);
        Assert.Equal(sample, WorkshopMemoryWire.DecodeResult(result));
        Assert.Equal(sample with { Request = MemoryRequest with { Context = WorkshopMemoryContext.Browser } },
            WorkshopMemoryWire.DecodeResult(WorkshopMemoryWire.Encode(sample with
            { Request = MemoryRequest with { Context = WorkshopMemoryContext.Browser } })));
    }

    [Fact]
    public void StoppedMemoryRequestsRejectUnknownEnumsReservedBytesAndInvalidIdentity()
    {
        var valid = WorkshopMemoryWire.Encode(MemoryRequest);
        foreach (var offset in new[] { 0, 4, 8, 12 })
        {
            var malformed = (byte[])valid.Clone();
            BinaryPrimitives.WriteUInt32LittleEndian(malformed.AsSpan(offset), uint.MaxValue);
            Assert.Throws<ArgumentException>(() => WorkshopMemoryWire.DecodeRequest(malformed));
        }
        foreach (var offset in new[] { 32, 40 })
        {
            var malformed = (byte[])valid.Clone();
            BinaryPrimitives.WriteUInt64LittleEndian(malformed.AsSpan(offset), 0);
            Assert.Throws<ArgumentException>(() => WorkshopMemoryWire.DecodeRequest(malformed));
        }
        var missingSession = (byte[])valid.Clone();
        missingSession.AsSpan(16, 16).Clear();
        Assert.Throws<ArgumentException>(() => WorkshopMemoryWire.DecodeRequest(missingSession));
        Assert.Throws<ArgumentException>(() => WorkshopMemoryWire.DecodeRequest(valid.AsSpan(1)));
        Assert.Throws<ArgumentException>(() => WorkshopMemoryWire.DecodeRequest(new byte[65]));
    }

    [Fact]
    public void StoppedMemoryResultRejectsUnboundedOrFabricatedMetrics()
    {
        var sample = new WorkshopMemoryResult(MemoryRequest, WorkshopMemoryStatus.Accepted,
            1234, 1200, 19, 1_000_000_000, 5000, 5050, 6, 7);
        foreach (var invalid in new[] {
            sample with { UsedBefore = -1 }, sample with { UsedAfter = -1 },
            sample with { DurationTicks = -1 }, sample with { Frequency = 0 },
            sample with { AllocatedBefore = -1 }, sample with { AllocatedAfter = 4999 },
            sample with { CollectionsBefore = -1 }, sample with { CollectionsAfter = 5 },
            sample with { Status = (WorkshopMemoryStatus)uint.MaxValue },
            sample with { Status = WorkshopMemoryStatus.Busy } })
            Assert.Throws<ArgumentException>(() => WorkshopMemoryWire.Encode(invalid));
        var malformed = WorkshopMemoryWire.Encode(sample);
        malformed[120] = 1;
        Assert.Throws<ArgumentException>(() => WorkshopMemoryWire.DecodeResult(malformed));
        Assert.Throws<ArgumentException>(() => WorkshopMemoryWire.DecodeResult(new byte[127]));
        Assert.Throws<ArgumentException>(() => WorkshopMemoryWire.DecodeResult(new byte[129]));
        foreach (var status in new[] { WorkshopMemoryStatus.Busy, WorkshopMemoryStatus.Stale, WorkshopMemoryStatus.Unsupported })
        {
            var rejection = new WorkshopMemoryResult(MemoryRequest, status);
            Assert.Equal(rejection, WorkshopMemoryWire.DecodeResult(WorkshopMemoryWire.Encode(rejection)));
        }
    }
}
