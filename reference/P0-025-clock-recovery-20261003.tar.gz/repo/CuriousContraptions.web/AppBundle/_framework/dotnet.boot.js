export const config = /*json-start*/{
  "mainAssemblyName": "CuriousContraptions.web.dll",
  "resources": {
    "hash": "sha256-FBsxW5z7lxVla9fglgjy/90rx6tQU7E/gMH8/f4vS/c=",
    "jsModuleNative": [
      {
        "name": "dotnet.native.js"
      }
    ],
    "jsModuleRuntime": [
      {
        "name": "dotnet.runtime.js"
      }
    ],
    "wasmNative": [
      {
        "name": "dotnet.native.wasm",
        "hash": "sha256-vTnpcET1R3XtV9FhXzFBL8hj8lOO2MxHPY1OiSZv8Ig="
      }
    ],
    "wasmSymbols": [
      {
        "name": "dotnet.native.js.symbols"
      }
    ],
    "icu": [
      {
        "virtualPath": "icudt_CJK.dat",
        "name": "icudt_CJK.dat",
        "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk="
      },
      {
        "virtualPath": "icudt_EFIGS.dat",
        "name": "icudt_EFIGS.dat",
        "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc="
      },
      {
        "virtualPath": "icudt_no_CJK.dat",
        "name": "icudt_no_CJK.dat",
        "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs="
      }
    ],
    "coreAssembly": [
      {
        "virtualPath": "System.Private.CoreLib.wasm",
        "name": "System.Private.CoreLib.wasm",
        "hash": "sha256-yg8BmJkldI3nA+RANW5i8Bk9YLWvGx6XjYvPZpkm2Dg="
      },
      {
        "virtualPath": "System.Runtime.InteropServices.JavaScript.wasm",
        "name": "System.Runtime.InteropServices.JavaScript.wasm",
        "hash": "sha256-6oZGbt4Q+ny14D/RwxFOsPh6TWXvGA35LUQNi2147Is="
      }
    ],
    "assembly": [
      {
        "virtualPath": "CuriousContraptions.Animation.wasm",
        "name": "CuriousContraptions.Animation.wasm",
        "hash": "sha256-uB6x0qQjeUvDeTuQdqC1Y1Rmvv5zgk8ybXvDPY+ZHH8="
      },
      {
        "virtualPath": "CuriousContraptions.wasm",
        "name": "CuriousContraptions.wasm",
        "hash": "sha256-2IYlMxxkvYBSCzD5P9KqbQw7jd9c3q/o1saMf9AiCDQ="
      },
      {
        "virtualPath": "CuriousContraptions.web.wasm",
        "name": "CuriousContraptions.web.wasm",
        "hash": "sha256-aQpfpvP4fwVO8VyWrHZBQNxK7zQX6YCetTZvDS8xKik="
      },
      {
        "virtualPath": "GodotSharp.wasm",
        "name": "GodotSharp.wasm",
        "hash": "sha256-aKVww1ALS8kP0QgMRPVc4SVWwJ0TqV30G5a/izSw8qs="
      },
      {
        "virtualPath": "System.Collections.Concurrent.wasm",
        "name": "System.Collections.Concurrent.wasm",
        "hash": "sha256-/DcaYiJD9dBWW8Txi0sp7OCaMe/UoMANnXSQqjRgF4E="
      },
      {
        "virtualPath": "System.Collections.wasm",
        "name": "System.Collections.wasm",
        "hash": "sha256-wF4BdwtLrYGn+1YgRuafvqPBtUtLZXsbYpfvlgH+3Gs="
      },
      {
        "virtualPath": "System.Collections.Immutable.wasm",
        "name": "System.Collections.Immutable.wasm",
        "hash": "sha256-/MwkyEdajj6W9YOhRDXzYdsIRtoED+kmFKxVBRlmYgI="
      },
      {
        "virtualPath": "System.Console.wasm",
        "name": "System.Console.wasm",
        "hash": "sha256-KLhV+5bTo/WCHe9xaF0OASrRvOtTUTs4IhIc4n3fIRE="
      },
      {
        "virtualPath": "System.Diagnostics.StackTrace.wasm",
        "name": "System.Diagnostics.StackTrace.wasm",
        "hash": "sha256-QgGkpXpDCTbQuwQztoiguKMu+V0tHMKuahovQz47gSk="
      },
      {
        "virtualPath": "System.Diagnostics.TraceSource.wasm",
        "name": "System.Diagnostics.TraceSource.wasm",
        "hash": "sha256-t9zzgdgUKlRplKzpEsGTSbdahonKam7bV79adP2nLPU="
      },
      {
        "virtualPath": "System.Linq.wasm",
        "name": "System.Linq.wasm",
        "hash": "sha256-WlNrcNcunH7njvaWZmKDLJ4tqoOiypccHk1XY/2/WY8="
      },
      {
        "virtualPath": "System.Memory.wasm",
        "name": "System.Memory.wasm",
        "hash": "sha256-OIZ4HwAqwx2oLiKOYrM7gesQIslqBah26x49ultUFew="
      },
      {
        "virtualPath": "System.Private.Uri.wasm",
        "name": "System.Private.Uri.wasm",
        "hash": "sha256-SKO5F/CrtIZb6D6tUlCBrawOuXly3onKxh/MX0yxy9g="
      },
      {
        "virtualPath": "System.Runtime.wasm",
        "name": "System.Runtime.wasm",
        "hash": "sha256-M7mykYXl05B9ylOexlftN1ZHKhwTDdlHasLHvyFl9aE="
      },
      {
        "virtualPath": "System.Runtime.InteropServices.wasm",
        "name": "System.Runtime.InteropServices.wasm",
        "hash": "sha256-eIgC+GC76OUeMSnVyDL+slksGJ2WfARv/ME58q9PVUU="
      },
      {
        "virtualPath": "System.Runtime.Loader.wasm",
        "name": "System.Runtime.Loader.wasm",
        "hash": "sha256-UaTF/sBHx3iQpQ9oPORd2zLI/0sqWWMHLreV7NJ5oRc="
      },
      {
        "virtualPath": "System.Security.Cryptography.wasm",
        "name": "System.Security.Cryptography.wasm",
        "hash": "sha256-dsiK29h49cT3/TIKPI4JNxstOFgq+lHOLrwZJpNkVHg="
      },
      {
        "virtualPath": "System.Text.RegularExpressions.wasm",
        "name": "System.Text.RegularExpressions.wasm",
        "hash": "sha256-t0Ha/2ltXPrrKiAhVsY8CN/f6FdGBcLW4RHpDU6xRDI="
      },
      {
        "virtualPath": "System.Threading.wasm",
        "name": "System.Threading.wasm",
        "hash": "sha256-FwyDcZnxeMqBKWhHxRy85Odxpr9oN9FZppBlGA6sZHE="
      },
      {
        "virtualPath": "twodog.wasm",
        "name": "twodog.wasm",
        "hash": "sha256-JktIsl36QtQdjjg3y75mYFTVDG8G7Jzwcx2F8k7JieI="
      }
    ]
  },
  "debugLevel": 0,
  "globalizationMode": "sharded",
  "runtimeConfig": {
    "runtimeOptions": {
      "configProperties": {
        "Microsoft.Extensions.DependencyInjection.VerifyOpenGenericServiceTrimmability": true,
        "System.ComponentModel.DefaultValueAttribute.IsSupported": false,
        "System.ComponentModel.Design.IDesignerHost.IsSupported": false,
        "System.ComponentModel.TypeConverter.EnableUnsafeBinaryFormatterInDesigntimeLicenseContextSerialization": false,
        "System.ComponentModel.TypeDescriptor.IsComObjectDescriptorSupported": false,
        "System.Data.DataSet.XmlSerializationIsSupported": false,
        "System.Diagnostics.Debugger.IsSupported": false,
        "System.Diagnostics.Metrics.Meter.IsSupported": false,
        "System.Diagnostics.Tracing.EventSource.IsSupported": false,
        "System.Globalization.Invariant": false,
        "System.TimeZoneInfo.Invariant": false,
        "System.Linq.Enumerable.IsSizeOptimized": true,
        "System.Net.Http.EnableActivityPropagation": false,
        "System.Net.Http.WasmEnableStreamingResponse": true,
        "System.Net.SocketsHttpHandler.Http3Support": false,
        "System.Reflection.Metadata.MetadataUpdater.IsSupported": false,
        "System.Resources.ResourceManager.AllowCustomResourceTypes": false,
        "System.Resources.UseSystemResourceKeys": true,
        "System.Runtime.CompilerServices.RuntimeFeature.IsDynamicCodeSupported": true,
        "System.Runtime.InteropServices.BuiltInComInterop.IsSupported": false,
        "System.Runtime.InteropServices.EnableConsumingManagedCodeFromNativeHosting": false,
        "System.Runtime.InteropServices.EnableCppCLIHostActivation": false,
        "System.Runtime.InteropServices.Marshalling.EnableGeneratedComInterfaceComImportInterop": false,
        "System.Runtime.Serialization.EnableUnsafeBinaryFormatterSerialization": false,
        "System.StartupHookProvider.IsSupported": false,
        "System.Text.Encoding.EnableUnsafeUTF7Encoding": false,
        "System.Text.Json.JsonSerializer.IsReflectionEnabledByDefault": false,
        "System.Threading.Thread.EnableAutoreleasePool": false
      }
    }
  }
}/*json-end*/;