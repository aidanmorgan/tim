// One P025 proof attempt. Inject the exact independently reviewed collector,
// admission and trial functions; this file contains no asset-map copy.
// Evaluate this expression once. Reviewer calls installRetained(page), attests
// the guarded empty BUILD scene/current-navigation console, then sets only
// page.__p025IdleLease.approved=true and calls run(page, collect, admit, trials).
(() => {
  const origin = 'http://127.0.0.1:8060';
  const marker = 'P025_OWNED_GUARD ';
  const stateKey = '__p025OwnedGuard';
  const expectedController = origin + '/workshop-isolation-worker.js';
  function documentGuard(options) {
    const key = '__p025OwnedGuard', prefix = 'P025_OWNED_GUARD ';
    if (globalThis[key]) throw Error('P025 guard already installed');
    const g = globalThis[key] = { role: options.role, origin: performance.timeOrigin,
      events: [], errors: [], overflow: false, released: false, permit: null, phase: 'Preparation', strictAt: null,
      controller: navigator.serviceWorker.controller?.scriptURL, registration: null, registrationSettled: false };
    const listeners = [];
    const add = (object, name, fn) => { object.addEventListener(name, fn, true); listeners.push([object, name, fn]); };
    const fail = reason => {
      if (g.errors.length < 16) g.errors.push(reason);
      console.info(prefix + JSON.stringify({ reason, origin: g.origin, role: g.role }));
    };
    const note = row => {
      if (g.events.length >= 256) { if (!g.overflow) fail('document event cap'); g.overflow = true; return; }
      g.events.push({ at: performance.now(), ...row });
    };
    const input = event => {
      if (!event.isTrusted) return;
      const row = { type: event.type, x: event.clientX ?? null, y: event.clientY ?? null,
        buttons: event.buttons ?? null, button: event.button ?? null, pointerType: event.pointerType ?? null,
        altKey: !!event.altKey, ctrlKey: !!event.ctrlKey, metaKey: !!event.metaKey, shiftKey: !!event.shiftKey,
        phase: g.phase };
      note(row);
      const unpressedMouseMotion = event.buttons === 0 &&
        (event.type === 'mousemove' || (event.type === 'pointermove' && event.pointerType === 'mouse'));
      if (g.phase === 'Preparation' && unpressedMouseMotion) return;
      const p = g.permit;
      if (g.role !== 'target' || !p || event.clientX !== p.x || event.clientY !== p.y) {
        fail('unexpected trusted input: ' + event.type); return;
      }
      const expected = ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'];
      if (unpressedMouseMotion && p.index === 0 && !p.moves.includes(event.type)) {
        p.moves.push(event.type); return;
      }
      if (event.type !== expected[p.index]) { fail('input sequence mismatch: ' + event.type); return; }
      p.index++;
    };
    g.enterStrict = () => {
      if (g.released || g.errors.length || g.overflow || g.phase !== 'Preparation')
        throw Error('guard cannot enter strict phase');
      g.phase = 'Strict'; g.strictAt = performance.now();
      note({ type: 'strict transition', phase: g.phase });
      return { phase: g.phase, at: g.strictAt, origin: g.origin };
    };
    for (const name of ['pointermove', 'mousemove', 'pointerdown', 'mousedown',
      'pointerup', 'mouseup', 'click', 'dblclick', 'keydown', 'keyup', 'beforeinput',
      'input', 'change', 'wheel', 'touchstart', 'touchend', 'contextmenu']) add(document, name, input);
    add(document, 'visibilitychange', () => {
      note({ type: 'visibilitychange', hidden: document.hidden });
      if (g.role === 'target' && document.hidden) fail('target lost foreground');
    });
    add(navigator.serviceWorker, 'controllerchange', () => fail('controller changed'));
    let timer;
    const detach = () => {
      for (const [object, name, fn] of listeners) object.removeEventListener(name, fn, true);
      clearTimeout(timer); g.released = true;
    };
    g.release = () => { detach(); const proof = { released: g.released, events: g.events, errors: g.errors, overflow: g.overflow, origin: g.origin, registrationSettled: g.registrationSettled, phase: g.phase, strictAt: g.strictAt }; delete globalThis[key]; return proof; };
    timer = setTimeout(() => { fail('guard lease expired'); detach(); }, 180000);
    g.ready = navigator.serviceWorker.getRegistration().then(registration => {
      if (g.released) return;
      if (!registration) { fail('service worker registration absent'); return; }
      g.registration = registration;
      add(registration, 'updatefound', () => fail('service worker update found'));
      if (registration.waiting || registration.installing || registration.scope !== location.origin + '/' ||
          registration.active?.scriptURL !== g.controller || !navigator.serviceWorker.controller ||
          navigator.serviceWorker.controller.scriptURL !== options.controller) fail('service worker policy changed');
    }).catch(error => { if (!g.released) fail(String(error)); }).finally(() => { g.registrationSettled = true; });
    if (g.role === 'target' && document.hidden) fail('target started hidden');
  }
async function readState(page, allowBooting = false) {
    return await page.evaluate(async allowBooting => {
      const g = globalThis.__p025OwnedGuard;
      if (!g) throw Error('guard absent');
      await g.ready;
      const m = await import('./workshop-client.js');
      let runtime;
      try { runtime = { mode: m.captureMode(1), status: m.status(1), clock: m.clockProfileEvidence(1) }; }
      catch (error) { if (!allowBooting) throw error; runtime = { bootingReadError: String(error) }; }
      return { origin: performance.timeOrigin, ...runtime, controller: navigator.serviceWorker.controller?.scriptURL,
        waiting: !!g.registration?.waiting, installing: !!g.registration?.installing,
        active: g.registration?.active?.scriptURL, scope: g.registration?.scope,
        visible: !document.hidden, errors: g.errors.slice(), overflow: g.overflow,
        released: g.released, guardOrigin: g.origin, events: g.events.slice(), phase: g.phase, strictAt: g.strictAt };
    }, allowBooting);
  }
  function validState(state) {
    const s = state.clock?.serving;
    return state.mode === 1 && state.status === 0 && !state.waiting && !state.installing &&
      state.controller === expectedController && state.active === expectedController &&
      state.scope === origin + '/' && state.guardOrigin === state.origin &&
      !state.released && !state.overflow && state.errors.length === 0 &&
      s?.policyVersion === 1 && s.phase === 2 && s.isolated && s.controlled && s.scope === origin + '/';
  }
  async function installRetained(page) {
    if (page.__p025IdleLease) throw Error('retained lease already exists');
    if (page.url() !== origin + '/' || page.workers().length !== 1) throw Error('retained context mismatch');
    const worker = page.workers()[0];
    const lease = page.__p025IdleLease = { version: 1, approved: false, worker,
      origin: null, errors: [], events: [], overflow: false, released: false,
      installed: Date.now(), retainedSessionId: 'unobserved', attestation: null };
    const refs = [];
    const note = (type, detail) => {
      if (lease.events.length >= 256) { lease.overflow = true; if (!lease.errors.includes('retained event cap')) lease.errors.push('retained event cap'); return; }
      lease.events.push({ at: Date.now(), type, detail: String(detail).slice(0, 2048) });
    };
    const fail = (type, detail) => { note(type, detail); if (lease.errors.length < 16) lease.errors.push(type + ': ' + String(detail).slice(0, 2048)); };
    const on = (object, name, fn) => { object.on(name, fn); refs.push([object, name, fn]); };
    on(page, 'console', message => {
      const text = message.text();
      if (text.startsWith(marker) || text.startsWith('CCGPU ') || message.type() === 'error') fail('retained console', text);
    });
    on(page, 'pageerror', error => fail('retained pageerror', error));
    on(page, 'framenavigated', frame => { if (frame === page.mainFrame()) fail('retained navigation', frame.url()); });
    on(page, 'load', () => fail('retained load', page.url()));
    on(page, 'request', request => fail('retained new request', request.url()));
    on(page, 'worker', value => fail('retained new worker', value.url()));
    on(worker, 'close', () => fail('retained worker closed', worker.url()));
    on(page, 'close', () => fail('retained page closed', ''));
    lease.check = async () => {
      if (lease.released || Date.now() - lease.installed >= 180000 || lease.errors.length || lease.overflow) throw Error('retained lease invalid: ' + lease.errors.join('; '));
      const state = await readState(page);
      if (!validState(state) || state.origin !== lease.origin || page.url() !== origin + '/' ||
          page.workers().length !== 1 || page.workers()[0] !== worker) throw Error('retained context/guard changed');
      return state;
    };
    lease.release = async () => {
      for (const [object, name, fn] of refs) object.off(name, fn);
      lease.released = true;
      let document;
      try { document = await page.evaluate(() => globalThis.__p025OwnedGuard?.release()); }
      catch (error) { document = { error: String(error) }; }
      const proof = { released: true, installed: lease.installed, approved: lease.approved,
        origin: lease.origin, retainedSessionId: lease.retainedSessionId, attestation: lease.attestation,
        events: lease.events, errors: lease.errors, overflow: lease.overflow, document };
      delete page.__p025IdleLease;
      return proof;
    };
    let setupSettled = false, deadlineArmed = true;
    const deadline = page.waitForTimeout(10000).then(() => {
      if (deadlineArmed) throw Error('retained installer exceeded10s');
    });
    deadline.catch(() => {});
    const setup = (async () => {
      await page.evaluate(documentGuard, { role: 'retained', controller: expectedController });
      const state = await readState(page);
      lease.origin = state.origin;
      if (!validState(state) || lease.errors.length) throw Error('retained initial guard state invalid');
      return { installed: lease.installed, origin: lease.origin, workerUrl: worker.url(),
        approved: false, state, requirement: 'Reviewer must now attest empty BUILD and current-navigation console while this guard remains active.' };
    })().then(value => { setupSettled = true; return value; }, error => { setupSettled = true; throw error; });
    setup.catch(() => {});
    try {
      return await Promise.race([setup, deadline]);
    } catch (error) {
      lease.errors.push(String(error));
      let cleanup, cleanupSettled = false;
      const cleanupWork = lease.release().then(value => { cleanup = value; cleanupSettled = true; },
        failure => { cleanup = { error: String(failure) }; cleanupSettled = true; });
      const cleanupWait = page.waitForTimeout(2000).catch(failure => { cleanup = { ...cleanup, waitError: String(failure) }; });
      await Promise.race([cleanupWork, cleanupWait]);
      await cleanupWait;
      return { error: String(error), cleanup, pendingSetup: !setupSettled, pendingCleanup: !cleanupSettled };
    } finally {
      deadlineArmed = false;
      await deadline.catch(() => {});
    }
  }
  async function run(retained, collect, admit, trials) {
    const result = { verdict: 'Incomplete', started: Date.now(), errors: [], events: [],
      limits: { wallMs: 120000, cleanupMs: 2000, events: 512, clicks: 18 },
      retainedSessionId: 'unobserved', cleanup: {} };
    const lease = retained.__p025IdleLease;
    if (!lease || lease.version !== 1 || !lease.approved || !lease.attestation)
      return { ...result, errors: ['Missing independently attested retained idle lease.'] };
    let target, phase = 'initial', active = true, monitor, expectedAck = null, actionIndex = 0;
    let ackSession, previousSequence = 1n, navCount = 0, boundWorker, boundOrigin;
    let originalClick, originalDescriptor;
    const refs = [], operations = [];
    let rejectFailure;
    const failure = new Promise((resolve, reject) => { rejectFailure = reject; });
    failure.catch(() => {});
    const fail = reason => {
      if (result.errors.length < 32) result.errors.push(String(reason).slice(0, 2048));
      if (target?.__p025Matched) target.__p025Matched.stopped = true;
      rejectFailure(Error(String(reason)));
    };
    const note = (type, detail) => {
      if (result.events.length >= result.limits.events) { fail('host event cap'); return; }
      result.events.push({ at: Date.now(), phase, type, detail });
    };
    const on = (object, name, fn) => { object.on(name, fn); refs.push([object, name, fn]); };
    const bounded = async (label, promise) => {
      const op = { label, settled: false }; operations.push(op);
      const tracked = Promise.resolve(promise).then(value => { op.settled = true; return value; },
        error => { op.settled = true; throw error; });
      tracked.catch(() => {});
      return await Promise.race([tracked, failure]);
    };
    const bytes = text => {
      const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/', values = [];
      let value = 0, bits = 0;
      for (const letter of text) { const k = alphabet.indexOf(letter); if (k < 0) continue;
        value = (value << 6) | k; bits += 6; if (bits >= 8) { bits -= 8; values.push((value >> bits) & 255); } }
      return new Uint8Array(values);
    };
    const actions = [{ x: 128, y: 154, phase: null }, { x: 720, y: 350, phase: 2 }];
    for (let i = 0; i < 8; i++) actions.push({ x: 686, y: 836, phase: 5 }, { x: 686, y: 836, phase: 2 });
    const check = async () => {
      if (result.errors.length) throw Error(result.errors.join('; '));
      const retainedState = await lease.check();
      if (retainedState.phase !== 'Strict') throw Error('retained guard is not strict');
      const state = await readState(target);
      if (!validState(state) || state.phase !== 'Strict' || !state.visible || state.origin !== boundOrigin ||
          target.workers().length !== 1 || target.workers()[0] !== boundWorker || boundWorker === lease.worker)
        throw Error('target identity/visibility/worker guard changed');
      return state;
    };
    try {
      monitor = (async () => {
        while (active) {
          await retained.waitForTimeout(100);
          if (!active) break;
          if (Date.now() - result.started >= result.limits.wallMs) { fail('combined wall deadline'); break; }
          if (lease.errors.length || lease.overflow || lease.released) { fail('retained guard violation'); break; }
        }
      })().catch(error => { if (active) fail(error); });
      result.retainedBefore = await bounded('retained preflight', lease.check());
      target = await bounded('owned page creation', retained.context().newPage());
      target.setDefaultTimeout(10000);
      target.setDefaultNavigationTimeout(10000);
      on(target, 'console', message => {
        const text = message.text();
        if (message.type() === 'error' || text.startsWith(marker)) { fail('target console: ' + text); return; }
        if (!text.startsWith('CCGPU ')) return;
        note('ACK', text);
        try {
          if (!expectedAck || phase !== 'trials') throw Error('unsolicited ACK');
          const b = bytes(text.split(' ')[1]);
          if (b.length !== 192) throw Error('ACK size');
          const d = new DataView(b.buffer), sequence = d.getBigUint64(0, true);
          const session = Array.from(b.slice(64, 80), x => x.toString(16).padStart(2, '0')).join('');
          if (d.getUint32(8, true) !== 0 || d.getUint32(12, true) !== 0 || d.getUint32(16, true) !== 0 ||
              d.getUint32(20, true) !== expectedAck.phase || d.getUint32(52, true) !== 4 ||
              d.getBigUint64(32, true) !== 0n || sequence !== previousSequence + 1n ||
              (ackSession && session !== ackSession)) throw Error('ACK permit mismatch');
          ackSession = session; previousSequence = sequence; expectedAck = null;
        } catch (error) { fail(error); }
      });
      on(target, 'pageerror', error => fail('target pageerror: ' + error));
      on(target, 'framenavigated', frame => {
        if (frame !== target.mainFrame()) return;
        navCount++; note('navigation', frame.url());
        if (frame.url() !== origin + '/' || !((phase === 'bootstrap' && navCount === 1) ||
            (phase === 'identities' && navCount === 2))) fail('unexpected target navigation');
      });
      on(target, 'load', () => {
        note('load', target.url());
        if (phase !== 'bootstrap' && phase !== 'identities') fail('unexpected target load');
      });
      on(target, 'request', request => { if (phase === 'admission' || phase === 'trials') fail('new target request after identity closure: ' + request.url()); });
      on(target, 'worker', worker => {
        note('worker', worker.url());
        if (phase !== 'bootstrap' && phase !== 'identities') fail('new target worker after identity closure');
        on(worker, 'close', () => { if (phase === 'admission' || phase === 'trials') fail('bound target worker closed'); });
      });
      await bounded('viewport', target.setViewportSize({ width: 1440, height: 900 }));
      await bounded('init guard', target.addInitScript(documentGuard, { role: 'target', controller: expectedController }));
      await bounded('foreground', target.bringToFront());
      phase = 'bootstrap';
      await bounded('ordinary bootstrap', target.goto(origin + '/', { waitUntil: 'load', timeout: 10000 }));
      const bootstrapDeadline = Date.now() + 10000;
      while (true) {
        const state = await bounded('bootstrap qualified state read', readState(target, true));
        if (state.errors.length || state.overflow || state.released || !state.visible ||
            (state.status !== undefined && state.status !== 0) || (state.mode !== undefined && state.mode !== 1))
          throw Error('bootstrap guard or runtime terminal state');
        const qualified = profile => Array.isArray(profile) && profile.length === 7 &&
          profile.every(Number.isFinite) && profile[0] === 2 && profile[1] === 1 && profile[2] === 1 &&
          profile[3] >= 0 && profile[4] > 0 && profile[4] <= 0.007 &&
          Number.isSafeInteger(profile[5]) && profile[5] > 0 && profile[6] >= profile[3];
        if (validState(state) && qualified(state.clock?.browser) && qualified(state.clock?.worker) &&
            target.workers().length === 1 && target.workers()[0].url() === origin + '/simulation/worker.js') break;
        if (Date.now() >= bootstrapDeadline) throw Error('ordinary bootstrap Ready deadline');
        await target.waitForTimeout(50);
      }
      result.bootstrap = await bounded('bootstrap guard read', readState(target));
      if (!validState(result.bootstrap) || !result.bootstrap.visible || navCount !== 1) throw Error('bootstrap guard failed');
      await bounded('retained before collector', lease.check());
      phase = 'identities';
      result.identities = await bounded('unchanged collector', collect(target));
      if (result.identities.verdict !== 'IdentitiesCompletePendingReviewerReadyAndSessionAdmission' || navCount !== 2)
        throw Error('loaded identity prerequisite incomplete');
      // The init guard runs in each document. The collector reload must replace
      // bootstrap origin, and only its final document may enter admission.
      const current = await bounded('new document guard read', readState(target));
      if (current.origin === result.bootstrap.origin || !validState(current) || !current.visible) throw Error('collector document/guard mismatch');
      // Preparation permits only logged mouse movement with no button held.
      // Both irreversible transitions precede every admission check and UI action.
      result.strictTransition = {
        retained: await bounded('retained strict transition', retained.evaluate(() => globalThis.__p025OwnedGuard.enterStrict())),
        target: await bounded('target strict transition', target.evaluate(() => globalThis.__p025OwnedGuard.enterStrict()))
      };
      phase = 'admission';
      result.retainedStrictState = await bounded('strict retained state', lease.check());
      if (result.retainedStrictState.phase !== 'Strict') throw Error('retained strict transition missing');
      const retainedImage = await bounded('strict retained visual', retained.screenshot({ type: 'png', timeout: 10000 }));
      if (retainedImage.length > 2097152) throw Error('retained screenshot exceeded2MiB');
      result.retainedStrictVisual = { mimeType: 'image/png', base64: retainedImage.toString('base64'),
        byteLength: retainedImage.length, independentVisualReviewRequired: true };
      result.admission = await bounded('unchanged admission', admit(target));
      if (result.admission.verdict !== 'ReadyProductionClockIsolationWorkerAdmissionPass') throw Error('Ready admission incomplete');
      boundOrigin = target.__p025IdentityGate.origin; boundWorker = target.__p025IdentityGate.worker;
      result.beforeTrials = await bounded('both-page admission', check());
      originalClick = target.mouse.click;
      originalDescriptor = Object.getOwnPropertyDescriptor(target.mouse, 'click');
      target.mouse.click = async (x, y, options) => {
        await check();
        const action = actions[actionIndex];
        if (!action || action.x !== x || action.y !== y || options !== undefined || expectedAck) throw Error('action whitelist/ACK boundary mismatch');
        await target.evaluate(({ x, y }) => {
          const g = globalThis.__p025OwnedGuard;
          if (g.errors.length || g.released || g.permit) throw Error('input guard cannot arm');
          g.permit = { x, y, index: 0, moves: [] };
        }, { x, y });
        expectedAck = action.phase === null ? null : { phase: action.phase };
        note('authorized click', { index: actionIndex++, x, y, phase: action.phase });
        await originalClick.call(target.mouse, x, y);
        const input = await target.evaluate(() => {
          const g = globalThis.__p025OwnedGuard, permit = g.permit; g.permit = null;
          return { permit, errors: g.errors.slice(), overflow: g.overflow };
        });
        if (input.permit?.index !== 5 || input.errors.length || input.overflow) throw Error('trusted click sequence incomplete');
        if (result.errors.length) throw Error('continuous guard failed during action');
      };
      phase = 'trials';
      result.trials = await bounded('unchanged original six-trial protocol', trials(target));
      result.afterTrials = await bounded('final both-page check', check());
      if (result.trials.stopped || result.trials.errors.length || result.trials.trials.length !== 6 ||
          result.trials.warmup.length !== 2 || actionIndex !== 18 || expectedAck || previousSequence !== 18n)
        throw Error('original trial protocol incomplete');
      result.targetSession = ackSession;
      result.verdict = 'SixReportedCounterContrastsCompletePendingIndependentReview';
    } catch (error) {
      fail(error);
      if (!result.trials && target?.__p025Matched) result.partialTrials = target.__p025Matched;
    } finally {
      active = false; phase = 'cleanup';
      if (target?.__p025Matched && result.errors.length) target.__p025Matched.stopped = true;
      if (target && originalClick) {
        if (originalDescriptor) Object.defineProperty(target.mouse, 'click', originalDescriptor);
        else delete target.mouse.click;
      }
      for (const [object, name, fn] of refs) object.off(name, fn);
      // Closing ONLY the owned target is the supported cancellation boundary.
      // A timed-out underlying operation is not claimed cancelled or settled.
      let cleanupExpired = false;
      const cleanupWait = retained.waitForTimeout(result.limits.cleanupMs).then(() => { cleanupExpired = true; },
        error => { cleanupExpired = true; result.cleanup.waitError = String(error); });
      const cleanupWork = (async () => {
        if (target && !target.isClosed()) {
          await target.close({ runBeforeUnload: false });
          result.cleanup.targetClosed = true;
        }
        if (monitor) await monitor;
        result.cleanup.retained = await lease.release();
        const document = result.cleanup.retained?.document;
        if (!document || document.released !== true || document.registrationSettled !== true || document.error)
          throw Error('retained document cleanup unconfirmed');
        result.cleanup.completed = true;
      })().catch(error => { result.cleanup.error = String(error); });
      await Promise.race([cleanupWork, cleanupWait]);
      await cleanupWait;
      result.cleanup.deadlineReached = cleanupExpired && !result.cleanup.completed;
      result.cleanup.cleanupOperationPending = !result.cleanup.completed && !result.cleanup.error;
      result.cleanup.pendingOperations = operations.filter(x => !x.settled).map(x => x.label);
      if (!result.cleanup.completed || result.cleanup.waitError || result.cleanup.pendingOperations.length || result.errors.length) result.verdict = 'Incomplete';
      result.finished = Date.now();
      result.summary = { verdict: result.verdict, started: result.started, finished: result.finished,
        identityRecords: result.identities?.records?.length ?? 0,
        trials: result.trials?.trials?.length ?? 0, errors: result.errors,
        cleanupComplete: result.cleanup.completed === true, pendingOperations: result.cleanup.pendingOperations };
    }
    return result;
  }
  return { installRetained, run };
})()
