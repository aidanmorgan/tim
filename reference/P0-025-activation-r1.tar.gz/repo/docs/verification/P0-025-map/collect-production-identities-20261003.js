// One bounded read-only identity collector plus the explicitly authorized same-origin reload.
// Original failed setup remains in reviewer-continuation-20261003.json.
// Expected identities are the normal Production activation-handoff export;
// implementation-progress.json retains the exact delta from the original preparation.
// The independent reviewer must establish Ready/mode/session/worker/clock applicability
// after this collector succeeds and before the unchanged warmups or measured trials.
async (page) => {
  const expected = {
    ".stamp": {
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    "404.html": {
      "bytes": 626,
      "sha256": "203665008980c85bb038aaee6b5224568ffe531e21cdbafd43b9591939e8f7a9"
    },
    "CuriousContraptions.web.runtimeconfig.json": {
      "bytes": 2323,
      "sha256": "62f5ab8307fc3d3687946be6f0cf52382f6cf379aaf91e5b56c8267857db00c0"
    },
    "_framework/CuriousContraptions.Animation.wasm": {
      "bytes": 33557,
      "sha256": "b81eb1d2a423794bc3793b9076a0b5635466befe73824f326d7bc33d8f991c7f"
    },
    "_framework/CuriousContraptions.wasm": {
      "bytes": 305941,
      "sha256": "41d9504d3ba3db538aea24664efad63edb60802d2ae1fdcc16cc5e61936fb4cb"
    },
    "_framework/CuriousContraptions.web.wasm": {
      "bytes": 6933,
      "sha256": "2f20eb8429080e114842434856f45b8688f239a353806adc15c154b75742a55d"
    },
    "_framework/GodotSharp.wasm": {
      "bytes": 5656857,
      "sha256": "68a570c3500b4bc90fd1080c44f55ce12556c09d13a95df41b96bf8b34b0f2ab"
    },
    "_framework/System.Collections.Concurrent.wasm": {
      "bytes": 24341,
      "sha256": "fc371a622243f5d0565bc4f18b4b29ece09a31efd4a0c00d9d7490aa34601781"
    },
    "_framework/System.Collections.Immutable.wasm": {
      "bytes": 42261,
      "sha256": "fccc24c8475a8e3e96f583a14435f361db0846da040fe92614ac550519666202"
    },
    "_framework/System.Collections.wasm": {
      "bytes": 12053,
      "sha256": "c05e01770b4bad81a7fb562046e69fbea3c1b54b4b657b1b6297ef9601fedc6b"
    },
    "_framework/System.Console.wasm": {
      "bytes": 15125,
      "sha256": "28b855fb96d3a3f5821def71685d0e012ad1bceb53513b3822121ce27ddf2111"
    },
    "_framework/System.Diagnostics.StackTrace.wasm": {
      "bytes": 4885,
      "sha256": "4201a4a57a430936d0bb0433b688a0b8a32ef95d2d1cc2ae6a1a2f433e3b8129"
    },
    "_framework/System.Diagnostics.TraceSource.wasm": {
      "bytes": 11029,
      "sha256": "b7dcf381d8142a546994ace912c19349b75a8689ca6a6edb57bf5a74fda72cf5"
    },
    "_framework/System.Linq.wasm": {
      "bytes": 30485,
      "sha256": "5a536b70d72e9c7ee78ef6966662832c9e2daa83a2ca971c1e4d5763fdbf598f"
    },
    "_framework/System.Memory.wasm": {
      "bytes": 7445,
      "sha256": "3886781f002ac31da82e228e62b33b81eb1022c96a05a876eb1e3dba5b5415ec"
    },
    "_framework/System.Private.CoreLib.wasm": {
      "bytes": 1480469,
      "sha256": "ca0f01989925748de703e440356e62f0193d60b5af1b1e978d8bcf669926d838"
    },
    "_framework/System.Private.Uri.wasm": {
      "bytes": 65813,
      "sha256": "48a3b917f0abb4865be83ead525081adac0eb97972de89cac61fcc5f4cb1cbd8"
    },
    "_framework/System.Runtime.InteropServices.JavaScript.wasm": {
      "bytes": 46869,
      "sha256": "ea86466ede10fa7cb5e03fd1c3114eb0f87a4d65ef180df92d440d8b6d78ec8b"
    },
    "_framework/System.Runtime.InteropServices.wasm": {
      "bytes": 8981,
      "sha256": "788802f860bbe8e51e3129d5c832feb2592c189d967c046ffcc139f2af4f5545"
    },
    "_framework/System.Runtime.Loader.wasm": {
      "bytes": 4885,
      "sha256": "51a4c5fec047c77890a50f683ce45ddb32c8ff4b2a5963072eb795ecd279a117"
    },
    "_framework/System.Runtime.wasm": {
      "bytes": 12053,
      "sha256": "33b9b29185e5d3907dca539ec657ed3756472a1c130dd9476ac2c7bf2165f5a1"
    },
    "_framework/System.Security.Cryptography.wasm": {
      "bytes": 20245,
      "sha256": "76c88adbd878f5c4f7fd320a3c8e09371b2d38582afa51ce2ebc192693645478"
    },
    "_framework/System.Text.RegularExpressions.wasm": {
      "bytes": 246037,
      "sha256": "b741daff696d5cfaeb2a202156c63c08dfdfe8574605c2d6e111e90d4eb14432"
    },
    "_framework/System.Threading.wasm": {
      "bytes": 12053,
      "sha256": "170c837199f178ca81296847c51cbce4e771a6bf6837d159a69065180eac6471"
    },
    "_framework/dotnet.boot.js": {
      "bytes": 7464,
      "sha256": "85fd89cd23fcb14649535892c5f4a9af219965153f442d817c0b7aea091bf91f"
    },
    "_framework/dotnet.js": {
      "bytes": 37898,
      "sha256": "ba72088a45591210f9a08fec223b0f848a0a4d3245026ae9479353596c7fa89d"
    },
    "_framework/dotnet.native.js": {
      "bytes": 554085,
      "sha256": "f1ae452278bab15245a0a4a4770b32c0ccc805de1457b1802454015446ade4a6"
    },
    "_framework/dotnet.native.js.symbols": {
      "bytes": 19444310,
      "sha256": "c915b00b408dcc6cd11d73d330c05f1eb90267eeb62b851ad7dbf406e5c76858"
    },
    "_framework/dotnet.runtime.js": {
      "bytes": 198480,
      "sha256": "41b9eaad9187b46abbc2e752d7bfc06043e91fd264a61aecc959650fa24799db"
    },
    "_framework/icudt_CJK.dat": {
      "bytes": 956416,
      "sha256": "4992ed42745cd09930a8769bd155153fb4f7b813d2798cf1cc39e9c4fa549c79"
    },
    "_framework/icudt_EFIGS.dat": {
      "bytes": 550832,
      "sha256": "f1f22d7ad618f24434c30ea8c704cb893de85e50701caba66de3f6a51178c937"
    },
    "_framework/icudt_no_CJK.dat": {
      "bytes": 1107168,
      "sha256": "2fbb15ecd1183f7eff42bd853c278fa39709a918135d1c061eec05e50fb435fb"
    },
    "_framework/twodog.wasm": {
      "bytes": 50965,
      "sha256": "264b48b25dfa42d41d8e3837cbbe666054d50c6f06ec9cf0731d85f24ec989e2"
    },
    "favicon-16x16.png": {
      "bytes": 860,
      "sha256": "df8fddef4c64e640d5e67e9d3d75bf333ee6c24c422a226d2628698502dfbded"
    },
    "favicon-32x32.png": {
      "bytes": 1485,
      "sha256": "1fc8e1db39d0d40495bcd84ec52283f32ad7b680b33ab7a15118ab53194ba10a"
    },
    "favicon-96x96.png": {
      "bytes": 4365,
      "sha256": "129b6e6db3b690889f3d9dc926b10c1500a819c364671920e3bb806f41f2c310"
    },
    "favicon.ico": {
      "bytes": 15086,
      "sha256": "2b12b3a195e0f7e1e7052df7e7e9b8369b7a7e0d8843017ebf1435013738491d"
    },
    "favicon.svg": {
      "bytes": 11764,
      "sha256": "1ef6a8841b987bfdf92fed81a7aa51c5e393b5e4269b6f761b905b8d6f902583"
    },
    "godot.audio.position.worklet.js": {
      "bytes": 2973,
      "sha256": "be33985bc7160d6bf9646f259cd86b259cd67b02ccb297ee5c44f8ac84327bc8"
    },
    "godot.audio.worklet.js": {
      "bytes": 7298,
      "sha256": "5b476a9c9ce642c0ee4256436d1bc31d9c38f868aca0f9a8e2a57c18d2dec2a3"
    },
    "godot.js": {
      "bytes": 36535,
      "sha256": "d98b44a1caf920bc5a257e647d7d430de5c972eb3f6c07f359678cc8e396cfd9"
    },
    "godot.pck": {
      "bytes": 24796,
      "sha256": "baeee0a7e1993dd1216ff378ceaf1dea5115fa8ec6944a887526055c1e18823e"
    },
    "godot.wasm": {
      "bytes": 47380389,
      "sha256": "bd39e97044f54775ed57d1615f31412fc863f2538ed8cc473d8d4e89266ff088"
    },
    "index.html": {
      "bytes": 20447,
      "sha256": "a9ce285101eff2a600c2275d9b133ea95e357cf8c974545993c74818fd3346ef"
    },
    "native-clock.js": {
      "bytes": 3017,
      "sha256": "f594d04160b516ffb1c87375ccce8ec4321f910b4807be3c1db244ca7e44e34f"
    },
    "package.json": {
      "bytes": 19,
      "sha256": "4db3f375c580dbd2fe977190c854014c577b08c59615b41d4bc53163840e625f"
    },
    "simulation/.stamp": {
      "bytes": 0,
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
    },
    "simulation/CuriousContraptions.Simulation.runtimeconfig.json": {
      "bytes": 2330,
      "sha256": "3fe643d2c36f9eaa4e43401fe39b11420b6fe2bb93b6245e116048e68c6d91cd"
    },
    "simulation/_framework/CuriousContraptions.Simulation.pdb": {
      "bytes": 45384,
      "sha256": "197354fc4075a23621e77f0c6519dcf363a3b0919c67139a3496c9d0afa0eec4"
    },
    "simulation/_framework/CuriousContraptions.Simulation.wasm": {
      "bytes": 159509,
      "sha256": "ac91b7882ec67682a658520ee63c3ec2cd6b9428f3cac40941af6854dfb099b1"
    },
    "simulation/_framework/Microsoft.CSharp.wasm": {
      "bytes": 301333,
      "sha256": "a6c328c66c6b697f94a8cb91eb2b8227673fc4b4f7c36d0e3b5273573349f2a4"
    },
    "simulation/_framework/Microsoft.VisualBasic.Core.wasm": {
      "bytes": 418581,
      "sha256": "bde0611b2a2baf374c1df8910edfd5a2f346d76e6b2cbacbede9d7e5fbef7e71"
    },
    "simulation/_framework/Microsoft.VisualBasic.wasm": {
      "bytes": 6933,
      "sha256": "f80640d89a62ed879dc8f83f67b380bd5e2370fa6e780538ca549e46f243b7cd"
    },
    "simulation/_framework/Microsoft.Win32.Primitives.wasm": {
      "bytes": 5397,
      "sha256": "5319538d5cc3db74f74cb1f0040a1090f35dda97030c123f695d39894e83c70a"
    },
    "simulation/_framework/Microsoft.Win32.Registry.wasm": {
      "bytes": 22805,
      "sha256": "63e8e3f9afb68131c789897229cf78c041f8d70837563add77d2923f472b57a8"
    },
    "simulation/_framework/System.AppContext.wasm": {
      "bytes": 4885,
      "sha256": "335584349580fb7c2bd8dbc784b5e1e38256584e155596a0f76f0689559b5c6d"
    },
    "simulation/_framework/System.Buffers.wasm": {
      "bytes": 4885,
      "sha256": "42d23b0f65e20fb3720910cd5bb4398cf63946b963aa42563a87c958b0692cea"
    },
    "simulation/_framework/System.Collections.Concurrent.wasm": {
      "bytes": 78613,
      "sha256": "eb455838af2255c5880a789e31ccedafde9f4b1997683c076209611d591f7162"
    },
    "simulation/_framework/System.Collections.Immutable.wasm": {
      "bytes": 240917,
      "sha256": "9567b761437f15ce6eaeebc658ffe6f2a6ae9c3e743884199488a00b39f27597"
    },
    "simulation/_framework/System.Collections.NonGeneric.wasm": {
      "bytes": 37653,
      "sha256": "3c7e2469ae3958b9ccc6245f313cca090f6ee36740c30772f7d929b492e89e70"
    },
    "simulation/_framework/System.Collections.Specialized.wasm": {
      "bytes": 37653,
      "sha256": "83d446f8afa268a9ab2babc077efcc460cfaf086c71e94a5472385218dbbb142"
    },
    "simulation/_framework/System.Collections.wasm": {
      "bytes": 102677,
      "sha256": "9d036c847837a0ac91417c39ccbc357c49b8078490295c9e1f617aeb00447b7a"
    },
    "simulation/_framework/System.ComponentModel.Annotations.wasm": {
      "bytes": 92437,
      "sha256": "5ae2399d744bcde801bdc0d7775da9f6ba0f6298bc8e87c278427abfcb3adfe1"
    },
    "simulation/_framework/System.ComponentModel.DataAnnotations.wasm": {
      "bytes": 6421,
      "sha256": "e34ae100807c8fec89d58be70e6436acf21558a3493ba5072effd4e284b19412"
    },
    "simulation/_framework/System.ComponentModel.EventBasedAsync.wasm": {
      "bytes": 16149,
      "sha256": "3b2d14444f335796b285be392135996c49e5eac18cf4b6ad91881b78051144a3"
    },
    "simulation/_framework/System.ComponentModel.Primitives.wasm": {
      "bytes": 32021,
      "sha256": "5bdff31adda227185e58725102923b1bb67472413945fb96533e0d9f0c606eae"
    },
    "simulation/_framework/System.ComponentModel.TypeConverter.wasm": {
      "bytes": 306453,
      "sha256": "41f1e922c33aa53e606042da541b4fa230eb97418dc1c938eaae0cbbddf7582a"
    },
    "simulation/_framework/System.ComponentModel.wasm": {
      "bytes": 5909,
      "sha256": "698853b31bb99790dd40c229ac3e1285bb708d3889047efc23ac0c4330519f2b"
    },
    "simulation/_framework/System.Configuration.wasm": {
      "bytes": 8981,
      "sha256": "976628f4a15a5e4817a5782e4d9767b930b2b4e62e3cb8c5f1c653d071d6c258"
    },
    "simulation/_framework/System.Console.wasm": {
      "bytes": 43797,
      "sha256": "5ca4d802f56a1a0b8ddc7b5e798c630f066a9457059887e92ce8cd563c1748d1"
    },
    "simulation/_framework/System.Core.wasm": {
      "bytes": 13077,
      "sha256": "d02d5ef2d67dfa999c53530f7dc7fc0fb34d726476a47f0b771b03318ad51c6d"
    },
    "simulation/_framework/System.Data.Common.wasm": {
      "bytes": 1007893,
      "sha256": "6cefcb3e9c616ba852a28488e8ffa56b3092c532976afe9df92486239c4aa05f"
    },
    "simulation/_framework/System.Data.DataSetExtensions.wasm": {
      "bytes": 5397,
      "sha256": "417acdf5930ca5665e15306eeb26656b0e65631d7eb54c448e17da3447471b8a"
    },
    "simulation/_framework/System.Data.wasm": {
      "bytes": 15125,
      "sha256": "21383a54de5f08fbb214a0bdba0ff4bea5d1a1a8278c66215a3d74cb985e8935"
    },
    "simulation/_framework/System.Diagnostics.Contracts.wasm": {
      "bytes": 5909,
      "sha256": "ebef2141873dd48fbf2aa73953acc2b8dc360a89d07af0f57e612f8526457e87"
    },
    "simulation/_framework/System.Diagnostics.Debug.wasm": {
      "bytes": 5397,
      "sha256": "9290d04e231c7db3bd9cfe4c8daea0ccbe174cea7ff62c44d420fbdfd59094ca"
    },
    "simulation/_framework/System.Diagnostics.DiagnosticSource.wasm": {
      "bytes": 192277,
      "sha256": "1e5c6d094fb6935600aa269b16abb98cea146ccc95d9912334d95412cff9ecd3"
    },
    "simulation/_framework/System.Diagnostics.FileVersionInfo.wasm": {
      "bytes": 12565,
      "sha256": "bd9b06848a9de804dcb6b63f2cfe22672d1c0dafa037e57393c980f5e725e1ab"
    },
    "simulation/_framework/System.Diagnostics.Process.wasm": {
      "bytes": 46357,
      "sha256": "404da827c0e32c6d3939d0be7cb9adf9884589410e4b0ca8c30436e68642bd3c"
    },
    "simulation/_framework/System.Diagnostics.StackTrace.wasm": {
      "bytes": 15637,
      "sha256": "f96b1ffe507b08323eece5177adb13c84fa5a384d873f4804b568cbf5ca788d3"
    },
    "simulation/_framework/System.Diagnostics.TextWriterTraceListener.wasm": {
      "bytes": 21269,
      "sha256": "7a63c8bf983cc45983afba0866164cfc34d61ab6f62e0820edcf9f8c0f7d8b97"
    },
    "simulation/_framework/System.Diagnostics.Tools.wasm": {
      "bytes": 4885,
      "sha256": "db22c857062b3e441693457187ea92f8ac4d125023f99e144e68c936ff2e60d9"
    },
    "simulation/_framework/System.Diagnostics.TraceSource.wasm": {
      "bytes": 48405,
      "sha256": "02262106d9a4c2938b5a8a0b53af8a989d324a0e9163f8a18e50838304004fc1"
    },
    "simulation/_framework/System.Diagnostics.Tracing.wasm": {
      "bytes": 5909,
      "sha256": "4bb1a249a73455cb01ec62ebba434ec8ec77524c8286f2cc582e65416d678f44"
    },
    "simulation/_framework/System.Drawing.Primitives.wasm": {
      "bytes": 54549,
      "sha256": "0a24afaeda8dc5be6629dc10ee86e19d346972f492d5edf548c1eadacea7ad47"
    },
    "simulation/_framework/System.Drawing.wasm": {
      "bytes": 10005,
      "sha256": "386f77a27952b5d8df5b370bab719277ba76a68b07ae9a01029b6e8e9ceefe4b"
    },
    "simulation/_framework/System.Dynamic.Runtime.wasm": {
      "bytes": 5909,
      "sha256": "c8be6a9594696fc8c730db1aa48cc0eea371b3d0d9bef009c77fe10a86c79e93"
    },
    "simulation/_framework/System.Formats.Asn1.wasm": {
      "bytes": 86805,
      "sha256": "118cb21b39e15840a6b1ce4515d1fa936e8f95922fb0e15831b47240794509ab"
    },
    "simulation/_framework/System.Formats.Tar.wasm": {
      "bytes": 28437,
      "sha256": "adc09c60e971855446d3b7819bfed4db184f2bf72299b315f69866b4b23e077a"
    },
    "simulation/_framework/System.Globalization.Calendars.wasm": {
      "bytes": 5397,
      "sha256": "81bf2774743979d920788baec090199a94af0d2aa69923d825b0604f37a5fe9b"
    },
    "simulation/_framework/System.Globalization.Extensions.wasm": {
      "bytes": 4885,
      "sha256": "bd992468aaf42266448269c73f3a3f9ac30c7842500aac52a369936df3b3473c"
    },
    "simulation/_framework/System.Globalization.wasm": {
      "bytes": 5397,
      "sha256": "c6212db83ae71026ec766a403c0a765739ad2f5bf821f17213147de85b9df3d6"
    },
    "simulation/_framework/System.IO.Compression.Brotli.wasm": {
      "bytes": 18197,
      "sha256": "eb8dd064bec82dda4306736cbf6dd98b40b2cf3e52a138c8f701a0b87aaeb263"
    },
    "simulation/_framework/System.IO.Compression.FileSystem.wasm": {
      "bytes": 4885,
      "sha256": "68ec2837721b8ac6b6815871cc1a64b42d8be1210382f4698490a12d269303e4"
    },
    "simulation/_framework/System.IO.Compression.ZipFile.wasm": {
      "bytes": 43285,
      "sha256": "93b5cf7cdb21adf3152206a2baf29ddfbec6b48ed46189e30ea259c94923fa37"
    },
    "simulation/_framework/System.IO.Compression.wasm": {
      "bytes": 157461,
      "sha256": "1e9b2ad33669c4292c99e6e11a58022e905f665c3a7d1267fe967f408bc5f184"
    },
    "simulation/_framework/System.IO.FileSystem.AccessControl.wasm": {
      "bytes": 21781,
      "sha256": "1a3c16aa5954f687631965690239aea46c7cff28b2e65b0dd8da2dd5ad6ca068"
    },
    "simulation/_framework/System.IO.FileSystem.DriveInfo.wasm": {
      "bytes": 13589,
      "sha256": "fe88e7da5d82356bac2366ad56b45df1d6e2ee4e01011ccb4c98d11fa620a2d3"
    },
    "simulation/_framework/System.IO.FileSystem.Primitives.wasm": {
      "bytes": 4885,
      "sha256": "1fc5b4ba1a395b15a81fc86025912635b74fa4f614803f319161d148ac7b30c7"
    },
    "simulation/_framework/System.IO.FileSystem.Watcher.wasm": {
      "bytes": 22805,
      "sha256": "b9c62e9e084717bbcb7d59901a6098e9a26c0762b1f5829c68b6225ad5d33656"
    },
    "simulation/_framework/System.IO.FileSystem.wasm": {
      "bytes": 5397,
      "sha256": "600df243b94be47d160580e812553965e54ac4f81f96d0beb70795d986db9ff0"
    },
    "simulation/_framework/System.IO.IsolatedStorage.wasm": {
      "bytes": 24853,
      "sha256": "a71a0c465e6a599aa025242727c98e1c47313b26585a633632be68614cbe1a5a"
    },
    "simulation/_framework/System.IO.MemoryMappedFiles.wasm": {
      "bytes": 39701,
      "sha256": "5992ec46e8df0ffa9af391d0abe8c7fe636fa9a482f047dca2b84ded5f84f88f"
    },
    "simulation/_framework/System.IO.Pipelines.wasm": {
      "bytes": 67861,
      "sha256": "4c3cf9a869576f8656f32036eea51931873c8f530c72bf68721d9aecf49c5e0e"
    },
    "simulation/_framework/System.IO.Pipes.AccessControl.wasm": {
      "bytes": 13077,
      "sha256": "2acc8500d58801f740aeb8c19c99d7dcb5a92403335c0262dbdb66dca6f99a0c"
    },
    "simulation/_framework/System.IO.Pipes.wasm": {
      "bytes": 32021,
      "sha256": "395413d4c1bc25bc805ee653ac65e5ad1faed122f64bfd0f4fa69c70b910bb9e"
    },
    "simulation/_framework/System.IO.UnmanagedMemoryStream.wasm": {
      "bytes": 5397,
      "sha256": "c876d84de9cbf065cebaaaa6c6477044459e3947b32cf8b67824b39fdefd0be9"
    },
    "simulation/_framework/System.IO.wasm": {
      "bytes": 5397,
      "sha256": "f0a003ef545c6f579d1bfc7e0b1e30500f3fd1c98650649c88f99aea37972d7a"
    },
    "simulation/_framework/System.Linq.AsyncEnumerable.wasm": {
      "bytes": 446229,
      "sha256": "99281ecdb05aad5e5204463eb7b2ce6cfe674375e011517a479a8085063dd2ca"
    },
    "simulation/_framework/System.Linq.Expressions.wasm": {
      "bytes": 565013,
      "sha256": "c9483f3d0f217a7002844ef0d05b9fd86544a70798d9d7fd7f6d0284283618c1"
    },
    "simulation/_framework/System.Linq.Parallel.wasm": {
      "bytes": 212757,
      "sha256": "12082de1f511a750dcdd47af84a6e9e0b8fd7e376395cf3f8c6a8cda27ddcc8b"
    },
    "simulation/_framework/System.Linq.Queryable.wasm": {
      "bytes": 68373,
      "sha256": "f8eb9b1961beff37c7f85b34957ba7b86a6af30cee73861721f254d9f1ddcc30"
    },
    "simulation/_framework/System.Linq.wasm": {
      "bytes": 190741,
      "sha256": "e113aac1e82e0f48459f75d9d970be24ace772cc59341897db278a3ee42cf5b3"
    },
    "simulation/_framework/System.Memory.wasm": {
      "bytes": 45333,
      "sha256": "715f016263fea4c3c2e620d18b7c76d5fb2073675439bcfebc5b3bbac658da3b"
    },
    "simulation/_framework/System.Net.Http.Json.wasm": {
      "bytes": 45845,
      "sha256": "4859a26f782549d7d14d0640b4183400582b352f49ddd520a6c0e6b7d5fdbc91"
    },
    "simulation/_framework/System.Net.Http.wasm": {
      "bytes": 286485,
      "sha256": "e442ab94cf5269b002973a749f9eea4c513679a2c1fa33f4ff3d67473fe2c109"
    },
    "simulation/_framework/System.Net.HttpListener.wasm": {
      "bytes": 45845,
      "sha256": "30e7a26dc1e5d2cc79484a8d407421459391e7df0009051c3675ff15579cb5ea"
    },
    "simulation/_framework/System.Net.Mail.wasm": {
      "bytes": 94997,
      "sha256": "ccd7aab6d882b042caac6ae9cbf4f93502b10f4f63a1c9fc85726fdc171f2a8e"
    },
    "simulation/_framework/System.Net.NameResolution.wasm": {
      "bytes": 14101,
      "sha256": "ba5ff9a6b65b0b4bc6ac8b7a504484fb8969268ff05d881672efb5fa00207399"
    },
    "simulation/_framework/System.Net.NetworkInformation.wasm": {
      "bytes": 32021,
      "sha256": "f96aa81ebcfbb2d81571019bb698bb8d0a9e978ac9da1c76485d072689301daf"
    },
    "simulation/_framework/System.Net.Ping.wasm": {
      "bytes": 17685,
      "sha256": "e67bc7f23d15226ff59cc375fa5553239e118bc0f99ed9b7d00d9f841d2173f4"
    },
    "simulation/_framework/System.Net.Primitives.wasm": {
      "bytes": 97045,
      "sha256": "ce137fa22ca29106f08ee9c335b62de176d49f7c3f0e047b8ce03ccc3d698510"
    },
    "simulation/_framework/System.Net.Quic.wasm": {
      "bytes": 28949,
      "sha256": "35085c6327f41ebe2d7e285ca6d2e3ea48c32a36c3de7214e9fed551f3fe8d79"
    },
    "simulation/_framework/System.Net.Requests.wasm": {
      "bytes": 55573,
      "sha256": "51d24e5a6bb5c66f7474d8aff968992cda039cd6940c2f1207224f64063f7d23"
    },
    "simulation/_framework/System.Net.Security.wasm": {
      "bytes": 104213,
      "sha256": "60cbd65fb632329e81b182ae3700d559e7aad2aafa4bcd87a05b99274f04dc36"
    },
    "simulation/_framework/System.Net.ServerSentEvents.wasm": {
      "bytes": 30485,
      "sha256": "a869803f6d8851342eab13901c7a0cbf6fd42eb466343abff3fc2628a85aba2d"
    },
    "simulation/_framework/System.Net.ServicePoint.wasm": {
      "bytes": 4885,
      "sha256": "fd24d207fa66a0477b7813f57b04e101831e246bde4c33ab29fb68574e93ca22"
    },
    "simulation/_framework/System.Net.Sockets.wasm": {
      "bytes": 64277,
      "sha256": "bd9132d8b808bcf270334a7a5e26493284f97ef06557aca1ac87f4662514d8e9"
    },
    "simulation/_framework/System.Net.WebClient.wasm": {
      "bytes": 45845,
      "sha256": "480b94316291ccadb04ad559e3a246c6864d5043dd1fd42250ad8fb1de0b61c7"
    },
    "simulation/_framework/System.Net.WebHeaderCollection.wasm": {
      "bytes": 22805,
      "sha256": "6b2f07597dd5e76b377e8ff3afc237a7be9939d02e63479caded54d930b03952"
    },
    "simulation/_framework/System.Net.WebProxy.wasm": {
      "bytes": 11541,
      "sha256": "90a3b74c7f07b015df0bdd92cbddfca085751dd28c4b4b95a73b486940c3794e"
    },
    "simulation/_framework/System.Net.WebSockets.Client.wasm": {
      "bytes": 42261,
      "sha256": "336c6f26f881037c132e2e11254fa96b2a1754f884af23e0c32c9d88b274e160"
    },
    "simulation/_framework/System.Net.WebSockets.wasm": {
      "bytes": 99093,
      "sha256": "fea523cea345ef89f9162110a4ec30db01a600e4f9ec7a2125615ce8dfc2b497"
    },
    "simulation/_framework/System.Net.wasm": {
      "bytes": 6933,
      "sha256": "6c4e4986e96f5ecf9516d8085b520c2a110b1dce605037b410fccd883b686691"
    },
    "simulation/_framework/System.Numerics.Vectors.wasm": {
      "bytes": 5397,
      "sha256": "70af1c5496d124bc8a9f24b3af13373bf6095e0f099516ab58c2406311b641c5"
    },
    "simulation/_framework/System.Numerics.wasm": {
      "bytes": 4885,
      "sha256": "839a7aa2a7d09763948ff3abdc92624c29e43048afe5897aaf70248b4f1776f7"
    },
    "simulation/_framework/System.ObjectModel.wasm": {
      "bytes": 30997,
      "sha256": "68fd5c1dd9c2bd83f576bac8087b7fa0c614a923905555655b97f103384d62e1"
    },
    "simulation/_framework/System.Private.CoreLib.wasm": {
      "bytes": 4869913,
      "sha256": "8330e781a284d5fceb7a7ae716f8beecc1e21c9114427d1bad00f583743e8452"
    },
    "simulation/_framework/System.Private.DataContractSerialization.wasm": {
      "bytes": 849173,
      "sha256": "ea39ab91f85bb46900b3c174a403333f4ca6b9b606348ee7edad49db1638cbdf"
    },
    "simulation/_framework/System.Private.Uri.wasm": {
      "bytes": 95509,
      "sha256": "6ad801d6063ad0aebf9eda505cd37c8ec1a99f0d7ce58f3306ae9634db792ca8"
    },
    "simulation/_framework/System.Private.Xml.Linq.wasm": {
      "bytes": 143637,
      "sha256": "6de35cba66f9568350616891f5bc460ae50f4c3d793520fa12a011761f4753f6"
    },
    "simulation/_framework/System.Private.Xml.wasm": {
      "bytes": 3096345,
      "sha256": "8bd2a152b229195ca132980be0657f25ccd8a7835d0dffa8d7c3e294f966e3c1"
    },
    "simulation/_framework/System.Reflection.DispatchProxy.wasm": {
      "bytes": 27925,
      "sha256": "5bdfb4501c6dcf412f67dc609269e0fad1ce857596d8604a7637190156dce981"
    },
    "simulation/_framework/System.Reflection.Emit.ILGeneration.wasm": {
      "bytes": 5397,
      "sha256": "c9f3a8a03c8fb68d0b9e0d7b0b0809e79357aa15b3fadf527e188625e4fbf476"
    },
    "simulation/_framework/System.Reflection.Emit.Lightweight.wasm": {
      "bytes": 5397,
      "sha256": "33047d8ffb2e3ee7b35d219d6cd3d4db75477b918805fe91f41b35a7d06d3f79"
    },
    "simulation/_framework/System.Reflection.Emit.wasm": {
      "bytes": 123157,
      "sha256": "2592bf86e67d76859820fbf4cb37afd7062e8545c0210af1a36342caeec0d4e0"
    },
    "simulation/_framework/System.Reflection.Extensions.wasm": {
      "bytes": 4885,
      "sha256": "ff12a4a40b2ac0d43cb284dd6bdeda51e77a6a5d43f5d193753036951beb2f13"
    },
    "simulation/_framework/System.Reflection.Metadata.wasm": {
      "bytes": 493333,
      "sha256": "b5ced24f35318b43be4bc8afba445778fed254a543c2ca9260fb6bf1bd2786a4"
    },
    "simulation/_framework/System.Reflection.Primitives.wasm": {
      "bytes": 5397,
      "sha256": "9e263280c94ad479db12e81b3624de05cec49102175cf9e766481952aab7a8bb"
    },
    "simulation/_framework/System.Reflection.TypeExtensions.wasm": {
      "bytes": 14101,
      "sha256": "a6df1129b3bdde0bc786cd837ca7f872d60da671fa11cda3ea5f8cd1281d012e"
    },
    "simulation/_framework/System.Reflection.wasm": {
      "bytes": 5909,
      "sha256": "d64e965155b5989c14292280c2f2a3e70b46fd64d87f7b1c0a6172738b91b56b"
    },
    "simulation/_framework/System.Resources.Reader.wasm": {
      "bytes": 4885,
      "sha256": "f83137c833ed445e4933c4f9db2710b75a92009d2f6e35f99eee19a23f92b99e"
    },
    "simulation/_framework/System.Resources.ResourceManager.wasm": {
      "bytes": 5397,
      "sha256": "088338814326a2dffe46588e261a5ff7866522c02be188847d6bce0176e8bcc5"
    },
    "simulation/_framework/System.Resources.Writer.wasm": {
      "bytes": 16661,
      "sha256": "2b1db7b0a1b2cff90480955dd594510d423ddc0f79085a64608cc27a3902c6d4"
    },
    "simulation/_framework/System.Runtime.CompilerServices.Unsafe.wasm": {
      "bytes": 4885,
      "sha256": "3fab48ce8cdd089a878b2d331a3b8fb4b55f3986f9c9bd103f014cc0c527e006"
    },
    "simulation/_framework/System.Runtime.CompilerServices.VisualC.wasm": {
      "bytes": 6933,
      "sha256": "ff81f00f3690e5aed2d95f90cebf78373df38bdd7f699df4b5186d6b45caa981"
    },
    "simulation/_framework/System.Runtime.Extensions.wasm": {
      "bytes": 7445,
      "sha256": "3279379f578ae1ea93119926fd97d3ecb42619dc060281766a72eaad96c33db3"
    },
    "simulation/_framework/System.Runtime.Handles.wasm": {
      "bytes": 5397,
      "sha256": "408553e1c929cf5ec950012cbda68a6181f7e4ebbc57d12b20abb0348d390995"
    },
    "simulation/_framework/System.Runtime.InteropServices.JavaScript.wasm": {
      "bytes": 79637,
      "sha256": "b90b0e875184ab6657d2c5c1c579f2a18ccd31fe3279751e2ca5206f5ab47caa"
    },
    "simulation/_framework/System.Runtime.InteropServices.RuntimeInformation.wasm": {
      "bytes": 5397,
      "sha256": "ce10b90825bd9c292a19774e7c87f06b08c51e2e498e540d9c3f291a475f5a81"
    },
    "simulation/_framework/System.Runtime.InteropServices.wasm": {
      "bytes": 54549,
      "sha256": "5738352a54988c730a07c296f7b38a699b117a2f10e7ddcaa0f82741ed67e54a"
    },
    "simulation/_framework/System.Runtime.Intrinsics.wasm": {
      "bytes": 6933,
      "sha256": "5e8eb1339e85413677d3fe95820a777d847ee05c55fca98ca28341369b7ec3a2"
    },
    "simulation/_framework/System.Runtime.Loader.wasm": {
      "bytes": 5397,
      "sha256": "5fe44c9c07d3542e3e4c3050a12fe1ecb8723c1c098e8ae9a042c505f57bdb8f"
    },
    "simulation/_framework/System.Runtime.Numerics.wasm": {
      "bytes": 134933,
      "sha256": "a836033e5b612ab963d9d9da06c36830ae57fe7c4a85321d52243dba0553b96d"
    },
    "simulation/_framework/System.Runtime.Serialization.Formatters.wasm": {
      "bytes": 55573,
      "sha256": "87f7401689e4f5e8a0a1b79e5192d239d6cf7f41b3d8e9f87d809b5b8846c269"
    },
    "simulation/_framework/System.Runtime.Serialization.Json.wasm": {
      "bytes": 5397,
      "sha256": "3026c802c1d006e828f2aa49a79d59d141cfbe2248d35dd7f1caa85175df6bb3"
    },
    "simulation/_framework/System.Runtime.Serialization.Primitives.wasm": {
      "bytes": 13077,
      "sha256": "0f312b7f0eebdcb283285afcf4f071805f92c7130425c6fa9469e999dbe7dc0f"
    },
    "simulation/_framework/System.Runtime.Serialization.Xml.wasm": {
      "bytes": 6421,
      "sha256": "3f8096a61d2112672c7e2c0a624469e267bfe68f29b89a96c417e3d0070b7d69"
    },
    "simulation/_framework/System.Runtime.Serialization.wasm": {
      "bytes": 6933,
      "sha256": "a6be1a661eaaf3e2e20d18ed56d26490b78266e560445f623a1aeeddc5d37d46"
    },
    "simulation/_framework/System.Runtime.wasm": {
      "bytes": 34581,
      "sha256": "749c711b5fb16756eb2a39c565c12c3baf6668a815ce19f0f78539814a2be86b"
    },
    "simulation/_framework/System.Security.AccessControl.wasm": {
      "bytes": 47893,
      "sha256": "802b2846b562914973371b2b35b67ee905464f6f9750f2895b1f7984128497fc"
    },
    "simulation/_framework/System.Security.Claims.wasm": {
      "bytes": 44821,
      "sha256": "18f7126c7c1654b1f57dc6b4b2d23632a644fb1b152eb03f92c92e890c9c2784"
    },
    "simulation/_framework/System.Security.Cryptography.Algorithms.wasm": {
      "bytes": 6933,
      "sha256": "2c3cd88869d1d1baf161c14da34a1c068e7d7586596fd3017b78a5776ce72527"
    },
    "simulation/_framework/System.Security.Cryptography.Cng.wasm": {
      "bytes": 5909,
      "sha256": "669cab343b42fb7b62ea6dddea6847d5ab3f9be645a8bb5cd9b64114db6e547f"
    },
    "simulation/_framework/System.Security.Cryptography.Csp.wasm": {
      "bytes": 5909,
      "sha256": "329ed67a65f08a43056f211939b95003c97cc2a019e6386687a41ba138a2df6a"
    },
    "simulation/_framework/System.Security.Cryptography.Encoding.wasm": {
      "bytes": 5397,
      "sha256": "76e22955c04dee0df59430fbef262e006df1337539199b5e3c7ce7522573d26e"
    },
    "simulation/_framework/System.Security.Cryptography.OpenSsl.wasm": {
      "bytes": 5397,
      "sha256": "e07e8460839c40a5fbb294d1f86ef88e64d5260ebe32002d63d83c6f6d8a7058"
    },
    "simulation/_framework/System.Security.Cryptography.Primitives.wasm": {
      "bytes": 5397,
      "sha256": "0d7e70d82e3a52b658d2e6d36849f79719a57d89c91471354cdf30238aac3207"
    },
    "simulation/_framework/System.Security.Cryptography.X509Certificates.wasm": {
      "bytes": 6421,
      "sha256": "c274418a55e3bb61a1599b12701a7aa4167c74d483f3516e5be0d75d9c54bb52"
    },
    "simulation/_framework/System.Security.Cryptography.wasm": {
      "bytes": 643861,
      "sha256": "2d9912b6ae35317e7d4e9b69879fc91904521bc079f9ad6576b6f442935507a2"
    },
    "simulation/_framework/System.Security.Principal.Windows.wasm": {
      "bytes": 27413,
      "sha256": "4cd39f6305468aff9dfd793a2d782b3b28839311b3bfd3721f6206cae548311e"
    },
    "simulation/_framework/System.Security.Principal.wasm": {
      "bytes": 4885,
      "sha256": "5a8c389fb11b6177351df42a1d0bb526197b7fcbc2adc54d9050172d9bf2bd38"
    },
    "simulation/_framework/System.Security.SecureString.wasm": {
      "bytes": 5397,
      "sha256": "77b8156e9b2ddcd9caf3c644729689a07e70df37e6b115c3250befa9b2fe4556"
    },
    "simulation/_framework/System.Security.wasm": {
      "bytes": 7957,
      "sha256": "1ee5fb2c13b8e9456241bdaeff4befb3e5cbc6055013e29594eb3a507f86c348"
    },
    "simulation/_framework/System.ServiceModel.Web.wasm": {
      "bytes": 6421,
      "sha256": "478b70e645d5519f90b2aebfe1792aed079dbf9a73a2e4dd5d569ca1e1b457fd"
    },
    "simulation/_framework/System.ServiceProcess.wasm": {
      "bytes": 5397,
      "sha256": "52c9b3dcce68e5648cd52736754de78ea5d4d4c79232f81cf286b14caf20046a"
    },
    "simulation/_framework/System.Text.Encoding.CodePages.wasm": {
      "bytes": 732437,
      "sha256": "822cb8f0f6ab978d4ec78ea97dc7072d35e5ca936fddd5cabbec912a259c242d"
    },
    "simulation/_framework/System.Text.Encoding.Extensions.wasm": {
      "bytes": 5397,
      "sha256": "90bd8213e57be38f7cbdf6f592e60db2d8b6ca52435622b97849d398a26ffb9e"
    },
    "simulation/_framework/System.Text.Encoding.wasm": {
      "bytes": 5397,
      "sha256": "00ce9cd2dc7e94bac367a399377a0b85eea70b6d4b67a8f5b04287602d205fd4"
    },
    "simulation/_framework/System.Text.Encodings.Web.wasm": {
      "bytes": 55573,
      "sha256": "1f456421e334ae5257fd57aaff33e11321fba62b2457724e2a78333ff763244f"
    },
    "simulation/_framework/System.Text.Json.wasm": {
      "bytes": 638741,
      "sha256": "aac74269b8accdfdea1ccb2f62246ec5aef558d0a335e929a81447b3ce3af6f4"
    },
    "simulation/_framework/System.Text.RegularExpressions.wasm": {
      "bytes": 374549,
      "sha256": "ee6b3162d52e55f6639983bbe70ad918eeab6a91157634fb44282de98f44c867"
    },
    "simulation/_framework/System.Threading.AccessControl.wasm": {
      "bytes": 23317,
      "sha256": "cf485ab4de5fc0c2601ddcf8407306f3e7bd9c331c2fe8d6be8118ff8fb9d0af"
    },
    "simulation/_framework/System.Threading.Channels.wasm": {
      "bytes": 56085,
      "sha256": "645559120649e1f02fac06bce19a23e63d4e2d7fbb5611798ead1726819d3d7d"
    },
    "simulation/_framework/System.Threading.Overlapped.wasm": {
      "bytes": 5397,
      "sha256": "82810b176c3352eb1b308d650130c5e26c8775ee464fc1375f8aa6b4714d39e8"
    },
    "simulation/_framework/System.Threading.Tasks.Dataflow.wasm": {
      "bytes": 175381,
      "sha256": "764ce778af10b71410e9f9460a29a2fe87c3bd5f95a301f52dcc5745e0fddf91"
    },
    "simulation/_framework/System.Threading.Tasks.Extensions.wasm": {
      "bytes": 5397,
      "sha256": "34460361a601a601774a8e79dd581a986ab729950bdf6503be9b3663f74b762b"
    },
    "simulation/_framework/System.Threading.Tasks.Parallel.wasm": {
      "bytes": 50965,
      "sha256": "f7bc459332e2e3f0b4a2d5aa066a637311ab300141461bb86f6f47a4c5da4d9c"
    },
    "simulation/_framework/System.Threading.Tasks.wasm": {
      "bytes": 6421,
      "sha256": "f9339e480b0a2064f55090668c7457eb5811906210fb4bc4b4142bf24fbb1e52"
    },
    "simulation/_framework/System.Threading.Thread.wasm": {
      "bytes": 5397,
      "sha256": "285386b2d5571003101f085f5932198f70391f088f97e2a58197ad4ce7ded1c6"
    },
    "simulation/_framework/System.Threading.ThreadPool.wasm": {
      "bytes": 5397,
      "sha256": "6adc6cde9d78263e809e724cf8011d6d54772defe8493f42b41f1bcf499c3395"
    },
    "simulation/_framework/System.Threading.Timer.wasm": {
      "bytes": 4885,
      "sha256": "dab6cb4a40d487f09d28c517375db12b9f743f93ddb50ebe0ff1d4175636ccd6"
    },
    "simulation/_framework/System.Threading.wasm": {
      "bytes": 34581,
      "sha256": "ba57229933c4418a3ebf3bf38dc8fdefe55d1784d897569c1b1bf6178d3ae2c7"
    },
    "simulation/_framework/System.Transactions.Local.wasm": {
      "bytes": 165653,
      "sha256": "9539134a57d3aa3ee3258716bab7f57c76e850a0b008b287372269810150cb51"
    },
    "simulation/_framework/System.Transactions.wasm": {
      "bytes": 6421,
      "sha256": "ea413b9a2bd0a317e1313540926622e5596c421a972d8708980b9cf43ed2923a"
    },
    "simulation/_framework/System.ValueTuple.wasm": {
      "bytes": 5397,
      "sha256": "c9cb6f3e645bb681e23e9339a4a9da8c006b8d1411f5addbf873d61f281ada46"
    },
    "simulation/_framework/System.Web.HttpUtility.wasm": {
      "bytes": 19733,
      "sha256": "36173c2f6dc9d7e00f07b8eef7b299943727a046ba5ef0baa782e5ba80235646"
    },
    "simulation/_framework/System.Web.wasm": {
      "bytes": 4885,
      "sha256": "9b9681cfefb3cc5f2d37394de3e479a4fa86852f3cd8fc70e0ac286a469d56b2"
    },
    "simulation/_framework/System.Windows.wasm": {
      "bytes": 5397,
      "sha256": "afad9baef44a306bdd7088374886d65a2ee4f3f36a09fa67f8b3ea9f08adbca1"
    },
    "simulation/_framework/System.Xml.Linq.wasm": {
      "bytes": 5397,
      "sha256": "ad0d2f4b2d19d7a1a7545992ff00acd36fa9aed2de9b51d2adb1dd7d623334ae"
    },
    "simulation/_framework/System.Xml.ReaderWriter.wasm": {
      "bytes": 11541,
      "sha256": "6e69334420e7c0c8059f266f40a9e3261e6b75f649b59e278ab8da26e7c8aea9"
    },
    "simulation/_framework/System.Xml.Serialization.wasm": {
      "bytes": 5909,
      "sha256": "1cf432a3b727b2b02e97d15f1cfd092d5617a2773f0d8c0cf3bb7a2170388cf7"
    },
    "simulation/_framework/System.Xml.XDocument.wasm": {
      "bytes": 5397,
      "sha256": "60bc088cc2bc175c6afc5220cc6ebe8e2252b646cbfb9b0b40b7730f6b20a5af"
    },
    "simulation/_framework/System.Xml.XPath.XDocument.wasm": {
      "bytes": 5909,
      "sha256": "ad46f5b02d843ea6272f2b3d57f0b41ffdf5dda2c1c85aea9b4a93eb326951c1"
    },
    "simulation/_framework/System.Xml.XPath.wasm": {
      "bytes": 5397,
      "sha256": "fb956a5f0f079808c3bf28b6fb2ecaf7978c6ab5bb5d8e303d6d1b87bc7c2ff2"
    },
    "simulation/_framework/System.Xml.XmlDocument.wasm": {
      "bytes": 5397,
      "sha256": "b8fc1d6be1f6844b23d096edd9b5c69d255b8e475b46c154dd38e27f030b422e"
    },
    "simulation/_framework/System.Xml.XmlSerializer.wasm": {
      "bytes": 7445,
      "sha256": "22b9c6f7594dd6d7cab1a6d3a14629bac724851afdc176f72719ba0aab0e4c91"
    },
    "simulation/_framework/System.Xml.wasm": {
      "bytes": 13077,
      "sha256": "28fcaa1c997e64ca3773a3c2976bcf690181743f0fe0a501c6c524bd1f74fe19"
    },
    "simulation/_framework/System.wasm": {
      "bytes": 39701,
      "sha256": "ec31ac9648bd01f1313e9bd34cfe4ba2ef9479530fb710bb4cca13c2fa39b0a6"
    },
    "simulation/_framework/WindowsBase.wasm": {
      "bytes": 5909,
      "sha256": "b48f78f933a316a47767cf3495ffb661ef51eeea3a3b15f7b7bdd2642dd6a1d7"
    },
    "simulation/_framework/dotnet.boot.js": {
      "bytes": 37019,
      "sha256": "63299edd728a0e43f2f90314fabdc039e30d7694eb1ae0b8f1ce8a3f8b54be68"
    },
    "simulation/_framework/dotnet.js": {
      "bytes": 37898,
      "sha256": "ba72088a45591210f9a08fec223b0f848a0a4d3245026ae9479353596c7fa89d"
    },
    "simulation/_framework/dotnet.js.map": {
      "bytes": 51818,
      "sha256": "284c68abc54f86607c605f4032b060265e438dcd067140834596a6af65df5c36"
    },
    "simulation/_framework/dotnet.native.js": {
      "bytes": 145050,
      "sha256": "8d975da1b2c13360b795085843ad7149027f5aa0f779008edd1ce81c668e8f1d"
    },
    "simulation/_framework/dotnet.native.js.symbols": {
      "bytes": 484406,
      "sha256": "0048867ac07f0c4f191725dafa83f07ac27512734d19807406f4fe38854d9893"
    },
    "simulation/_framework/dotnet.native.wasm": {
      "bytes": 3001422,
      "sha256": "253c57775ef06eb1ca57fdfbe66a0715415cddafe87d54cf3ea49393a2b0363d"
    },
    "simulation/_framework/dotnet.runtime.js": {
      "bytes": 198480,
      "sha256": "41b9eaad9187b46abbc2e752d7bfc06043e91fd264a61aecc959650fa24799db"
    },
    "simulation/_framework/dotnet.runtime.js.map": {
      "bytes": 276757,
      "sha256": "b321bd217887402b736a70395cbdb67eb01825aa78db7f8c637ef10e907ad3a7"
    },
    "simulation/_framework/icudt_CJK.dat": {
      "bytes": 956416,
      "sha256": "4992ed42745cd09930a8769bd155153fb4f7b813d2798cf1cc39e9c4fa549c79"
    },
    "simulation/_framework/icudt_EFIGS.dat": {
      "bytes": 550832,
      "sha256": "f1f22d7ad618f24434c30ea8c704cb893de85e50701caba66de3f6a51178c937"
    },
    "simulation/_framework/icudt_no_CJK.dat": {
      "bytes": 1107168,
      "sha256": "2fbb15ecd1183f7eff42bd853c278fa39709a918135d1c061eec05e50fb435fb"
    },
    "simulation/_framework/mscorlib.wasm": {
      "bytes": 49429,
      "sha256": "dc7d86e67813ede21a62c4c3b3e0a81a076f7d3721c6dcb5ef96ffe07f7eab12"
    },
    "simulation/_framework/netstandard.wasm": {
      "bytes": 90389,
      "sha256": "76dca1da6d9ce009380120a8b55b299fe1263a2b97908e73a92daaf74a876feb"
    },
    "simulation/basketball.wgsl": {
      "bytes": 8308,
      "sha256": "7748a629ea18a1efad4147f47c10fbad7f2563170658d951ab60565fc84277af"
    },
    "simulation/package.json": {
      "bytes": 19,
      "sha256": "4db3f375c580dbd2fe977190c854014c577b08c59615b41d4bc53163840e625f"
    },
    "simulation/worker.js": {
      "bytes": 10771,
      "sha256": "26c873c40302815ba449b4a7f121355efbf01eba34ea0a3eab967cdcd5b01c88"
    },
    "twodog.sizes.json": {
      "bytes": 45,
      "sha256": "21980630bca22d37ce6b476515796856c02288eeb0c2cde306d858b3782c40ad"
    },
    "workshop-client.js": {
      "bytes": 18948,
      "sha256": "5ec2da16f63ea3d5ea1ba276de27ade4894c18618e915f6dbfe83c305fda301f"
    },
    "workshop-isolation-worker.js": {
      "bytes": 1686,
      "sha256": "491a7e1769e461ee5fe42f2bec445efea6f400d93b45ae13490efe591ae1f7c7"
    },
    "workshop-isolation.js": {
      "bytes": 8225,
      "sha256": "463bd16eccba3330448ea07ba0e21e1c99039f66d710f8a0f2f830df5040c019"
    }
  };
  const mandatory = ["index.html","godot.js","godot.wasm","godot.pck","workshop-isolation.js","workshop-client.js","native-clock.js","_framework/dotnet.js","_framework/dotnet.boot.js","_framework/dotnet.runtime.js","_framework/dotnet.native.js","_framework/CuriousContraptions.wasm","_framework/CuriousContraptions.web.wasm","_framework/CuriousContraptions.Animation.wasm","_framework/GodotSharp.wasm","_framework/twodog.wasm","_framework/System.Private.CoreLib.wasm","simulation/worker.js","simulation/basketball.wgsl","simulation/_framework/dotnet.js","simulation/_framework/dotnet.boot.js","simulation/_framework/dotnet.runtime.js","simulation/_framework/dotnet.native.js","simulation/_framework/dotnet.native.wasm","simulation/_framework/CuriousContraptions.Simulation.wasm","simulation/_framework/System.Private.CoreLib.wasm"];
  const origin = 'http://127.0.0.1:8060';
  const limit = { wallMs: 30000, cleanupMs: 2000, resource: 67108864,
    cache: 134217728, distinct: 240, requests: 512, decodedTotal: 134217728, decodedUnique: 100663296,
    logEntries: 512, logChars: 4096, payloadChars: 89478488 };
  const result = { verdict: 'Incomplete', limits: limit, start: Date.now(),
    records: [], generatedFavicons: [], logs: [], missing: [], errors: [], cleanup: null,
    limitations: ['A pending Playwright worker body read cannot be cancelled by this helper.',
      'Deadline or cleanup uncertainty forbids measurement; no timeout implies cancellation.',
      'The512MiB transient reservation and128MiB CDP cache are setup accounting, not residency proof.',
      'Controller/policy applicability is separate; this does not identify installed service-worker source.'] };
  let session, active = true, expired = false, reading = false, received = 0;
  let requestCount = 0, totalDecoded = 0, uniqueDecoded = 0, lastRelevant = Date.now(), navigationLoader = null;
  let queue = [], main = new Map(), responseByRequest = new Map(), workerPending = new Map();
  const hashes = new Map();
  const generatedUrls = new Set(), publicGeneratedUrls = new Set();
  const wait = ms => page.waitForTimeout(ms);
  const fail = message => {
    if (active) result.errors.push(String(message).slice(0, 4096));
    active = false;
  };
  const within = promise => Promise.race([promise, deadline]);
  let rejectDeadline, resolveDeadline, deadlineArmed = true;
  const deadline = new Promise((resolve, reject) => { resolveDeadline = resolve; rejectDeadline = reject; });
  const wallWait = page.waitForTimeout(limit.wallMs).then(() => {
    if (!deadlineArmed) return;
    expired = true; fail('Identity collection exceeded30s deadline.');
    rejectDeadline(new Error('Identity collection deadline.'));
  }).catch(error => { if (deadlineArmed) { fail(error.message); rejectDeadline(error); } });
  // The rejection is consumed even if it expires between protocol calls.
  deadline.catch(() => {});
  const relative = url => {
    if (!url.startsWith(origin + '/') || url.includes('?') || url.includes('#'))
      throw new Error('Unexpected identity URL: ' + url);
    const path = url.slice(origin.length + 1);
    return path === '' ? 'index.html' : decodeURIComponent(path);
  };
  const relevant = path => mandatory.includes(path) || /\.(js|wasm|wgsl|pck|dat|pdb|json)$/.test(path);
  const register = (url, metadata) => {
    const path = relative(url);
    if (!relevant(path)) return null;
    if (!expected[path]) throw new Error('Unlisted relevant asset: ' + path);
    if (++requestCount > limit.requests) throw new Error('Request metadata capacity exceeded.');
    lastRelevant = Date.now();
    return { path, url, ...metadata };
  };
  const enqueue = entry => {
    if (!active) return;
    if (queue.length >= limit.requests) return fail('Body queue capacity exceeded.');
    queue.push(entry); lastRelevant = Date.now();
  };
  const request = event => {
    if (!active) return;
    try {
      if (event.request.url.startsWith('blob:' + origin + '/')) {
        if (event.type !== 'Other' || event.request.method !== 'GET' || event.redirectResponse ||
            event.documentURL !== origin + '/' || !navigationLoader || event.loaderId !== navigationLoader)
          throw new Error('Unclassified blob request.');
        generatedUrls.add(event.request.url);
        if (generatedUrls.size > 1 || ++requestCount > limit.requests)
          throw new Error('Generated favicon metadata capacity exceeded.');
        lastRelevant = Date.now();
        main.set(event.requestId, { path: 'GeneratedFavicon', generatedFavicon: true,
          boundary: 'OwnedPageCDP', url: event.request.url, resourceType: event.type,
          requestId: event.requestId, loaderId: event.loaderId, method: event.request.method,
          documentURL: event.documentURL, receivedAt: Date.now() });
        return;
      }
      const path = relative(event.request.url);
      // Worker bodies use the existing Playwright response boundary. Native clock
      // is also collected there because it is imported in both B and S.
      if (path.startsWith('simulation/') || path === 'native-clock.js') return;
      const row = register(event.request.url, { boundary: 'OwnedPageCDP', requestId: event.requestId,
        loaderId: event.loaderId, method: event.request.method, documentURL: event.documentURL,
        receivedAt: Date.now() });
      if (!row) return;
      if (event.redirectResponse || event.request.method !== 'GET') throw new Error('Redirect or non-GET identity request.');
      if (row.path === 'index.html') {
        if (navigationLoader && navigationLoader !== row.loaderId) throw new Error('Multiple navigation loaders.');
        navigationLoader = row.loaderId;
      }
      main.set(event.requestId, row);
    } catch (error) { fail(error.message); }
  };
  const response = event => {
    const row = main.get(event.requestId);
    if (!active || !row) return;
    row.status = event.response.status; row.responseURL = event.response.url;
    row.fromServiceWorker = !!event.response.fromServiceWorker;
    if (row.status !== 200 || row.responseURL !== row.url) return fail('Invalid main response: ' + row.path);
    if (row.generatedFavicon) {
      row.mimeType = event.response.mimeType;
      row.contentLength = Object.entries(event.response.headers)
        .find(([name]) => name.toLowerCase() === 'content-length')?.[1];
      if (row.mimeType !== 'image/png' || String(row.contentLength) !== '5508')
        fail('Generated favicon response differs from the current declared role.');
    }
  };
  const loaded = event => {
    const row = main.get(event.requestId);
    if (!active || !row) return;
    if (row.status !== 200) return fail('Main body lacks accepted200 response: ' + row.path);
    main.delete(event.requestId);
    row.loadingFinished = { timestamp: event.timestamp, encodedDataLength: event.encodedDataLength };
    if (row.generatedFavicon) {
      result.generatedFavicons.push({ ...row, completedAt: Date.now(), byteIdentityClaim: false });
      lastRelevant = Date.now();
      return;
    }
    enqueue({ row, read: () => session.send('Network.getResponseBody', { requestId: event.requestId }) });
  };
  const failed = event => {
    if (active && main.has(event.requestId)) fail('Main identity load failed: ' + event.errorText);
  };
  const playwrightRequest = req => {
    if (!active) return;
    try {
      if (req.url().startsWith('blob:' + origin + '/')) {
        if (req.resourceType() !== 'other' || req.method() !== 'GET' || req.redirectedFrom())
          throw new Error('Unclassified public blob request.');
        publicGeneratedUrls.add(req.url());
        if (publicGeneratedUrls.size > 1) throw new Error('Public generated favicon capacity exceeded.');
        lastRelevant = Date.now();
        return;
      }
      const path = relative(req.url());
      if (!path.startsWith('simulation/') && path !== 'native-clock.js') return;
      const row = register(req.url(), { boundary: 'PlaywrightWorkerResponse',
        requestId: null, loaderId: null, observationId: ++received,
        method: req.method(), resourceType: req.resourceType(), startedAt: Date.now() });
      if (!row) return;
      if (req.redirectedFrom() || row.method !== 'GET') throw new Error('Invalid worker identity request.');
      workerPending.set(req, row);
    } catch (error) { fail(error.message); }
  };
  const playwrightResponse = response => {
    if (!active) return;
    const req = response.request();
    const row = workerPending.get(req);
    if (!row) return;
    row.status = response.status(); row.fromServiceWorker = response.fromServiceWorker();
    row.receivedAt = Date.now();
    if (row.status !== 200 || response.url() !== row.url)
      return fail('Invalid worker identity response: ' + row.path);
    responseByRequest.set(req, { row, response });
  };
  const playwrightFinished = req => {
    const entry = responseByRequest.get(req);
    if (!active || !workerPending.has(req)) return;
    if (!entry) return fail('Worker body lacks accepted response: ' + req.url());
    workerPending.delete(req); responseByRequest.delete(req);
    entry.row.requestTiming = req.timing();
    enqueue({ row: entry.row, read: async () => {
      // requestfinished precedes this call. No body call starts before completion.
      const bytes = await entry.response.body();
      if (bytes.byteLength > limit.resource) throw new Error('Worker body exceeds resource cap.');
      return { body: bytes.toString('base64'), base64Encoded: true };
    } });
  };
  const playwrightFailed = req => {
    if (active && workerPending.has(req)) fail('Worker identity request failed: ' + req.url());
  };
  const consoleMessage = message => {
    if (!active) return;
    if (result.logs.length >= limit.logEntries) return fail('Console capacity exceeded.');
    const value = message.text();
    if (value.length > limit.logChars) return fail('Console message capacity exceeded.');
    result.logs.push({ at: Date.now(), type: message.type(), text: value });
    if (message.type() === 'error') fail('Browser console error during identity collection.');
  };
  try {
    if (page.url() !== origin + '/') throw new Error('Existing8060 page required.');
    result.before = await within(page.evaluate(() => ({ url: location.href,
      controlled: !!navigator.serviceWorker.controller,
      controller: navigator.serviceWorker.controller?.scriptURL,
      isolated: crossOriginIsolated, visibility: document.visibilityState })));
    if (!result.before.controlled || !result.before.isolated || result.before.visibility !== 'visible')
      throw new Error('Controlled isolated foreground page required.');
    session = await within(page.context().newCDPSession(page));
    session.on('Network.requestWillBeSent', request);
    session.on('Network.responseReceived', response);
    session.on('Network.loadingFinished', loaded);
    session.on('Network.loadingFailed', failed);
    page.on('request', playwrightRequest); page.on('response', playwrightResponse); page.on('requestfinished', playwrightFinished);
    page.on('requestfailed', playwrightFailed); page.on('console', consoleMessage);
    await within(session.send('Network.enable', { maxTotalBufferSize: limit.cache,
      maxResourceBufferSize: limit.resource, maxPostDataSize: 0 }));
    await within(page.reload({ waitUntil: 'domcontentloaded', timeout: limit.wallMs }));
    while (active) {
      const entry = queue.shift();
      if (!entry) {
        if (mandatory.every(path => hashes.has(path)) && main.size === 0 &&
            responseByRequest.size === 0 && workerPending.size === 0 && Date.now() - lastRelevant >= 1000) break;
        await within(wait(25)); continue;
      }
      reading = true;
      const body = await within(entry.read());
      if (!active) break;
      if (body.body.length > limit.payloadChars) throw new Error('Encoded body exceeds cap.');
      const wanted = expected[entry.row.path];
      const expression = '(async () => { const text=' + JSON.stringify(body.body) +
        '; const binary=' + JSON.stringify(body.base64Encoded) +
        '; let bytes;if(binary){const raw=atob(text);bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);}else{bytes=new TextEncoder().encode(text);}' +
        'if(bytes.byteLength>' + limit.resource + ')throw new Error("Decoded body exceeds cap");' +
        'const digest=await crypto.subtle.digest("SHA-256",bytes);' +
        'return {bytes:bytes.byteLength,sha256:Array.from(new Uint8Array(digest),v=>v.toString(16).padStart(2,"0")).join("")}; })()';
      const reply = await within(session.send('Runtime.evaluate',
        { expression, awaitPromise: true, returnByValue: true }));
      if (reply.exceptionDetails || !reply.result?.value) throw new Error('Page WebCrypto failed.');
      const actual = reply.result.value;
      totalDecoded += actual.bytes;
      if (totalDecoded > limit.decodedTotal) throw new Error('Aggregate decoded body cap exceeded.');
      if (actual.bytes !== wanted.bytes || actual.sha256 !== wanted.sha256)
        throw new Error('Loaded body mismatch: ' + entry.row.path);
      const prior = hashes.get(entry.row.path);
      if (prior && (prior.bytes !== actual.bytes || prior.sha256 !== actual.sha256))
        throw new Error('Different bodies for duplicate URL: ' + entry.row.path);
      if (!prior) uniqueDecoded += actual.bytes;
      if (uniqueDecoded > limit.decodedUnique) throw new Error('Unique decoded body cap exceeded.');
      hashes.set(entry.row.path, actual);
      if (hashes.size > limit.distinct) throw new Error('Distinct asset capacity exceeded.');
      result.records.push({ ...entry.row, ...actual, duplicate: !!prior, completedAt: Date.now() });
      reading = false; lastRelevant = Date.now();
    }
    if (!active) throw new Error('Collection stopped by a recorded failure.');
    result.after = await within(page.evaluate(() => {
      const icon = document.getElementById('-gd-engine-icon');
      return { url: location.href, controller: navigator.serviceWorker.controller?.scriptURL,
        isolated: crossOriginIsolated, visibility: document.visibilityState,
        generatedIcon: icon ? { tag: icon.tagName, rel: icon.rel, href: icon.href } : null };
    }));
    result.publicGeneratedUrls = [...publicGeneratedUrls];
    for (const url of new Set([...generatedUrls, ...publicGeneratedUrls])) {
      const icon = result.after.generatedIcon;
      if (!generatedUrls.has(url) || !publicGeneratedUrls.has(url) ||
          !result.generatedFavicons.some(row => row.url === url) ||
          result.after.url !== origin + '/' || icon?.tag !== 'LINK' || icon.rel !== 'icon' || icon.href !== url)
        throw new Error('Generated favicon lacks exact current-document role or duplicate-boundary join.');
    }
    result.workerUrls = page.workers().map(worker => worker.url());
    result.navigationLoader = navigationLoader;
    result.missing = mandatory.filter(path => !hashes.has(path));
    if (result.missing.length || !navigationLoader || result.workerUrls.length !== 1 ||
        result.workerUrls[0] !== origin + '/simulation/worker.js' ||
        result.after.controller !== result.before.controller || !result.after.isolated ||
        result.after.visibility !== 'visible') throw new Error('Final identity/environment check failed.');
    result.verdict = 'IdentitiesCompletePendingReviewerReadyAndSessionAdmission';
  } catch (error) {
    result.errors.push(String(error.message || error).slice(0, 4096));
  } finally {
    active = false; deadlineArmed = false; resolveDeadline();
    page.off('request', playwrightRequest); page.off('response', playwrightResponse); page.off('requestfinished', playwrightFinished);
    page.off('requestfailed', playwrightFailed); page.off('console', consoleMessage);
    if (session) {
      session.off('Network.requestWillBeSent', request);
      session.off('Network.responseReceived', response);
      session.off('Network.loadingFinished', loaded);
      session.off('Network.loadingFailed', failed);
    }
    result.pendingAtStop = { reading, queue: queue.length, main: main.size,
      workerResponses: responseByRequest.size, workerRequests: workerPending.size };
    queue = []; main.clear(); responseByRequest.clear(); workerPending.clear();
    let cleanupArmed = true;
    const cleanupWait = page.waitForTimeout(limit.cleanupMs).then(() => {
      if (cleanupArmed) throw new Error('Owned CDP detach exceeded2s.');
    });
    try {
      if (session) await Promise.race([session.detach(), cleanupWait]);
      result.cleanup = { detached: true, completedAt: Date.now() };
    } catch (error) {
      result.cleanup = { detached: false, error: String(error.message || error) };
      result.verdict = 'Incomplete';
    } finally { cleanupArmed = false; }
    // Public Playwright waits have no cancellation operation. Disarm, then drain
    // both fixed waits before return; no pending helper timer can enter trials.
    await cleanupWait.catch(() => {});
    await wallWait;
    result.cleanup.driverDeadlineWaitsSettled = true;
    result.expired = expired;
    result.decodedBytes = totalDecoded; result.uniqueDecodedBytes = uniqueDecoded; result.end = Date.now();
    if (result.errors.length || reading || result.pendingAtStop.queue ||
        result.pendingAtStop.main || result.pendingAtStop.workerResponses || result.pendingAtStop.workerRequests) result.verdict = 'Incomplete';
    result.missing = mandatory.filter(path => !hashes.has(path));
  }
  return result;
}
