#!/usr/bin/env bash
# Compare reviewer base/candidate captures with each other and with the implementer's receipts.
S=/private/tmp/claude-501/-Users-aidan-dev-personal-tim/7e56a042-6670-44d4-ae0f-4efd972de00e/scratchpad
I=/Users/aidan/dev/personal/tim/.claude/worktrees/story-9a-39/_bmad-output/implementation-artifacts/evidence-9a-39
echo "== reviewer base vs reviewer candidate (traces, lesson worlds, placed solutions)"
for f in $(cd $S/rvb/capture && ls trace-*.txt lesson-world.txt placed-solutions.txt); do
  if cmp -s $S/rvb/capture/$f $S/rvc/capture/$f; then echo "IDENTICAL $f $(wc -l < $S/rvb/capture/$f) lines"; else echo "DIFFER $f"; fi
done
echo "trace files: $(ls $S/rvb/capture/trace-*.txt | wc -l); lesson lines: $(wc -l < $S/rvb/capture/lesson-world.txt); placed lines: $(wc -l < $S/rvb/capture/placed-solutions.txt)"
echo "== reviewer base vs implementer baseline"
for f in $(cd $S/rvb/capture && ls trace-*.txt lesson-world.txt placed-solutions.txt); do
  cmp -s $S/rvb/capture/$f $I/baseline/capture/$f && echo "SAME $f" || echo "DIFF $f"
done
echo "== reviewer base-encoder old saves vs implementer pins"
(cd $S/rvb/old-saves && shasum -a 256 *.bin) > $S/rvb/old-saves.sha256
diff <(sort -k2 $S/rvb/old-saves.sha256 | awk '{print $1, $2}') <(sort -k2 $I/baseline/capture/old-saves.sha256 | awk '{print $1, $2}' | sed 's# \*# #; s# .*/# #') && echo "OLD SAVES BYTE-IDENTICAL to implementer pins ($(wc -l < $S/rvb/old-saves.sha256) files)"
echo "== base decode of base bytes (positive control): refused lines"
grep -c LOADED $S/rvb/capture/old-save-outcomes.txt; grep -v LOADED $S/rvb/capture/old-save-outcomes.txt
echo "== candidate decode vs implementer candidate outcomes"
diff $S/rvc/capture/old-save-outcomes.txt $I/candidate/capture-final/old-save-outcomes.txt && echo "OUTCOMES IDENTICAL"
echo "== unshifted kinds: base vs candidate LOADED lines"
for k in lamp latch ball_detector pipe_5_5 pressure_plate_2 clock_2_5 basketball powered_gate; do
  for b in save command; do
    x=$(grep "^$k: $b " $S/rvb/capture/old-save-outcomes.txt); y=$(grep "^$k: $b " $S/rvc/capture/old-save-outcomes.txt)
    [ "$x" = "$y" ] && echo "SAME $k $b" || echo "DIFF $k $b"
  done
done
echo "== NaN split base"; cat $S/rvb/nan-split.txt; echo "== NaN split candidate"; cat $S/rvc/nan-split.txt
