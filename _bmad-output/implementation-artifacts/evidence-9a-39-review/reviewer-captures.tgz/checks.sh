#!/usr/bin/env bash
# Reviewer checks for 9A.39: CI "Test C# tools" step verbatim from .github/workflows/pages.yml, Release worker build,
# strict tsc + snapshot unit (pinned toolchain), git diff --check.
cd /Users/aidan/dev/personal/tim/.claude/worktrees/story-9a-39
E=_bmad-output/implementation-artifacts/evidence-9a-39-review
{
set -x
dotnet test tools/Coverage.Tests --nologo --no-build --no-restore -c Debug -f net10.0 -noAutoResponse
dotnet test tools/BundleElements.Tests --nologo --no-build --no-restore -c Debug -f net10.0 -noAutoResponse
dotnet test tools/WorkerAotGuard.Tests --nologo --no-build --no-restore -c Debug -f net10.0 -noAutoResponse
toolchain="TypeCheckTests.EverySuiteAndSharedModuleTypeChecks TypeCheckTests.ASuiteReadingADeletedAccessorFailsTheTypeCheck
  SuiteProcessTests.EnvironmentIsScrubbed SuiteProcessTests.HangIsTimedOutAndTheWholeTreeIsKilled
  SuiteProcessTests.FailingAssertionFailsTheFile SuiteProcessTests.CloseFindingInAfterHookFailsTheFile
  SuiteProcessTests.FileWithoutTestsIsNoTests SuiteProcessTests.CrashFailsTheFile
  SuiteProcessTests.PassingFileIsPassAndCountsDriverSignals SuiteProcessTests.ImportErrorFailsWithNoTests
  IdentityTests.UnchangedRunPasses IdentityTests.BundleChangedMidRunAbortsWithIdentityChanged
  IdentityTests.BundleChangedAndRestoredIsStillIdentityChanged IdentityTests.SuiteSourceChangedMidRunIsIdentityChanged
  IdentityTests.EndRehashCatchesAChangeTheWatcherMissed"
filter=""
for test in $toolchain; do filter="$filter&FullyQualifiedName!=CuriousContraptions.E2eRunner.Tests.$test"; done
dotnet test tools/E2eRunner.Tests --nologo --no-build --no-restore -c Debug -f net10.0 -noAutoResponse --filter "${filter#&}"
echo "ci-tools rc=$?"
} > $E/ci-tools.log 2>&1

dotnet build CuriousContraptions.Simulation/CuriousContraptions.Simulation.csproj -c Release > $E/worker-release.log 2>&1; echo "worker release rc=$?" >> $E/worker-release.log

find_pkg() { for d in $(ls -d "$HOME"/.npm/_npx/*/node_modules/"$1" 2>/dev/null | sort); do
  v=$(node -p "require('$d/package.json').version" 2>/dev/null); [ "$v" = "$2" ] && { echo "$d"; return; }; done; }
TSC=$(find_pkg typescript 6.0.3)/bin/tsc
TYPES=$(dirname "$(find_pkg @types/node 26.0.1)")
TSX=$(ls -d "$HOME"/.npm/_npx/*/node_modules/tsx 2>/dev/null | sort | tail -1)
{
echo "tsc: $TSC"; echo "typeRoots: $TYPES"; echo "tsx: $TSX ($(node -p "require('$TSX/package.json').version"))"
node "$TSC" --noEmit --project tools/e2e/tsconfig.json --typeRoots "$TYPES"; echo "tsc rc=$?"
node "$TSX/dist/cli.mjs" --test tools/e2e/unit/run-reset-snapshot.test.ts; echo "snapshot unit rc=$?"
} > $E/ts-checks.log 2>&1

{ git diff --check HEAD; echo "diff-check rc=$?"; git diff --check --no-index /dev/null CuriousContraptions.tests/SourceStoreInstanceTests.cs | grep -v "^+" ; echo "untracked-file whitespace check done"; } > $E/diff-check.txt 2>&1
grep -E "Passed!|Failed!|rc=" $E/ci-tools.log; tail -6 $E/worker-release.log; grep -E "rc=|^ℹ (tests|pass|fail)" $E/ts-checks.log; cat $E/diff-check.txt
