using CuriousContraptions.Gpu;

namespace CuriousContraptions.Tests;

/// <summary>9A.39 independent-review probe (not a deliverable). Same source on base f27cb71d and on the candidate. Writes to
/// RV9A39_DIR the refusal reasons of a current-layout generic Bumper record carrying a NaN declared parameter at the save and command
/// boundaries: whether the NonFinite/OutOfRange split for a NaN parameter is pre-existing generic-path behaviour.</summary>
public sealed class ReviewerProbe9a39
{
    private static string Outcome(Action action)
    {
        try { action(); return "LOADED"; }
        catch (WorkshopSaveRejectedException error) { return $"save {error.Reason}"; }
        catch (WireFaultException error) { return $"wire {error.Reason}"; }
        catch (ArgumentException error) { return $"untyped {error.GetType().Name}: {error.Message}"; }
        catch (InvalidOperationException error) { return $"untyped {error.GetType().Name}: {error.Message}"; }
    }

    [Fact]
    public void NaNParameterSplit()
    {
        if (Environment.GetEnvironmentVariable("RV9A39_DIR") is not { } dir) return;
        var lines = new List<string>();
        foreach (var (part, key) in new[] { ("bumper", "strength"), ("switch", "trigger_threshold") })
            foreach (var value in new[] { float.NaN, float.PositiveInfinity, 1e9f })
            {
                var bytes = PayloadInstanceTests.GenericSave(part, null, [(key, value)]);
                var save = Outcome(() => WorkshopSaveCodec.Decode(SaveFixture.Elements, bytes));
                var command = Outcome(() => WorkshopWireFlatBuffers.MapInstance(WorkshopSaveCodec.Open(bytes).Construction!.Value.Instances(0)!.Value));
                lines.Add($"{part} {key}={value} save:{save} command:{command}");
            }
        File.WriteAllLines(Path.Combine(dir, "nan-split.txt"), lines);
    }
}
