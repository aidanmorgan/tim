#!/usr/bin/env bash
# Usage: mutant.sh <name> <mutated file relative to rv-cand>
# Builds the mutated throwaway candidate, runs the main suite and the bundle tests, records the log, restores the file from the index.
S=/private/tmp/claude-501/-Users-aidan-dev-personal-tim/7e56a042-6670-44d4-ae0f-4efd972de00e/scratchpad
C=$S/rv-cand
O=/Users/aidan/dev/personal/tim/.claude/worktrees/story-9a-39/_bmad-output/implementation-artifacts/evidence-9a-39-review/mutation
mkdir -p $O
L=$O/$1.log
cd $C
{
  echo "mutant $1 file $2"; git diff -- "$2"
  dotnet build CuriousContraptions.slnx -c Debug > $O/$1.build.txt 2>&1; rc=$?
  grep -E "error|Warn|Error\(s\)|Build succeeded|FAILED" $O/$1.build.txt | sort -u | head -20
  if [ $rc -ne 0 ]; then echo "BUILD FAILED rc=$rc: tests not run (stale binaries would be invalid)"; else
  dotnet test CuriousContraptions.tests -c Debug --no-build --no-restore 2>&1 | grep -E "^\s+Failed |Passed!|Failed!" | head -40
  dotnet test tools/BundleElements.Tests -c Debug --no-build --no-restore 2>&1 | grep -E "^\s+Failed |Passed!|Failed!" | head -40
  fi
} > $L 2>&1
git checkout -- "$2"
echo "restored: $(git diff --quiet -- "$2" && echo yes || echo NO)" >> $L
grep -E "error|BUILD FAILED|Passed!|Failed!|^\s+Failed |restored" $L | head -30
