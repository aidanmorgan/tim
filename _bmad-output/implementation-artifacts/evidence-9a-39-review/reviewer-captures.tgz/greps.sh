#!/usr/bin/env bash
# Deletion greps (spec 9A.39) on base HEAD and candidate worktree, production scope.
cd /Users/aidan/dev/personal/tim/.claude/worktrees/story-9a-39
P=(engine ui elements CuriousContraptions.Abstractions CuriousContraptions.Abstractions.Electrical CuriousContraptions.Abstractions.Fluid CuriousContraptions.Abstractions.Mechanical CuriousContraptions.Abstractions.Signal CuriousContraptions.Bundle CuriousContraptions.Simulation CuriousContraptions.Animation CuriousContraptions.Animation.Worker CuriousContraptions.web CuriousContraptions.FlatBuffers ':(exclude)engine/PartId.cs')
P1='WorkshopBattery|AddBatteryConfiguration|ElectricalSourceSettings|IWorkshopElectricalSource|CanonicalSource|ApplySource|RefreshBatteryObservation|BatteryIntent|BatteryToggleText'
P2='_battery|WorkshopInput\.Battery\b|PartId\.Battery'
for side in base candidate; do
  if [ $side = base ]; then
    a=$(git grep -n -w -E "$P1" HEAD -- "${P[@]}" | wc -l)
    b=$(git grep -n -E "$P2" HEAD -- "${P[@]}" | wc -l)
    c=$(git grep -n -F '"battery"' HEAD -- engine/gpu 'engine/MachineWorld*.cs' | wc -l)
  else
    a=$(git grep -n --untracked -w -E "$P1" -- "${P[@]}" | wc -l)
    b=$(git grep -n --untracked -E "$P2" -- "${P[@]}" | wc -l)
    c=$(git grep -n --untracked -F '"battery"' -- engine/gpu 'engine/MachineWorld*.cs' | wc -l)
  fi
  echo "$side: p1=$a p2=$b p3=$c"
done
echo "ls-files deleted: [$(git ls-files ui/WorkshopBattery.cs engine/gpu/WorkshopBattery.cs)]"
echo "== candidate residual 'battery' (case-insensitive) in engine/ui production, for inspection"
git grep -n --untracked -i -E 'battery' -- engine ui ':(exclude)engine/PartId.cs' | head -40
